# Response to the reviewer (revision 6)

Every number below is generated from the result files (`numbers.tex`). Status key: **Agreed and fixed**, **Partly agreed**, **Not reproduced / disagree**, **Cannot be done by us** (needs the authors or new data).

## Overall
The reviewer's most important concern, the clamping of output nodes, was **correct and more serious than the review stated**. We re-ran every AML analysis under a corrected policy. Several first-draft AML conclusions did not survive, and the manuscript now says so.

## Major concerns

### 1. Output nodes appear to be clamped as drug targets: **Agreed and fixed**
* **Verified in the code.** In the AML network the clampable set was every gene except NPM1 and DNMT3A, so the reward genes (BCL2, MYC, CCND1, AKT1, STAT5A, TP53, CDKN2A) could be clamped. The Methods sentence "non-output nodes" was true only for the three published Boolean models, not for the AML network.
* **It is worse than described.** No gene's rule uses BCL2 as a regulator (0 rules), so venetoclax cannot change any other node. Its apparent effect was entirely the clamp setting a reward indicator.
* **Fix.** New strict policy (default): TP53, CDKN2A (on), MYC, CCND1, STAT5A (off) form a five-marker reward; none can be clamped; BCL2 and AKT1 stay clampable but are outside the reward. The original policy remains as `--aml-policy legacy` for comparison only.
* **Effect on results (same simulations, two rewards).** Venetoclax gain: +10.9 points (legacy) to 0.0 (strict). Midostaurin + venetoclax: +19.1 to +1.5, which is midostaurin alone (+1.5). The old best three-gene set (BCL2+MYC+SYK) was mostly direct clamping of two output nodes. **The first draft's headline pair, its "exactly additive" finding and the size-matched null were artifacts.**
* **New headline pair (strict).** Midostaurin + ibrutinib (53.4% against 44.7% untreated). It is a different result, and the manuscript presents it as such.
* **The triplet survived.** Ibrutinib + midostaurin + an ERK-inhibitor class contains neither BCL2 nor AKT1, and is again the certified best druggable set.
* **All affected analyses were re-run:** five-drug ranking, size-matched null, stability, genotype strata, calibration checks, druggable search, audit, cost sensitivity, scaling, genotype search, marker decomposition, benchmark for the AML network, TBS on the AML network.
* Where: Results 2.6, Fig. 4, Methods "Interventions, clamping policy and reward", Supplementary Table `policy`.

### 2. "Independent calibrations" is overstated: **Agreed and fixed**
* Replaced "independent" by "distinct" everywhere. Verified: the 15 calibrations have **identical rule sets** and differ only in probabilities. Pairwise Spearman of rule-probability vectors: mean 0.67, minimum 0.36; of the ten five-drug scores: mean 0.81, minimum 0.21. They are an ensemble of related fits.
* The reviewer also said the triplet was compared with only four sets. **Correct for the first draft.** We now ran the **full 92-set certified search inside every calibration**: triplet is the certified best in 15/15, rank at most 3 in 15/15; excess over additivity positive in 15/15 (mean 0.182, range 0.083 to 0.342); over Bliss in 15/15 (mean 0.201, range 0.107 to 0.356).
* Where: Results 2.7, Supplementary Table `calib`.

### 3. The triplet relies on weak or uncalibrated components: **Partly agreed; sensitivity analysis added**
* **Agreed:** ERK-inhibitor unit outside the calibration; midostaurin calibration weak (within-drug r = 0.29); mapping is our assumption. The text now calls the triplet a hypothesis with low biological confidence.
* **Sensitivity analysis added (requested).** Removing the MAPK1 input to STAT5A: excess 0.143 (reference 0.152), triplet still best of the four triplets. Swapping the two main STAT5A rule probabilities: excess 0.089. Random rewiring of one regulator (60 networks): positive in 100%, triplet best in 100%. Three rewirings: 100% positive, 98% best.
* **A correction to our own earlier claim.** We had said the STAT5A rule `BTK | FLT3 | MAPK1` explains the excess. The ablation shows it does not: the excess is spread over several markers, and removing both BTK and MAPK1 inputs removes only STAT5A's share. The text no longer claims that explanation.
* **Not done:** alternative rule *forms* beyond these perturbations; any experimental test.
* Where: Results 2.7 and 2.8, Fig. 7, Supplementary Tables `struct`, `mech`.

### 4. Additive null versus Bliss independence: **Agreed and fixed**
* The first draft used a linear additive null. Both nulls are now defined in the Methods and **both are reported**: Bliss independence is computed per marker from fractional effects and averaged over markers (the reward is a mean of marker indicators).
* Headline pair: excess 4.21 points (additive) and 4.54 (Bliss). Triplet: 0.149 (additive) and 0.158 (Bliss). Both are super-additive under both nulls; Bliss gives somewhat larger excess because it is smaller than the linear sum.
* We state explicitly that both are model-based nulls on a fraction-of-markers reward and are not measures of drug synergy.

### 5. Benchmark too small: **Partly agreed**
* **Exact bound added.** 21/21 successes gives a one-sided 95% lower bound of 86.7% (Clopper-Pearson). The reviewer's "about 85%" was for 18/18; we now have more runs.
* **More repetitions only for the network that had to be re-run:** AML now 8 repetitions; Calzone 5, Grieco 5, Remy 3 (unchanged). Total 21 certified runs. Increasing the other networks was not possible in our environment and is listed as a limitation.
* **C2 failed** and C3 held with ties: both stated in abstract and Results. The protocol is not publicly registered; the text says "time-stamped inside our project".
* **Ground-truth risk (top-30 re-estimation) quantified:** union bound on missing a better set is at most 1 (worst-case SD 0.5); margins in Supplementary Table `gtmargin`.
* Remy at 3 repetitions and T-LGL dropped remain disclosed deviations.

### 6. Theory is only a sketch; formula inconsistency: **Partly agreed; one claim of ours was wrong**
* **Formula.** In our LaTeX source, Algorithm 1 and the Methods give the *same* formula, with the `7L/(3(n-1))` term **outside** the square root, and the code (`np.sqrt(2*var*L/(n-1)) + 7*L/(3*(n-1))`) matches. We suspect plain-text extraction of the PDF merged the two lines. We have now typeset it as an explicit display with fractions so that it cannot be misread. Not reproduced as an inconsistency.
* **Unsupported "about 3%" claim: correct, and our claim was wrong.** We measured it: the strict 1-delta constant costs **5.0% more simulations** (20 paired runs), as expected because cost scales with the square of the radius. The manuscript now reports the measured value and the derivation.
* **Weak audit: partly addressed.** Added a harder audit (15 sets, 2 within epsilon of the best): 15/15 certified, 15/15 correct, 0 interval violations. Still modest, and the text says so.
* **Not done:** a line-by-line verification of the sample-complexity constants. It remains a sketch and is labelled as one.

### 7. Missing or corrupted Figure 2 and page 5: **Not reproduced; defensive fixes made**
* In our compiled PDF every figure is embedded (checked with `pdfimages`). We cannot reproduce a missing figure. The images were PNGs with alpha channels, which some viewers handle badly, so all figures are now flattened to RGB. The page layout has also changed.

### 8. Submission-readiness placeholders: **Cannot be done by us**
* The `[Authors: ...]` notes (contributions, repository DOI, how the authors verified the AI-assisted code and text) must be completed by the authors. We cannot invent them. The AI-assistance disclosure is kept.

## Minor concerns
* **Patient-level uncertainty and TBS tangential:** moved out of the main Results into Supplementary Notes 3 and 4 (main text keeps a short pointer).
* **State-of-the-art comparator:** LUCB added (same empirical-Bernstein radius). On the 92-set family both were correct in 4/4 runs and LUCB used 87,100 simulations against 80,250. **Not done:** UGapE or other methods; one family only. Stated.
* **"Certified" wording and confidence level:** the abstract and Results now state the level (at least 1-2*delta) and that the certificate is conditional on the model and the candidate family.
* **Reproducibility claim ("221/224 reproduced"):** **withdrawn.** It referred to the flawed analysis. The README now states what was actually checked: a repeat of the druggable stage reproduced its ranking, trace and summary identically, and the pipeline was not run in one uninterrupted session.
* **Future-dated references (2026):** unchanged. Authors must confirm publication status; several other references were entered from memory and must be verified.

## Changes the reviewer did not ask for
* Cost numbers under the corrected AML policy: reduction at epsilon 0.005, 0.01, 0.02, 0.05 is 180.8, 48.8, 13.5 and 2.5 times.
* Genotype-conditional search: the triplet is the best set in **all four** FLT3 x NPM1 strata (the first draft's "FLT3-mutant-specific" statement is withdrawn); only the size of the excess differs (larger in FLT3-mutant strata).
* The first draft's statements "midostaurin + venetoclax is additive" and "KIT adds nothing in the venetoclax pair" were about an artifact and are removed; the class-level test now uses ibrutinib (FLT3-only 53.32% against midostaurin 53.47%).
