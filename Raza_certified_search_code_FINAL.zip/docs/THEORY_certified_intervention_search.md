# Certified adaptive intervention search: formal statement

Status: **proof sketch for internal use. Constants and the sample-complexity statement must be verified line by line before submission.**

## 1. Problem

A stochastic gene-network model and a finite family of admissible interventions
`A` (|A| = K), for example all sets of at most k non-output nodes clamped to 0.
One simulation of intervention `a` returns a reward `X in [0,1]` (here: fraction of output
indicators in their desired state at the final step). Simulations are i.i.d. given `a`.
Let `mu_a = E[X | a]` (the model's expected score) and `mu* = max_a mu_a`.

**Goal ((eps, delta)-PAC identification).** Output `a_hat` such that
`P( mu_{a_hat} >= mu* - eps ) >= 1 - delta`, using as few simulations as possible.

What is certified is a property of the **model's expected score**. It is not a statement about biology.

## 2. Algorithm (as implemented in `bench.py`, `certsearch.py`)

Rounds t = 1, 2, ... Each active arm receives m new simulations, so every active arm has n_t = m t samples.

* Empirical mean `mu_hat_a`, unbiased sample variance `V_a`.
* Radius `r_t(a) = sqrt( 2 V_a L_t / (n_t - 1) ) + 7 L_t / (3 (n_t - 1))`, with `L_t = ln( 2 K t (t+1) / delta )`, i.e. `L_t = ln(2/delta_t)` and `delta_t = delta / (K t (t+1))`.
* `LCB_a = mu_hat_a - r_t(a)`, `UCB_a = mu_hat_a + r_t(a)`.
* Eliminate any arm with `UCB_a < max_j LCB_j`.
* Let `b = argmax mu_hat`. **Stop** and return `b` when `LCB_b >= max_{j != b} UCB_j - eps`, or when one arm remains.
* Safety cap on samples per arm; a run that hits the cap is reported as **uncertified**.

## 3. Correctness

**Lemma 1 (empirical Bernstein; Maurer and Pontil, 2009).** For i.i.d. `X_i in [0,1]`, n >= 2, and `delta' in (0,1)`,
with probability at least `1 - delta'`:
`mu - mean <= sqrt(2 V ln(2/delta') / n) + 7 ln(2/delta') / (3 (n-1))`, and the same bound holds for `mean - mu`.
(The cited theorem is one-sided for each tail.) Our radius divides the variance term by `n-1` instead of `n`, which is slightly larger and therefore conservative.

**Good event G.** For all arms `a` and all rounds `t`, `|mu_hat_a - mu_a| <= r_t(a)`.

**Lemma 2.** `P(G^c) <= 2 delta` for the constants above.

*Proof.* For fixed `(a, t)` each tail fails with probability at most `delta_t`, so the two-sided event fails with probability at most `2 delta_t`.
The sample count at round t is the deterministic number `m t` for every active arm, so no optional-stopping correction is needed beyond the union over t.
Summing: `sum_t sum_a 2 delta_t = 2 K sum_t delta/(K t (t+1)) = 2 delta`, using `sum_{t>=1} 1/(t(t+1)) = 1`. QED

> **Disclosure.** Because the implemented constant is the one-sided `ln(2/delta_t)`, the rigorously proven guarantee is at level **1 - 2 delta**
> (0.90 for delta = 0.05). A strictly 1 - delta version replaces `2` by `4` inside the logarithm, which enlarges every radius by a factor of about
> `sqrt( ln(4/delta_t) / ln(2/delta_t) )`, roughly 1.03 at the scales used here. We report the 1 - 2 delta statement for the experiments run, and the
> empirical miss rate separately.

**Theorem 1 (correctness).** On G, the algorithm (i) never eliminates an optimal arm, and (ii) any returned arm satisfies `mu_b >= mu* - eps`.
Hence `P(mu_b >= mu* - eps) >= 1 - 2 delta`.

*Proof.* (i) Let `a*` be optimal. Eliminating it needs `UCB_{a*} < max_j LCB_j`. On G, `UCB_{a*} >= mu* >= mu_j >= LCB_j` for every j. Contradiction.
(ii) If the algorithm stops with `LCB_b >= UCB_j - eps` for all `j != b`, then on G, `mu_b >= LCB_b >= UCB_j - eps >= mu_j - eps` for all j, including `a*`.
If one arm remains it is `a*` by (i), or all other arms were removed legitimately, so it is optimal. QED

If the cap is reached before the stopping condition, **no guarantee is claimed** and the run is flagged.

## 4. Sample complexity (sketch, to be verified)

Let `Delta_a = mu* - mu_a`, `Delta_tilde_a = max(Delta_a, eps)`, and `sigma_a^2 = Var(X | a)`.
Following the standard analysis of successive elimination (Even-Dar, Mannor and Mansour, 2006) with empirical-Bernstein radii (as in Audibert, Munos and Szepesvari, 2009),
on G an arm is eliminated once its radius and that of the leader satisfy `2 r_t(a) + 2 r_t(a*) <~ Delta_a`. This gives, up to constants,

`N_total = O( sum_a ( sigma_a^2 / Delta_tilde_a^2 + 1 / Delta_tilde_a ) * ln( K ln(1/Delta_tilde_a) / delta ) )`.

The uniform allocation that provides the same guarantee needs `n_unif = ceil( ln(2K/delta) / (2 eps^2) )` samples per arm (Hoeffding, union over K arms), i.e. `K n_unif` in total.
The adaptive bound is smaller whenever most arms are clearly suboptimal (large `Delta_a`) or have small variance. The savings are largest when the reward distribution is far from the worst case of variance 1/4.

**Limits of the bound.** If many arms are within `eps` of the optimum the algorithm cannot eliminate them and cost grows with their number.
This is a property of the problem, not of the algorithm, and is visible in the benchmark as near-ties.

## 5. Constrained and structured families

Any restriction of `A` (for example only druggable genes, at most k drugs, forbidden combinations) is handled by replacing `A` with the restricted family. The theorem holds unchanged with K the size of the restricted family.

## 6. What this does and does not give

* Gives: a certificate that the returned intervention is within eps of the best in the family, in terms of the model's expected score, with at least 90% confidence as implemented.
* Does not give: any statement that the model is biologically correct, that the output score predicts clinical benefit, or that the best set is synergistic.

## References to verify before citing

* Even-Dar, Mannor, Mansour (2006), Action elimination and stopping conditions for the multi-armed bandit and reinforcement learning problems, JMLR 7.
* Maurer, Pontil (2009), Empirical Bernstein bounds and sample variance penalization, COLT.
* Audibert, Munos, Szepesvari (2009), Exploration-exploitation tradeoff using variance estimates in multi-armed bandits, Theoretical Computer Science.
* Kaufmann, Cappe, Garivier (2016), On the complexity of best-arm identification in multi-armed bandit models, JMLR 17 (found in search; lower bounds and delta-PAC elimination).
