# Certified search for combination interventions in stochastic gene-network models

Code, results and manuscript source for *Certified search for combination interventions in stochastic gene-network models: method, benchmark and a case study in acute myeloid leukemia* (revision 8).

**One file, `aml_certified_search.py`, produces every table and figure in the paper.**

> Everything here concerns the expected score of a *model*. The AML combination predictions are model outputs only and have not been compared with any external data.

## Important: AML clamping policy

An earlier version of the AML analysis allowed reward genes (including the drug targets BCL2 and AKT1) to be clamped, which set part of the reward by construction. That was a flaw and is corrected. The default is now `--aml-policy strict` (reward genes cannot be clamped; BCL2 and AKT1 are not part of the reward). `--aml-policy legacy` reproduces the original behaviour for comparison only. Tables produced with the original policy are in `legacy_policy_results_SUPERSEDED/` and must not be cited as results. No notebook in this release; the earlier notebooks contain the flawed policy and are superseded by this file.

## Quick start

```bash
pip install -r requirements.txt          # Python >= 3.9, git must be installed
python aml_certified_search.py --list
python aml_certified_search.py --stages C_druggable,E_robust       # the AML application and its robustness checks
python aml_certified_search.py --stages C_benchmark --bench-plan aml_pbn_kgbn:0:8   # AML benchmark, 8 repetitions
python aml_certified_search.py --stages paper                      # regenerate numbers.tex, tables and figures from ./results
python aml_certified_search.py --stages paper --results reference_results   # same, from the shipped reference results (no long runs needed)
```
KGBN and PyBoolNet are cloned automatically on first run (public repositories, not redistributed here) at the commits pinned near the top of `aml_certified_search.py`. Stage `F_validation` reads KGBN's saved held-out evaluations, so it needs that commit. Results go to `./results` (`--results`), paper files to `./paper_build` (`--paper-dir`).

## Stages (time measured on one CPU core)

| Stage | What it does | Time |
|---|---|---|
| `B_pbn` | five-drug analysis: baseline, additive null, size-matched null, stability, genotype strata, alternative calibrations, rule noise | 551 s |
| `B_tbs` | validation of the topological score on three networks | 221 s |
| `B_conformal` | patient-level uncertainty on real data (independent of the AML policy) | about 440 s |
| `B_calib`, `B_manifest` | calibration quality; combination-benchmark scaffold; manifest | under 1 s |
| `C_benchmark` | pre-specified benchmark; criteria; exact confidence bound; ground-truth margin (quick mode, or `--bench-plan`, or `--full`) | quick about 120 s; AML 8 repetitions 786 s |
| `C_druggable` | certified search over druggable combinations; stress test across the 15 distinct calibrations | 126 s |
| `E_robust` | policy comparison, calibration dependence, full search in every calibration, structural sensitivity, strict-delta cost, harder audit, LUCB comparison | 766 s |
| `E_mechanism` | marker-level decomposition of the triplet after removing STAT5A inputs | 40 s |
| `D_extended` | guarantee audit, cost sensitivity, bound ablation, scaling, noise, genotype search, marker decomposition | about 22 min in full (701 s with the reused parts below) |
| `F_validation` | retrospective out-of-sample check of the calibrated network on held-out public data (single-drug response only; about 3 min; needs the files cloned from KGBN) | about 200 s |
| `G_decoy` | decoy drug-to-gene maps (`DECOY_N`, `DECOY_M`, `DECOY_REPS` environment variables; reported run: 1,000 decoys, 1,000 simulations per set, 30 replicates of the real map) and single-gene loss of function (computational only, no external data) | about 35 min |
| `C_figures`, `D_figures`, `paper` | figures, `numbers.tex`, tables | seconds |

## Provenance of `reference_results/` (be aware)

Processes in the environment used here did not survive long idle periods, so the reference results were produced over several sessions with the same code:
* produced after the policy correction: all AML stages (`B_pbn`, `C_druggable`, `E_robust`, `E_mechanism`, `D_extended` except the parts below, `B_tbs`, AML benchmark with 8 repetitions);
* reused from earlier complete runs of the same code because they do not depend on the AML policy: `B_conformal` outputs, the Calzone noise experiment (`d_noise.csv`), and the Calzone (5 repetitions), Grieco (5) and Remy (3) benchmark tables;
* reused from an earlier run of `D_extended` that was interrupted after finishing them: parts D.1 (audit, `d_missrate_runs.csv`) and D.2 (`d_sensitivity.csv`). Both use the druggable family, whose clampable genes do not include reward genes, but their reward is the five-marker reward, so they were produced after the policy correction.
* stages `F_validation` and `G_decoy` (added in revision 8) were each run in a single session; `G_decoy` was run again at its reported size after an accidental overwrite and reproduced the earlier log line for line;
* the complete pipeline has **not** been run in one uninterrupted session.

## Reproducibility checks actually made

* A clean-room test of this release (fresh directory, steps of the Quick start only) was run for `--list`, `F_validation`, a reduced `G_decoy` and `paper` from `reference_results`; see `CHANGELOG.md`.

* A repeat of stage `C_druggable` reproduced the druggable ranking table, the elimination trace and the summary file identically.
* A process-dependent random seed (Python `hash()` of a string tuple) was found and replaced by a fixed one during development.
* Library versions of the reference run: Python 3.12.3, numpy 2.4.4, scipy 1.17.1, pandas 3.0.2, matplotlib 3.10.8, scikit-learn 1.8.0, networkx 3.6.1, ripser 0.6.15. No claim of bit-for-bit reproducibility across versions.
* A long stage must finish in one session; if interrupted, re-run the remaining stages with `--stages`.

## Optional external comparison

Stage `B_calib` contains a small scaffold that, if a table `<folder above --results>/data/measured_combination_synergy.csv` (columns `drug_a, drug_b, synergy`) is supplied, reports a rank correlation with the model's predicted excess over additivity. No such table is used in the manuscript and the scaffold has not been run.

## Inputs and licences

KGBN (https://github.com/IlyaLab/KGBN) and PyBoolNet (https://github.com/hklarner/pyboolnet) are cloned at run time and are not redistributed. Check their licences and cite them. **Choose a licence for this repository before publishing it** (for example MIT or Apache-2.0 for code, CC-BY-4.0 for results and text); none has been chosen for you.

## How to get a DOI (GitHub + Zenodo)

1. Create a GitHub repository and push this folder (`.gitignore` excludes cloned repositories and run outputs).
2. Add a `LICENSE` file; fill in the commented lines of `CITATION.cff`.
3. Log in to https://zenodo.org with GitHub, open *Account, GitHub*, switch the repository on.
4. Create a GitHub Release (for example `v1.0.0`); Zenodo archives it.
5. Put the DOI into `CITATION.cff`, this README and the manuscript's availability statement.
6. After acceptance, make a new release instead of editing the old one.
