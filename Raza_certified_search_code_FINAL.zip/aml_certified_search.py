#!/usr/bin/env python3
"""
aml_certified_search.py
=======================
Single-file code release for:
  "Certified search for combination interventions in stochastic gene-network models,
   with a robust super-additive prediction in acute myeloid leukemia"

Every table and figure in the manuscript is produced by this file. The code in each stage is
identical to the code that generated the reported results (it was assembled from the analysis
notebooks); nothing was re-written for the release.

USAGE
-----
  python aml_certified_search.py --list
  python aml_certified_search.py --stages all                      # everything (about 50 min, one CPU core)
  python aml_certified_search.py --stages C_druggable,D_extended   # selected stages
  python aml_certified_search.py --stages C_benchmark --full       # regenerate the whole benchmark (about 1.5 h)

STAGES (run in this order)
--------------------------
  B_pbn          Part B: headline PBN re-evaluation (untreated baseline, additivity null, size-matched null, stability, genotype strata, alternative calibrations, rule noise)
  B_tbs          Part B: validation of the topological score on three networks
  B_conformal    Part B: patient-level uncertainty on real BeatAML and FPMTB data
  B_calib        Part B: calibration quality and combination-benchmark scaffold
  B_manifest     Part B: results manifest
  C_benchmark    Part C: pre-specified benchmark, criteria check, untreated baselines
  C_druggable    Part C: certified search over druggable combinations and 15-calibration stress test
  E_robust       Revision: clamping-policy comparison, Bliss null, per-calibration search, structural sensitivity, strict-delta cost, hard audit, LUCB
  E_mechanism    Revision: marker-level decomposition of the triplet in the reference network and after removing STAT5A inputs
  C_figures      Part C: figures and manifest
  D_extended     Part D: guarantee audit, cost sensitivity, bound ablation, scaling, noise, genotype, mechanism
  D_figures      Part D: figures
  F_validation   Retrospective out-of-sample check of the calibrated model on held-out public data (no new data, no lab work)
  G_decoy        Decoy drug-target maps and single-gene loss-of-function checks of the triplet (computational null tests)
  H_pools        Revision 9: simulate fixed reward pools (92 druggable sets, 833 three-gene sets) for the method comparison
  H_methods      Revision 9: certified search against LUCB and UGapE with the same radius, ablations, matched-budget baselines, controlled gap-structure test
  H_batch        Revision 10: batch-parallel LUCB against certified search on elapsed time
  I_theory       Revision 10: numerical check of the explicit sample-complexity bound and radius inequality; pooled replay guarantee
  I_drugcomb     Revision 10: model-predicted pair synergy against a DrugComb export (set DRUGCOMB_CSV); analysis fixed in advance
  paper          Regenerate figures, numbers.tex and LaTeX tables used by the manuscript

NOTES
-----
* Inputs are public: github.com/IlyaLab/KGBN and github.com/hklarner/pyboolnet (cloned automatically).
* Seeds are fixed. Re-running a stage reproduces its results exactly on the same library versions.
* Stage C_benchmark without --full runs one quick repetition and reads the shipped full-run tables
  in ./shipped_results (copied into the results folder if absent). Use --full to regenerate them.
* The original three-layer pipeline from the first draft (topology, algebraic control, synthetic-patient
  conformal analysis) is kept only in the notebook for provenance; none of its results are used in the manuscript.
* Requirements: python>=3.9, numpy, scipy, pandas, matplotlib, scikit-learn, networkx, ripser, git.
"""
import os, sys, json, time, zlib, itertools, hashlib, glob, re, argparse, subprocess, shutil, warnings
warnings.filterwarnings('ignore')
import numpy as np, pandas as pd
import networkx as nx
from scipy.stats import spearmanr, kendalltau, rankdata, pearsonr, mannwhitneyu
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

STAGE_ORDER = ['B_pbn', 'B_tbs', 'B_conformal', 'B_calib', 'B_manifest', 'C_benchmark', 'C_druggable', 'E_robust', 'E_mechanism', 'C_figures', 'D_extended', 'D_figures', 'F_validation', 'G_decoy', 'H_pools', 'H_methods', 'H_batch', 'I_theory', 'I_drugcomb', 'paper']
ap = argparse.ArgumentParser(description='Reproduce all results of the certified-search manuscript.')
ap.add_argument('--stages', default='all', help='comma-separated stage names, or "all"')
ap.add_argument('--results', default='./results', help='folder for result tables and figures')
ap.add_argument('--paper-dir', default='./paper_build', help='folder for numbers.tex, tables and paper figures')
ap.add_argument('--full', action='store_true', help='regenerate the full benchmark instead of the quick check (stage C_benchmark)')
ap.add_argument('--list', action='store_true')
ap.add_argument('--aml-policy', default='strict', choices=['strict', 'legacy'],
                help='strict (default): AML output genes are never clamped and drug targets are not part of the reward; legacy: original 7-marker reward with every gene clampable')
ap.add_argument('--bench-plan', default='', help='extend the benchmark, "network:start:stop,...", e.g. aml_pbn_kgbn:0:10,calzone_cellfate:5:10')
ARGS, _ = ap.parse_known_args()
AML_POLICY = ARGS.aml_policy
AML_APOP = ('TP53', 'CDKN2A')
AML_SURV = ('MYC', 'CCND1', 'STAT5A') if AML_POLICY == 'strict' else ('BCL2', 'MYC', 'CCND1', 'AKT1', 'STAT5A')
AML_UNCLAMPABLE = ('NPM1', 'DNMT3A') + ((AML_APOP + AML_SURV) if AML_POLICY == 'strict' else ())
HEADP = 'pair: Midostaurin + Ibrutinib' if AML_POLICY == 'strict' else 'pair: Midostaurin + Venetoclax'   # best pair among the five calibrated drugs under the chosen policy
HEAD_LABEL = HEADP.replace('pair: ', '')
if ARGS.list:
    print('\n'.join(STAGE_ORDER)); sys.exit(0)
_sel = {s.strip() for s in ARGS.stages.split(',')}
def _run(name): return 'all' in _sel or name in _sel
_bad = _sel - set(STAGE_ORDER) - {'all'}
if _bad: sys.exit(f'unknown stage(s): {sorted(_bad)}; use --list')

IN_COLAB = False
FULL_RUN = bool(ARGS.full)
RESULTS_DIR = os.path.abspath(ARGS.results); PAPER_DIR = os.path.abspath(ARGS.paper_dir); PROJECT_DIR = os.path.dirname(RESULTS_DIR)
os.makedirs(RESULTS_DIR, exist_ok=True); os.makedirs(PAPER_DIR, exist_ok=True); OUT = RESULTS_DIR + '/'
_here = os.path.dirname(os.path.abspath(__file__)); _shipped = os.path.join(_here, 'shipped_results')
if os.path.isdir(_shipped):
    for _f in os.listdir(_shipped):
        if not os.path.exists(os.path.join(RESULTS_DIR, _f)): shutil.copy(os.path.join(_shipped, _f), RESULTS_DIR)
def ensure_repo(url, dest, commit=None):
    """Clone a public repository on first use. If `commit` is given, check out exactly that commit (falls back to the default branch with a warning)."""
    if os.path.exists(dest): return dest
    subprocess.run(['git', 'clone', '--depth', '1', url, dest], check=True)
    if commit:
        ok = subprocess.run(['git', '-C', dest, 'fetch', '--depth', '1', 'origin', commit]).returncode == 0 and subprocess.run(['git', '-C', dest, 'checkout', '-q', 'FETCH_HEAD']).returncode == 0
        if not ok: print(f'[warning] could not check out pinned commit {commit[:10]} of {url}; using the default branch', flush=True)
    return dest
# Commits of the public inputs used for the checks run in revision 8 (their last commits pre-date every run reported here).
KGBN_COMMIT = 'd200345fc2a6219cd302af2cad1bab5a350f3456'      # IlyaLab/KGBN, committed 2026-05-09
PYB_COMMIT = '3394310d07e3e25810a828d8da4f6d7241115113'       # hklarner/pyboolnet, committed 2026-01-08
KGBN_DIR = ensure_repo('https://github.com/IlyaLab/KGBN.git', os.path.join(_here, 'KGBN_repo'), KGBN_COMMIT)
PYB_DIR = ensure_repo('https://github.com/hklarner/pyboolnet.git', os.path.join(_here, 'pyboolnet_repo'), PYB_COMMIT)
R = KGBN_DIR + '/manuscript/'; BASE = PYB_DIR + '/pyboolnet/repository/'
REF = R + 'optimization_results/BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW/pbn.txt'
KGBN_LOCAL_DIR = KGBN_DIR
print(f'results -> {RESULTS_DIR} | stages: {sorted(_sel)} | full benchmark: {FULL_RUN}', flush=True)

# =====================================================================================
# CORE: engine (exact Boolean-network maps, vectorised PBN) and certified search
# =====================================================================================
# Phase 6.1 — engine
import re, itertools, numpy as np, pandas as pd
from scipy import stats
from collections import defaultdict

def _vec_expr(expr):
    e = expr.strip().replace("!", "~")
    return compile(e, "<rule>", "eval")

# ---------- deterministic Boolean network, fully vectorised over all 2^n states ----------
class BoolNet:
    """Exact (STP-equivalent) representation: base_next[j] = index of successor of state j.
    Inhibition of a set T clamps bits of T to 0 AFTER the update, which is a bitwise AND
    with a mask, so every candidate's structure matrix L_T is obtained in O(2^n)."""
    def __init__(self, genes, rules=None, update_fn=None):
        self.genes = list(genes); self.n = len(genes)
        self.idx = {g: i for i, g in enumerate(genes)}
        N = 1 << self.n
        ar = np.arange(N, dtype=np.int64)
        self.bits = np.stack([((ar >> (self.n - 1 - i)) & 1).astype(bool) for i in range(self.n)], 1)  # N x n
        if rules is not None:
            env = {g: self.bits[:, i] for g, i in self.idx.items()}
            nxt = np.zeros(N, dtype=np.int64)
            for g in genes:
                v = eval(_vec_expr(rules[g]), {"__builtins__": {}}, env)
                nxt |= (np.asarray(v, dtype=bool).astype(np.int64) << (self.n - 1 - self.idx[g]))
            self.base_next = nxt
        else:
            self.base_next = np.array([self._s2i(update_fn(self._i2s(j))) for j in range(N)], dtype=np.int64)
    def _s2i(self, s):
        v = 0
        for b in s: v = (v << 1) | int(b)
        return v
    def _i2s(self, j): return tuple((j >> (self.n - 1 - i)) & 1 for i in range(self.n))
    def mask(self, inhibited):
        m = (1 << self.n) - 1
        for g in inhibited: m &= ~(1 << (self.n - 1 - self.idx[g]))
        return m
    def next_map(self, inhibited=frozenset()):
        return self.base_next & self.mask(inhibited)
    def start_indices(self, clamp_on=(), free_only=True):
        """all states with given genes = 1 (malignant basin)"""
        ok = np.ones(1 << self.n, dtype=bool)
        for g in clamp_on: ok &= self.bits[:, self.idx[g]]
        return np.nonzero(ok)[0]
    def final_states(self, inhibited, start, steps=60):
        nm = self.next_map(inhibited); cur = start.copy()
        for _ in range(steps): cur = nm[cur]
        return cur
    def ever_hits(self, inhibited, start, target_mask_fn, steps=40):
        nm = self.next_map(inhibited); cur = start.copy()
        hit = np.zeros(len(cur), bool)
        for _ in range(steps):
            cur = nm[cur]; hit |= target_mask_fn(cur)
        return hit, cur
    def trajectory(self, nm, s0, max_steps):
        traj = [int(s0)]; seen = {int(s0)}
        cur = int(s0)
        for _ in range(max_steps):
            cur = int(nm[cur]); traj.append(cur)
            if cur in seen: break
            seen.add(cur)
        return traj
    def gene_on(self, idx_arr, g): return self.bits[idx_arr, self.idx[g]]

def popcount(x):
    x = np.asarray(x, dtype=np.int64); c = np.zeros_like(x)
    while x.any():
        c += x & 1; x = x >> 1
    return c

def hamming_from_ints(states):
    a = np.asarray(states, dtype=np.int64)
    X = a[:, None] ^ a[None, :]
    return popcount(X).astype(float)

# ---------- topology + trivial trajectory statistics ----------
from ripser import ripser
def trajectory_features(bn, inhibited, seeds, max_steps=30, cloud_cap=400, rng=None):
    nm = bn.next_map(inhibited)
    cloud = []; lens = []; reach_att = []
    for s0 in seeds:
        tr = bn.trajectory(nm, s0, max_steps)
        cloud.extend(tr); lens.append(len(tr) - 1)
    cloud = list(dict.fromkeys(cloud))
    n_states = len(cloud)
    out = dict(n_states=n_states, mean_len=float(np.mean(lens)), max_len=float(np.max(lens)))
    if n_states < 3:
        out.update(TBS=0.0, H1_count=0, H0_total=0.0, diameter=0.0, mean_pair_dist=0.0, maxH1=0.0, entH1=0.0); return out
    if n_states > cloud_cap:
        rng = rng or np.random.default_rng(0)
        cloud = [cloud[i] for i in rng.choice(n_states, cloud_cap, replace=False)]
    D = hamming_from_ints(cloud)
    dg = ripser(D, distance_matrix=True, maxdim=1)["dgms"]
    h1 = dg[1] if len(dg) > 1 else np.zeros((0, 2)); h1 = h1[np.isfinite(h1[:, 1])]
    h0 = dg[0]; h0 = h0[np.isfinite(h0[:, 1])]
    out.update(TBS=float(np.sum(h1[:, 1] - h1[:, 0])) if len(h1) else 0.0, H1_count=int(len(h1)),
               H0_total=float(np.sum(h0[:, 1] - h0[:, 0])) if len(h0) else 0.0,
               maxH1=float(np.max(h1[:, 1] - h1[:, 0])) if len(h1) else 0.0,
               entH1=float(-np.sum((lambda l: (l/l.sum())*np.log(l/l.sum()))(h1[:, 1] - h1[:, 0]))) if len(h1) else 0.0,
               diameter=float(D.max()), mean_pair_dist=float(D[np.triu_indices_from(D, 1)].mean()))
    return out

# ---------- probabilistic Boolean network, vectorised over trials ----------
def parse_pbn(path):
    raw = defaultdict(list); order = []
    for line in open(path):
        line = line.strip()
        if not line or line.startswith("#"): continue
        lhs, rest = line.split("=", 1); g = lhs.strip()
        expr, prob = rest.rsplit(",", 1)
        if g not in order: order.append(g)
        raw[g].append((expr.strip(), float(prob)))
    return order, raw

class VecPBN:
    def __init__(self, path=None, genes=None, raw=None):
        if path is not None: genes, raw = parse_pbn(path)
        self.genes = list(genes); self.n = len(genes); self.idx = {g: i for i, g in enumerate(genes)}
        self.raw = raw
        self.rules = {}
        for g in genes:
            ex, pr = zip(*raw[g]); pr = np.array(pr, float); pr = pr / pr.sum()
            self.rules[g] = ([_vec_expr(e) for e in ex], np.cumsum(pr), pr)
    def with_probs(self, newprobs):
        raw = {g: [(e, p) for (e, _), p in zip(self.raw[g], newprobs[g])] for g in self.genes}
        return VecPBN(genes=self.genes, raw=raw)
    def step(self, S, clamp0, clamp1, rng):
        T = S.shape[0]
        env = {g: S[:, i] for g, i in self.idx.items()}
        out = np.empty_like(S)
        for g in self.genes:
            comp, cum, _ = self.rules[g]
            if len(comp) == 1:
                val = np.asarray(eval(comp[0], {"__builtins__": {}}, env), bool)
            else:
                u = rng.random(T); choice = (u[:, None] > cum[None, :-1]).sum(1)
                val = np.zeros(T, bool)
                for k, c in enumerate(comp):
                    v = np.asarray(eval(c, {"__builtins__": {}}, env), bool); val = np.where(choice == k, v, val)
            out[:, self.idx[g]] = val
        for g in clamp1: out[:, self.idx[g]] = True      # held mutation status
        for g in clamp0: out[:, self.idx[g]] = False     # drug clamp / wild-type hold wins last
        return out
    def init(self, T, rng, on=(), off=(), p=0.5):
        S = rng.random((T, self.n)) < p
        for g in on: S[:, self.idx[g]] = True
        for g in off: S[:, self.idx[g]] = False
        return S
    def run(self, T, inhibited, rng, steps=40, on=("FLT3", "NPM1"), off=(), hold_on=(), hold_off=(), p=0.5, record=False):
        """inhibited: clamped to 0 every step (drug). hold_on/hold_off: driver mutation status held every step."""
        S = self.init(T, rng, on=tuple(on) + tuple(hold_on), off=tuple(off) + tuple(hold_off), p=p)
        traj = [S.copy()] if record else None
        for _ in range(steps):
            S = self.step(S, list(inhibited) + list(hold_off), list(hold_on), rng)
            if record: traj.append(S.copy())
        return (S, traj) if record else S

def marker_scores(P, S, apop=AML_APOP, surv=AML_SURV):
    ap = np.stack([S[:, P.idx[g]] for g in apop], 1); sv = np.stack([~S[:, P.idx[g]] for g in surv], 1)
    ok = np.concatenate([ap, sv], 1)
    return ok.mean(1), ok.all(1)
def marker_matrix(P, S, apop=AML_APOP, surv=AML_SURV):
    """(trials x markers) boolean matrix: is each output marker in its desired state?"""
    return np.concatenate([np.stack([S[:, P.idx[g]] for g in apop], 1), np.stack([~S[:, P.idx[g]] for g in surv], 1)], 1)

def bool_rows_to_int(S):
    w = (1 << np.arange(S.shape[1] - 1, -1, -1, dtype=object))
    return [int(x) for x in (S.astype(object) @ w)]
def pbn_features(P, inhibited, rng, n_seeds=30, steps=12, cloud_cap=300, on=("FLT3","NPM1")):
    S, traj = P.run(n_seeds, inhibited, rng, steps=steps, on=on, record=True)
    allS = np.concatenate(traj, 0)
    ints = list(dict.fromkeys(bool_rows_to_int(allS)))
    n_states = len(ints); lens = steps
    if n_states > cloud_cap: ints = [ints[i] for i in rng.choice(n_states, cloud_cap, replace=False)]
    D = hamming_from_ints(ints)
    dg = ripser(D, distance_matrix=True, maxdim=1)["dgms"]
    h1 = dg[1]; h1 = h1[np.isfinite(h1[:, 1])]; h0 = dg[0]; h0 = h0[np.isfinite(h0[:, 1])]
    pers = h1[:, 1] - h1[:, 0] if len(h1) else np.zeros(0)
    return dict(TBS=float(pers.sum()), H1_count=int(len(pers)), maxH1=float(pers.max()) if len(pers) else 0.0,
                H0_total=float(np.sum(h0[:, 1] - h0[:, 0])), n_states=n_states, mean_pair_dist=float(D[np.triu_indices_from(D,1)].mean()))


import numpy as np, pandas as pd
EPS, DELTA, M_BATCH, CAP = 0.02, 0.05, 100, 40000
class BoolNoisy:
    """Published Boolean model (pyboolnet repository) with per-node update noise p (Boolean network with perturbations)."""
    def __init__(self, name, spec, pnoise=0.02, steps=50):
        self.name = name; self.pn = pnoise; self.steps = steps; rows = []
        for l in open(BASE + f'{name}/{name}.bnet'):
            l = l.strip()
            if not l or l.startswith('#') or l.lower().startswith('targets'): continue
            a, b = l.split(',', 1); rows.append((a.strip(), b.strip()))
        self.nodes = [a for a, _ in rows]; self.n = len(self.nodes); self.idx = {g: i for i, g in enumerate(self.nodes)}
        tok = re.compile(r'[A-Za-z0-9_]+')
        def tr(e):
            e = tok.sub(lambda m: f'v{self.idx[m.group(0)]}' if m.group(0) in self.idx else ('T' if m.group(0) == '1' else 'F' if m.group(0) == '0' else m.group(0)), e)
            return compile(e.replace('!', '~'), 'r', 'eval')
        self.code = [tr(b) for _, b in rows]
        self.on = [self.idx[g] for g in spec['ON']]; self.off = [self.idx[g] for g in spec['OFF']]
        self.targets = [g for g in self.nodes if g not in spec['ON'] + spec['OFF']]; self.kmax = spec['max_set_size']
    def sim(self, clamp, rng):
        T = clamp.shape[0]; Cm = np.ascontiguousarray(clamp.T); S = rng.random((self.n, T)) < 0.5
        F = np.zeros(T, bool); Tr = np.ones(T, bool)
        for _ in range(self.steps):
            env = {f'v{i}': S[i] for i in range(self.n)}; env['F'] = F; env['T'] = Tr; out = np.empty_like(S)
            for i, c in enumerate(self.code): out[i] = np.broadcast_to(np.asarray(eval(c, {"__builtins__": {}}, env), bool), (T,))
            out ^= rng.random((self.n, T)) < self.pn; out[Cm] = False; S = out
        ok = np.concatenate([S[self.on], ~S[self.off]], 0); return ok.mean(0)
class AMLNet:
    """BeatAML-calibrated 24-gene PBN (KGBN).
    Reward = fraction of the output markers in their desired state at t = 40.
    Policy 'strict' (default): the output genes (TP53, CDKN2A on; MYC, CCND1, STAT5A off) are never clamped and the drug targets
    BCL2 and AKT1 are not part of the reward, so a drug acts only through network dynamics.
    Policy 'legacy': the original 7-marker reward (BCL2 and AKT1 included) with every gene clampable."""
    hold_on = (); hold_off = (); detail = False
    def __init__(self, path=REF):
        self.P = VecPBN(path); self.name = 'aml_pbn_kgbn'; self.nodes = self.P.genes; self.n = self.P.n; self.idx = self.P.idx
        self.targets = [g for g in self.P.genes if g not in AML_UNCLAMPABLE]; self.kmax = 3
        self.ON = [self.idx['FLT3'], self.idx['NPM1']]; self.apop = [self.idx[g] for g in AML_APOP]; self.surv = [self.idx[g] for g in AML_SURV]
        self.marker_names = [f'{g} on' for g in AML_APOP] + [f'{g} off' for g in AML_SURV]
    def sim(self, clamp, rng, steps=40, p=0.5):
        P = self.P; T = clamp.shape[0]; S = rng.random((T, P.n)) < p; S[:, self.ON] = True
        ho = [P.idx[g] for g in self.hold_on]; hf = [P.idx[g] for g in self.hold_off]
        if ho: S[:, ho] = True
        if hf: S[:, hf] = False
        for _ in range(steps):
            env = {g: S[:, i] for g, i in P.idx.items()}; out = np.empty_like(S)
            for g in P.genes:
                comp, cum, _ = P.rules[g]
                if len(comp) == 1: val = np.asarray(eval(comp[0], {"__builtins__": {}}, env), bool)
                else:
                    u = rng.random(T); ch = (u[:, None] > cum[None, :-1]).sum(1); val = np.zeros(T, bool)
                    for k, c in enumerate(comp): val = np.where(ch == k, np.asarray(eval(c, {"__builtins__": {}}, env), bool), val)
                out[:, P.idx[g]] = val
            if ho: out[:, ho] = True
            out[clamp] = False
            if hf: out[:, hf] = False
            S = out
        mk = np.concatenate([S[:, self.apop], ~S[:, self.surv]], 1)
        return mk if self.detail else mk.mean(1)

class Problem:
    """Finite family of interventions. units=None: every set of <=kmax target nodes. units={drug: [genes]}: every set of <=kmax drugs."""
    def __init__(self, net, units=None, kmax=None):
        self.net = net; self.units = units; names = list(units) if units else net.targets; kmax = kmax or net.kmax
        self.arms = [c for k in range(1, kmax + 1) for c in itertools.combinations(names, k)]; self.K = len(self.arms)
        self.M = np.zeros((self.K, net.n), bool)
        for i, c in enumerate(self.arms):
            for u in c:
                for g in (units[u] if units else [u]): self.M[i, net.idx[g]] = True
        self.lookup = {frozenset(c): i for i, c in enumerate(self.arms)}
    def draw(self, ids, m, rng, chunk=100000):
        cl = np.repeat(self.M[np.asarray(ids)], m, axis=0); res = np.empty(len(cl))
        for a in range(0, len(cl), chunk): res[a:a + chunk] = self.net.sim(cl[a:a + chunk], rng)
        return res.reshape(len(ids), m)
def draw_detail(pr, ids, m, rng, chunk=100000):
    """Marker-level draws, shape (len(ids), m, n_markers); used for Bliss-independence expectations."""
    net = pr.net; net.detail = True
    try:
        cl = np.repeat(pr.M[np.asarray(ids)], m, axis=0)
        res = np.concatenate([net.sim(cl[a:a + chunk], rng) for a in range(0, len(cl), chunk)], 0)
    finally: net.detail = False
    return res.reshape(len(ids), m, -1)
def untreated_markers(net, n, seed):
    net.detail = True
    try: return net.sim(np.zeros((n, net.n), bool), np.random.default_rng(seed)).mean(0)
    finally: net.detail = False
def bliss_expected(u, singles):
    """Marker-level Bliss independence of fractional effects, averaged over markers. u: untreated marker probabilities; singles: list of single-component marker probabilities."""
    d = np.clip(1 - u, 1e-6, None); e = [(p - u) / d for p in singles]
    return float((u + d * (1 - np.prod([1 - x for x in e], axis=0))).mean())

def certified(pr, rng, eps=EPS, delta=DELTA, m=M_BATCH, cap=CAP, trace=None):
    """Successive elimination with empirical-Bernstein radii. Returns (arm, total simulations, certified?).
    Proven level: 1 - 2*delta (one-sided Maurer-Pontil constant ln(2/delta_t)); see THEORY document."""
    K = pr.K; n = np.zeros(K); s = np.zeros(K); ss = np.zeros(K); act = np.arange(K); t = 0; total = 0
    while True:
        t += 1; x = pr.draw(act, m, rng); n[act] += m; s[act] += x.sum(1); ss[act] += (x ** 2).sum(1); total += x.size
        nn = n[act]; mu = s[act] / nn; var = np.maximum(ss[act] / nn - mu ** 2, 0) * nn / np.maximum(nn - 1, 1)
        L = np.log(2 * K * t * (t + 1) / delta); r = np.sqrt(2 * var * L / np.maximum(nn - 1, 1)) + 7 * L / (3 * np.maximum(nn - 1, 1))
        lcb, ucb = mu - r, mu + r; b = int(np.argmax(mu)); oth = np.delete(ucb, b) if len(act) > 1 else np.array([-9.])
        cert = bool(len(act) == 1 or lcb[b] >= oth.max() - eps)
        if trace is not None: trace.append(dict(round=t, total=total, n_active=len(act), best_mean=float(mu[b]), best_lcb=float(lcb[b]), max_other_ucb=float(oth.max())))
        if cert or n[act].max() >= cap: return int(act[b]), total, cert
        act = act[ucb >= lcb.max()]
def uniform(pr, B, rng):
    m = max(int(B // pr.K), 1); return int(np.argmax(pr.draw(np.arange(pr.K), m, rng).mean(1))), m * pr.K
def succ_halving(pr, B, rng):
    act = np.arange(pr.K); Rr = int(np.ceil(np.log2(pr.K))); used = 0
    for r in range(Rr):
        if len(act) == 1: break
        m = max(int(B // (len(act) * Rr)), 1); mu = pr.draw(act, m, rng).mean(1); used += m * len(act)
        act = act[np.argsort(-mu)[:int(np.ceil(len(act) / 2))]]
    return int(act[0]), used
def greedy(pr, B, rng):
    N = len(pr.net.targets); kmax = pr.net.kmax; tot = sum(N - s for s in range(kmax)); m = max(int(B // tot), 1)
    cur = frozenset(); best = (None, -1); used = 0
    for s in range(kmax):
        cands = [cur | {g} for g in pr.net.targets if g not in cur]; ids = [pr.lookup[c] for c in cands]
        mu = pr.draw(ids, m, rng).mean(1); used += m * len(ids); j = int(np.argmax(mu)); cur = cands[j]
        if mu[j] > best[1]: best = (ids[j], mu[j])
    return best[0], used
print('certified search + baselines defined')


# C.3 — pre-registered protocol (criteria fixed in advance)
PREREG = {
 "title": "Pre-registered protocol: certified adaptive intervention search (written BEFORE running the corpus benchmark)",
 "date_written": "2026-10-31 session",
 "networks": {
  "calzone_cellfate": {
   "ON": [
    "Apoptosis"
   ],
   "OFF": [
    "Survival"
   ],
   "max_set_size": 3
  },
  "remy_tumorigenesis": {
   "ON": [
    "Apoptosis_high",
    "Growth_arrest"
   ],
   "OFF": [
    "Proliferation"
   ],
   "max_set_size": 3
  },
  "grieco_mapk": {
   "ON": [
    "Apoptosis",
    "Growth_Arrest"
   ],
   "OFF": [
    "Proliferation"
   ],
   "max_set_size": 2
  },
  "zhang_tlgl": {
   "ON": [
    "Apoptosis"
   ],
   "OFF": [
    "Proliferation"
   ],
   "max_set_size": 2
  },
  "aml_pbn_kgbn": {
   "ON": [
    "TP53",
    "CDKN2A"
   ],
   "OFF": [
    "BCL2",
    "MYC",
    "CCND1",
    "AKT1",
    "STAT5A"
   ],
   "max_set_size": 3
  }
 },
 "dynamics": "synchronous update; each node's update flipped independently with p=0.02 per step (Boolean network with perturbations) for the four pyboolnet models; fitted PBN rule sampling for AML; random uniform initial states; horizon 50 steps (40 for AML PBN); reward = fraction of output indicators satisfied at the final step, in [0,1]",
 "interventions": "clamp a set of non-output nodes to 0 after each update (inhibition), set size 1..max_set_size",
 "search": {
  "epsilon": 0.02,
  "delta": 0.05,
  "batch_per_round": 100,
  "bound": "empirical Bernstein (Maurer & Pontil), delta_t = delta/(K t (t+1)), stop when LCB(best) >= max UCB(others) - epsilon",
  "cap_per_arm": 40000
 },
 "truth": "all arms screened at n=2000; top 30 re-estimated at n=60000; truth_best = max of refined estimates",
 "baselines_budget_matched_to_each_certified_run": [
  "uniform allocation",
  "greedy forward selection",
  "fixed-budget successive halving"
 ],
 "repetitions": 5,
 "success_criteria_declared_in_advance": [
  "C1: certified search returns an epsilon-optimal arm in >= 95% of runs pooled over networks",
  "C2: simulation count at least 10x below the guaranteed-uniform bound ceil(ln(2K/delta)/(2 eps^2))*K in EVERY network",
  "C3: at matched budget, certified search success rate >= every uncertified baseline, pooled"
 ],
 "reporting_rule": "all networks and all runs are reported whether or not criteria are met; no network, objective or parameter is changed after seeing results"
}
SPEC = PREREG['networks']
json.dump(PREREG, open(OUT+'PREREGISTERED_protocol.json','w'), indent=1)
for c in PREREG['success_criteria_declared_in_advance']: print(' -', c)



# =====================================================================================
# STAGE B_pbn: Part B: headline PBN re-evaluation (untreated baseline, additivity null, size-matched null, stability, genotype strata, alternative calibrations, rule noise)
# =====================================================================================
if _run('B_pbn'):
    _t_stage = time.time()
    # Phase 6.2 — Setup + equivalence checks against the ORIGINAL (Part A) implementations
    import itertools, time, glob, hashlib
    import numpy as np, pandas as pd, networkx as nx
    from scipy.stats import spearmanr, kendalltau, rankdata
    R = KGBN_LOCAL_DIR + '/manuscript/'          # KGBN repo (cloned in Phase 5.1)
    OUT = RESULTS_DIR + '/'
    REF = R + 'optimization_results/BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW/pbn.txt'

    # (a) Palma network: vectorised successor map vs an independent eval-based update on 3,000 random states
    pal_genes, pal_rules = [], {}
    for line in open(R + 'inputs/Palma2021.txt'):
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        a, b_ = line.split('=', 1); pal_genes.append(a.strip()); pal_rules[a.strip()] = b_.strip()
    pal = BoolNet(pal_genes, rules=pal_rules)
    _idx = {g: i for i, g in enumerate(pal_genes)}
    _comp = {g: compile(pal_rules[g].replace('!', ' not ').replace('&', ' and ').replace('|', ' or ').strip(), 'x', 'eval') for g in pal_genes}
    def _orig_update(s):
        env = {g: bool(s[_idx[g]]) for g in pal_genes}
        return tuple(1 if eval(_comp[g], {"__builtins__": {}}, env) else 0 for g in pal_genes)
    _rng = np.random.default_rng(0); bad = 0
    for j in _rng.integers(0, 1 << pal.n, 3000):
        bad += int(pal._s2i(_orig_update(pal._i2s(int(j)))) != pal.base_next[j])
    print(f'Palma: vectorised vs original update — mismatches over 3,000 random states: {bad}')
    assert bad == 0
    # (b) PBN: vectorised simulator reproduces Part A's published estimate
    P = VecPBN(REF)
    S = P.run(26492, frozenset(['FLT3', 'KIT', 'BCL2']), np.random.default_rng(1), steps=40)
    sc, ok = marker_scores(P, S)
    print(f'Midostaurin+Venetoclax: vectorised n=26,492 partial={sc.mean()*100:.2f}%  strict={ok.mean()*100:.2f}%   (Part A n=300: 62.1%, strict ≤1.7%)')


    # Phase 7.0 — PBN setup (reference calibration = BeatAML Waves3+4)
    from scipy import stats
    REF=R+'optimization_results/BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW/pbn.txt'
    P=VecPBN(REF)
    T={"Venetoclax":{"BCL2"},"Ibrutinib":{"BTK"},"Entospletinib":{"SYK"},"Selumetinib":{"MAP2K1","MAP2K2"},"Midostaurin":{"FLT3","KIT"}}
    cands={"untreated":frozenset()}
    for k,v in T.items(): cands["single: "+k]=frozenset(v)
    for a,b in [("Midostaurin","Venetoclax"),("Midostaurin","Ibrutinib"),("Midostaurin","Entospletinib"),("Midostaurin","Selumetinib"),("Ibrutinib","Venetoclax")]:
        cands[f"pair: {a} + {b}"]=frozenset(T[a]|T[b])
    def run_score(cs, n, seed, steps=40, **kw):
        S=P.run(n, cs, np.random.default_rng(seed), steps=steps, **kw); return marker_scores(P,S)
    res={}

    # Phase 7.1 — untreated baseline, Hoeffding-sized ranking, additivity / HSA synergy nulls
    # 1. reference ranking at n=26492 (Hoeffding eps=0.01, delta=0.01)
    eps,delta=0.01,0.01; nH=int(np.ceil(np.log(2/delta)/(2*eps**2))); print('Hoeffding n',nH)
    rows=[]; per={}
    for name,cs in cands.items():
        sc,ok=run_score(cs,nH,123); per[name]=sc
        rows.append(dict(candidate=name,n_targets=len(cs),partial=sc.mean()*100,sd=sc.std(ddof=1)*100,strict=ok.mean()*100))
    dfH=pd.DataFrame(rows).sort_values('partial',ascending=False).reset_index(drop=True); print(dfH.round(2).to_string())
    dfH.to_csv(OUT+'pbn_hoeffding_ranking.csv',index=False)
    # 2. synergy vs additivity / HSA using paired bootstrap on same-n runs
    s0=per['untreated']
    def eff(name): return per[name]
    syn=[]
    for a,b in [("Midostaurin","Venetoclax"),("Midostaurin","Ibrutinib"),("Midostaurin","Entospletinib"),("Midostaurin","Selumetinib"),("Ibrutinib","Venetoclax")]:
        A,B,AB=per["single: "+a].mean(),per["single: "+b].mean(),per[f"pair: {a} + {b}"].mean(); S0=s0.mean()
        add=S0+(A-S0)+(B-S0); hsa=max(A,B)
        # uncertainty via independent MC replicate batches
        ex=[];hs=[]
        for r in range(30):
            m=lambda cs: run_score(cs,3000,5000+r)[0].mean()
            a0=m(frozenset()); aA=m(frozenset(T[a])); aB=m(frozenset(T[b])); aAB=m(frozenset(T[a]|T[b]))
            ex.append(aAB-(a0+(aA-a0)+(aB-a0))); hs.append(aAB-max(aA,aB))
        syn.append(dict(pair=f"{a} + {b}",untreated=S0*100,single_A=A*100,single_B=B*100,observed=AB*100,additive_expected=add*100,
           excess_over_additive_pp=(AB-add)*100,excess_mean_rep_pp=np.mean(ex)*100,excess_sd_rep_pp=np.std(ex,ddof=1)*100,
           excess_over_HSA_pp=(AB-hsa)*100,hsa_mean_rep_pp=np.mean(hs)*100,hsa_sd_rep_pp=np.std(hs,ddof=1)*100))
    dfS=pd.DataFrame(syn); print(dfS.round(2).to_string()); dfS.to_csv(OUT+'pbn_synergy_additivity.csv',index=False)
    # 7.1b — Bliss independence at the marker level (added in revision)
    def _mmeans(cs, n=26492, seed=123): return marker_matrix(P, P.run(n, cs, np.random.default_rng(seed), steps=40)).mean(0)
    _u = _mmeans(frozenset()); _mm = {k: _mmeans(frozenset(v)) for k, v in T.items()}; _rows = []
    for _a, _b in [("Midostaurin","Venetoclax"),("Midostaurin","Ibrutinib"),("Midostaurin","Entospletinib"),("Midostaurin","Selumetinib"),("Ibrutinib","Venetoclax")]:
        _ab = _mmeans(frozenset(T[_a] | T[_b])); _bl = bliss_expected(_u, [_mm[_a], _mm[_b]]); _lin = _u.mean() + (_mm[_a].mean() - _u.mean()) + (_mm[_b].mean() - _u.mean())
        _rows.append(dict(pair=f"{_a} + {_b}", observed=_ab.mean()*100, linear_additive=_lin*100, bliss_expected=_bl*100, excess_linear_pp=(_ab.mean()-_lin)*100, excess_bliss_pp=(_ab.mean()-_bl)*100))
    dfBl = pd.DataFrame(_rows); dfBl.to_csv(OUT+'pbn_synergy_bliss.csv', index=False); print(dfBl.round(2).to_string(index=False))

    # Phase 7.2 — all 1/2/3-gene clamp sets (n=1,500 trials each)

    genes_all=[g for g in P.genes if g not in AML_UNCLAMPABLE]   # root mutations and (strict policy) output genes are not clampable
    print(len(genes_all),'targetable genes')
    # ---- A. exhaustive null: all 1,2,3-gene clamp sets (size-matched comparison), n=1500 each
    t=time.time(); rows=[]
    for k in (1,2,3):
        for combo in itertools.combinations(genes_all,k):
            sc,ok=run_score(frozenset(combo),1500,zlib.crc32("+".join(combo).encode())%10**6)
            rows.append(dict(genes="+".join(combo),k=k,partial=sc.mean()*100,strict=ok.mean()*100))
    dfN=pd.DataFrame(rows); dfN.to_csv(OUT+'pbn_all_clamp_sets.csv',index=False); print('exhaustive sets',len(dfN),time.time()-t)
    mv=cands[HEADP]; mvk=len(mv)
    ref=dfH_ref=pd.read_csv(OUT+'pbn_hoeffding_ranking.csv').set_index('candidate')
    for k in (1,2,3):
        d=dfN[dfN.k==k].sort_values('partial',ascending=False)
        print(f'k={k}: n={len(d)}  top5:'); print(d.head(5).round(1).to_string(index=False))
    d3=dfN[dfN.k==3]; v=ref.loc[HEADP,'partial']
    print('Mido+Ven (3 genes) percentile among all size-3 sets: %.1f%%  rank %d/%d'%((d3.partial<v).mean()*100,(d3.partial>v).sum()+1,len(d3)))
    # FLT3+KIT+BCL2 sets in null

    # Phase 7.3a — rank stability across independent MC batches
    names=[c for c in cands if c!='untreated']
    # ---- B. ranking stability across independent MC batches (n=300 as in paper, and n=1000)
    for n in (300,1000):
        names=[c for c in cands if c!='untreated']; wins={c:0 for c in names}; ranks={c:[] for c in names}
        for r in range(200):
            m={c:run_score(cands[c],n,90000+r*37)[0].mean() for c in names}
            order=sorted(names,key=lambda c:-m[c])
            wins[order[0]]+=1
            for i,c in enumerate(order): ranks[c].append(i+1)
        st=pd.DataFrame([dict(candidate=c,n=n,top1_freq=wins[c]/200,mean_rank=np.mean(ranks[c]),rank_sd=np.std(ranks[c])) for c in names]).sort_values('mean_rank')
        st.to_csv(OUT+f'pbn_rank_stability_n{n}.csv',index=False); print(st.round(3).to_string(index=False))


    # Phase 7.3b — effect sizes vs the top pair (trial-level, n=26,492)
    from scipy.stats import mannwhitneyu
    # ---- C. effect sizes (Cohen d, prob of superiority) vs top, from n=26492 trial-level scores
    S1=run_score(cands[HEADP],26492,777)[0]
    es=[]
    for c in cands:
        if c in("untreated",HEADP):continue
        X=run_score(cands[c],26492,888+len(c))[0]
        d=(S1.mean()-X.mean())/np.sqrt((S1.var(ddof=1)+X.var(ddof=1))/2)
        from scipy.stats import mannwhitneyu
        u=mannwhitneyu(S1,X,alternative='two-sided').statistic/(len(S1)*len(X))
        es.append(dict(vs=c,diff_pp=(S1.mean()-X.mean())*100,cohen_d=d,prob_superiority=u))
    dfE=pd.DataFrame(es).sort_values('cohen_d'); dfE.to_csv(OUT+'pbn_effect_sizes.csv',index=False); print(dfE.round(3).to_string(index=False))


    # Phase 7.4a — genotype strata (mutation status held every step)
    # ---- A. genotype strata (mutation status HELD constant each step)
    rows=[]
    for f,n_,d in itertools.product([1,0],[1,0],[1,0]):
        on=[g for g,v in zip(["FLT3","NPM1","DNMT3A"],[f,n_,d]) if v]; off=[g for g,v in zip(["FLT3","NPM1","DNMT3A"],[f,n_,d]) if not v]
        sc={c:run_score(cands[c],4000,31337,hold_on=on,hold_off=off)[0].mean()*100 for c in cands}
        top=max(names,key=lambda c:sc[c]); order=sorted(names,key=lambda c:-sc[c])
        rows.append(dict(FLT3=f,NPM1=n_,DNMT3A=d,untreated=sc['untreated'],Head=sc[HEADP],top=top,top_score=sc[top],rank_Head=order.index(HEADP)+1,
                         best_single=max([c for c in names if c.startswith('single')],key=lambda c:sc[c])))
    dfG=pd.DataFrame(rows); dfG.to_csv(OUT+'pbn_genotype_strata.csv',index=False); print(dfG.round(1).to_string(index=False))

    # Phase 7.4b — time-horizon and initial-density sensitivity
    # ---- B. horizon and initial-condition sensitivity (drivers free as in manuscript)
    rows=[]
    for steps in (10,20,40,80,160):
        for p in (0.5,0.2,0.8):
            sc={c:run_score(cands[c],4000,555,steps=steps,p=p)[0].mean() for c in names}
            order=sorted(names,key=lambda c:-sc[c]); rows.append(dict(steps=steps,p_init=p,top=order[0],Head_rank=order.index(HEADP)+1,second=order[1]))
    dfT=pd.DataFrame(rows); dfT.to_csv(OUT+'pbn_horizon_init_sensitivity.csv',index=False); print(dfT.to_string(index=False))

    # Phase 7.4c — class-level test: FLT3-only vs FLT3+KIT (midostaurin)
    # ---- C. class-level: FLT3-only (gilteritinib/quizartinib-like) vs FLT3+KIT (midostaurin)
    cl={"Mido(FLT3+KIT)+Ibr":{"FLT3","KIT","BTK"},"FLT3-only(gilteritinib-like)+Ibr":{"FLT3","BTK"},"KIT-only+Ibr":{"KIT","BTK"},"Ibr alone":{"BTK"},"Mido(FLT3+KIT)+Ven":{"FLT3","KIT","BCL2"},"FLT3-only(gilteritinib-like)+Ven":{"FLT3","BCL2"},"KIT-only+Ven":{"KIT","BCL2"},"Ven alone":{"BCL2"},"FLT3-only alone":{"FLT3"},"FLT3-only+Ven+Ibrutinib":{"FLT3","BCL2","BTK"}}
    rows=[]
    for k,v in cl.items():
        sc,ok=run_score(frozenset(v),26492,2024); rows.append(dict(candidate=k,partial=sc.mean()*100,sd=sc.std(ddof=1)*100,strict=ok.mean()*100))
    dfC=pd.DataFrame(rows); dfC.to_csv(OUT+'pbn_class_level_flt3.csv',index=False); print(dfC.round(2).to_string(index=False))

    # Phase 7.5a — alternative calibrated PBNs (independent calibrations)
    from scipy.stats import kendalltau
    # ---- D. alternative calibrated PBNs from the KGBN repo (different data splits / cohorts), same 24 genes
    files=sorted(set(glob.glob(R+'optimization_results/**/pbn.txt',recursive=True)))
    files=[REF]+[f for f in files if f!=REF]
    alts=[]; _seen=set()
    for f in files:
        try: g,_=parse_pbn(f)
        except Exception as e: continue
        h=hashlib.md5(open(f,'rb').read()).hexdigest()
        if set(g)==set(P.genes) and 'Test_Evaluation' not in f and h not in _seen: _seen.add(h); alts.append(f)
    print(len(files),'pbn files;',len(alts),'DISTINCT calibrations with the identical 24-gene set')
    rows=[]; ranks={}
    for f in alts:
        Q=VecPBN(f); lab=f.split('optimization_results/')[1].replace('/pbn.txt','')
        sc={}
        for c in names: S=Q.run(4000,cands[c],np.random.default_rng(1),steps=40); sc[c]=marker_scores(Q,S)[0].mean()*100
        order=sorted(names,key=lambda c:-sc[c]); ranks[lab]=[order.index(c)+1 for c in names]
        rows.append(dict(model=lab,top=order[0],Head_rank=order.index(HEADP)+1,Head=sc[HEADP],untreated=marker_scores(Q,Q.run(4000,frozenset(),np.random.default_rng(1)))[0].mean()*100))
    dfA=pd.DataFrame(rows)
    from scipy.stats import kendalltau
    refr=ranks['BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW']
    dfA['kendall_tau_vs_reference']=[kendalltau(refr,ranks[m])[0] for m in dfA.model]
    dfA.to_csv(OUT+'pbn_alternative_calibrations.csv',index=False); print(dfA.round(3).to_string(index=False))

    # Phase 7.5b — rule-probability perturbation
    # ---- E. parametric perturbation of rule probabilities (Dirichlet around fitted values)
    rows=[]; rng=np.random.default_rng(11)
    for kappa in (200,50,20,10):
        wins=0; mr=[]; taus=[]
        for r in range(100):
            newp={g:rng.dirichlet(np.maximum(P.rules[g][2]*kappa,1e-3)) if len(P.rules[g][2])>1 else P.rules[g][2] for g in P.genes}
            Q=P.with_probs(newp); sc={c:marker_scores(Q,Q.run(1500,cands[c],rng,steps=40))[0].mean() for c in names}
            order=sorted(names,key=lambda c:-sc[c]); wins+=order[0]==HEADP; mr.append(order.index(HEADP)+1)
            taus.append(kendalltau(refr,[order.index(c)+1 for c in names])[0])
        rows.append(dict(kappa=kappa,top1_freq=wins/100,mean_rank=np.mean(mr),worst_rank=max(mr),mean_tau=np.mean(taus)))
    dfP=pd.DataFrame(rows); dfP.to_csv(OUT+'pbn_rule_prob_perturbation.csv',index=False); print(dfP.round(3).to_string(index=False))

    print('[stage B_pbn finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE B_tbs: Part B: validation of the topological score on three networks
# =====================================================================================
if _run('B_tbs'):
    _t_stage = time.time()
    # Phase 8.0 — pilot network, candidate universe (66 sets), static heuristic
    import itertools, numpy as np, pandas as pd, networkx as nx, time
    from scipy.stats import spearmanr, kendalltau
    # ================= PILOT NETWORK (identical rules to the notebook) =================
    GENES=["FLT3","NPM1","PI3K","AKT","STAT5","MYC","BCL2","NFKB","DNMT3A","TP53","BAX","CASP3","MDM2"]; IDX={g:i for i,g in enumerate(GENES)}
    def update(state):
        s={g:state[IDX[g]] for g in GENES}; n={}
        n["FLT3"]=s["FLT3"]; n["NPM1"]=s["NPM1"]; n["DNMT3A"]=s["DNMT3A"]
        n["PI3K"]=1 if (s["FLT3"] or s["NPM1"]) else 0; n["AKT"]=1 if s["PI3K"] else 0; n["STAT5"]=1 if s["FLT3"] else 0
        n["MYC"]=1 if (s["AKT"] or s["STAT5"]) else 0
        n["BCL2"]=1 if ((s["AKT"] or s["STAT5"]) and not s["CASP3"]) else 0
        n["NFKB"]=1 if (s["AKT"] and s["DNMT3A"]) else 0; n["MDM2"]=1 if (s["AKT"] or s["NFKB"]) else 0
        n["TP53"]=1 if not s["MDM2"] else 0; n["BAX"]=1 if (s["TP53"] and not s["BCL2"]) else 0; n["CASP3"]=1 if (s["BAX"] and not s["BCL2"]) else 0
        return tuple(n[g] for g in GENES)
    pil=BoolNet(GENES,update_fn=update)
    DEP=[("FLT3","PI3K"),("NPM1","PI3K"),("PI3K","AKT"),("FLT3","STAT5"),("AKT","MYC"),("STAT5","MYC"),("AKT","BCL2"),("STAT5","BCL2"),("CASP3","BCL2"),("AKT","NFKB"),("DNMT3A","NFKB"),("AKT","MDM2"),("NFKB","MDM2"),("MDM2","TP53"),("TP53","BAX"),("BCL2","BAX"),("BAX","CASP3"),("BCL2","CASP3")]
    G=nx.DiGraph(); G.add_nodes_from(GENES); G.add_edges_from(DEP); TRACK={"MYC","BCL2","NFKB","MDM2","TP53","BAX","CASP3"}
    def struct_score(cs,drivers=("FLT3","NPM1"),graph=G,track=TRACK):
        Gc=graph.copy(); Gc.remove_nodes_from(cs); reach=set()
        for d in drivers:
            if d in Gc: reach|=nx.descendants(Gc,d)
        tr=track-set(cs); return 100*len(tr-reach)/max(len(tr),1)
    def seeds_pilot(rng,n=40):
        out=[]
        for _ in range(n):
            s=list(rng.integers(0,2,size=pil.n)); s[0]=1; s[1]=1; out.append(pil._s2i(s))
        return out
    basin=pil.start_indices(("FLT3","NPM1"))
    ap=[pil.idx[g] for g in("TP53","BAX","CASP3")]; bc=pil.idx["BCL2"]
    def apop_state(idxs):
        b=pil.bits[idxs]; return b[:,ap[0]]&b[:,ap[1]]&b[:,ap[2]]&(~b[:,bc])
    MARK=["TP53","BAX","CASP3","BCL2","AKT","MDM2","NFKB"]; DES=[1,1,1,0,0,0,0]
    def func_score(idxs): b=pil.bits[idxs]; return np.mean([(b[:,pil.idx[g]]==d) for g,d in zip(MARK,DES)],0)
    drug_genes=[g for g in GENES if g not in("NPM1","DNMT3A")]
    cand={}
    for k in (1,2):
        for c in itertools.combinations(drug_genes,k): cand["("+", ".join(c)+")"]=frozenset(c)
    print('pilot candidates',len(cand))

    # Phase 8.1 — exact ground truth vs TBS and trivial statistics; test–retest
    # exact layer 2 (matches notebook definition: ever visits apoptotic state within 40 steps)
    rows=[]
    for name,cs in cand.items():
        hit,fin=pil.ever_hits(cs,basin,apop_state,steps=40)
        rows.append(dict(candidate=name,exact_conv=hit.mean()*100,exact_func=func_score(fin).mean()*100,struct=struct_score(cs)))
    ex=pd.DataFrame(rows)
    # TBS + trivial features on the canonical seed set (replicates paper)
    feat=[]
    canon=seeds_pilot(np.random.default_rng(0))
    for name,cs in cand.items():
        f=trajectory_features(pil,cs,canon,max_steps=30); f['candidate']=name; feat.append(f)
    F=pd.DataFrame(feat).merge(ex,on='candidate'); F.to_csv(OUT+'pilot_all_candidates_features.csv',index=False)
    print(F[F.candidate.isin(["(STAT5, BCL2)","(AKT, BCL2)","(BCL2)","(FLT3, BCL2)","(STAT5)","(FLT3)"])][['candidate','TBS','exact_conv']])
    def corr_table(F,target,label):
        rows=[]
        for c in ['TBS','H1_count','H0_total','n_states','mean_len','max_len','diameter','mean_pair_dist','struct']:
            r,p=spearmanr(F[c],F[target]); rows.append(dict(network=label,target=target,feature=c,spearman=r,p=p))
        rng=np.random.default_rng(0); null=[spearmanr(rng.permutation(F[target].values),F[target])[0] for _ in range(2000)]
        rows.append(dict(network=label,target=target,feature='RANDOM (permutation null 97.5th pct |rho|)',spearman=np.percentile(np.abs(null),95),p=np.nan))
        return pd.DataFrame(rows)
    C1=pd.concat([corr_table(F,'exact_conv','pilot (13 genes, 66 candidates)'),corr_table(F,'exact_func','pilot (13 genes, 66 candidates)')])
    print(C1.round(3).to_string(index=False))
    # partial correlation of TBS with exact_conv controlling for cloud size (rank-based)
    def partial_rank(x,y,z):
        from scipy.stats import rankdata
        rx,ry,rz=rankdata(x),rankdata(y),rankdata(z)
        bx=np.polyfit(rz,rx,1); by=np.polyfit(rz,ry,1)
        return np.corrcoef(rx-np.polyval(bx,rz),ry-np.polyval(by,rz))[0,1]
    print('partial rho TBS~exact_conv | n_states:',partial_rank(F.TBS,F.exact_conv,F.n_states))
    print('rho TBS~n_states:',spearmanr(F.TBS,F.n_states)[0])
    # test-retest and sensitivity to number of seeds
    rows=[]
    for ns in (10,20,40,80,160):
        mats=[]
        for r in range(20):
            sd=seeds_pilot(np.random.default_rng(1000+r),ns)
            mats.append([trajectory_features(pil,cs,sd,max_steps=30)['TBS'] for cs in cand.values()])
        M=np.array(mats); taus=[spearmanr(M[i],M[j])[0] for i in range(20) for j in range(i+1,20)]
        rho_ex=np.mean([spearmanr(M[i],F.exact_conv)[0] for i in range(20)])
        top=pd.Series([np.argmin(M[i]) for i in range(20)]).value_counts(normalize=True).max()
        cv=np.nanmean(M.std(0)/np.where(M.mean(0)>0,M.mean(0),np.nan))
        rows.append(dict(n_seeds=ns,test_retest_rho=np.mean(taus),mean_rho_with_exact=rho_ex,modal_argmin_freq=top,mean_CV=cv))
    T=pd.DataFrame(rows); T.to_csv(OUT+'pilot_tbs_stability.csv',index=False); print(T.round(3).to_string(index=False))
    # top-k hit rates: does the method's top-5 contain the exact optimum set?
    best=F.exact_conv.max(); opt=set(F[F.exact_conv==best].candidate); print('exact optimum candidates:',opt)
    def prec(col,asc,k=5):
        top=F.sort_values(col,ascending=asc).head(k).candidate; return len(set(top)&opt)
    print('top5 contains optimum -> TBS',prec('TBS',True),' struct',prec('struct',False),' mean_len',prec('mean_len',True),' n_states',prec('n_states',True))
    C1.to_csv(OUT+'tbs_validation_pilot_correlations.csv',index=False)

    # Phase 8.2 — size-normalised variants; real Palma network (136 sets, exact); PBN (253 sets, MC)
    from scipy.stats import spearmanr, rankdata

    def prho(x,y,z):
        rx,ry,rz=map(rankdata,(x,y,z)); bx=np.polyfit(rz,rx,1); by=np.polyfit(rz,ry,1)
        return np.corrcoef(rx-np.polyval(bx,rz),ry-np.polyval(by,rz))[0,1]
    def derived(F):
        F=F.copy(); F['TBS_per_state']=F.TBS/F.n_states.clip(lower=1); F['TBS_over_H0']=F.TBS/F.H0_total.replace(0,np.nan)
        z=np.column_stack([np.ones(len(F)),np.log1p(F.n_states),F.mean_len if 'mean_len' in F else np.zeros(len(F))])
        beta=np.linalg.lstsq(z,F.TBS.values,rcond=None)[0]; F['TBS_resid']=F.TBS.values-z@beta
        return F
    def table(F,target,label,ctrl):
        rows=[]
        for c in ['TBS','maxH1','H1_count','TBS_per_state','TBS_over_H0','TBS_resid','H0_total','n_states']+(['mean_len'] if 'mean_len' in F else [])+(['struct'] if 'struct' in F else []):
            v=F[c].fillna(0); r=spearmanr(v,F[target])[0]; pr=prho(v,F[target],F[ctrl]) if c!=ctrl else np.nan
            rows.append(dict(network=label,target=target,feature=c,spearman=r,partial_given_ctrl=pr))
        return pd.DataFrame(rows)
    tabs=[]
    # ---- pilot (re-use saved features, add maxH1/entH1/size-normalised variants)
    F=pd.read_csv(OUT+'pilot_all_candidates_features.csv')
    canon=seeds_pilot(np.random.default_rng(0))
    ext=[trajectory_features(pil,cs,canon,max_steps=30) for cs in cand.values()]
    F['maxH1']=[e['maxH1'] for e in ext]; F['entH1']=[e['entH1'] for e in ext]; F=derived(F)
    tabs+= [table(F,'exact_conv','pilot',  'mean_len'), table(F,'exact_func','pilot','mean_len')]
    # ---- Palma 18-gene real network, 136 candidates, exact continuous score over FLT3=1 basin
    def parse_bool(path):
        g,r=[],{}
        for line in open(path):
            line=line.strip()
            if not line or line.startswith('#') or '=' not in line: continue
            a,b=line.split('=',1); g.append(a.strip()); r[a.strip()]=b.strip()
        return g,r
    pg,pr=parse_bool(R+'inputs/Palma2021.txt'); pal=BoolNet(pg,rules=pr)
    APO=["TP53","CDKN2A"]; SUR=["BCL2","MYC","CCND1","AKT1","STAT5A"]
    basin=pal.start_indices(("FLT3",))
    def succ(i): b=pal.bits[i]; return np.all([b[:,pal.idx[g]] for g in APO],0)&np.all([~b[:,pal.idx[g]] for g in SUR],0)
    def part(i): b=pal.bits[i]; return np.mean([b[:,pal.idx[g]] for g in APO]+[~b[:,pal.idx[g]] for g in SUR],0)
    dg_=[g for g in pg if g not in("NPM1","DNMT3A")]
    pc={ "("+", ".join(c)+")":frozenset(c) for k in (1,2) for c in itertools.combinations(dg_,k)}
    rng=np.random.default_rng(0); seeds=[]
    for _ in range(40):
        s=list(rng.integers(0,2,size=pal.n)); s[pal.idx["FLT3"]]=1; seeds.append(pal._s2i(s))
    DEPP=nx.DiGraph(); DEPP.add_nodes_from(pg)
    import re
    for g,r in pr.items():
        for h in set(re.findall(r'[A-Za-z0-9]+',r)):
            if h in pal.idx: DEPP.add_edge(h,g)
    rows=[]; t=time.time()
    for name,cs in pc.items():
        hit,fin=pal.ever_hits(cs,basin,succ,steps=25)
        f=trajectory_features(pal,cs,seeds,max_steps=15)
        f.update(candidate=name,exact_conv=hit.mean()*100,exact_func=part(fin).mean()*100,struct=struct_score(cs,drivers=("FLT3","NPM1","DNMT3A"),graph=DEPP,track=set(APO+SUR)))
        rows.append(f)
    FP=derived(pd.DataFrame(rows)); FP.to_csv(OUT+'palma_all_candidates_features.csv',index=False); print('palma',len(FP),time.time()-t)
    tabs+=[table(FP,'exact_func','palma',  'mean_len'),table(FP,'exact_conv','palma','mean_len')]
    # ---- PBN: 253 clamp sets, MC partial score (n=1500, from exp) vs TBS & trivial features
    NS=pd.read_csv(OUT+'pbn_all_clamp_sets.csv'); NS=NS[NS.k<=2]
    P=VecPBN(R+'optimization_results/BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW/pbn.txt'); rr=np.random.default_rng(5); rows=[]
    for _,r in NS.iterrows():
        f=pbn_features(P,frozenset(r.genes.split('+')),rr); f['candidate']=r.genes; f['mc_partial']=r.partial; rows.append(f)
    FB=pd.DataFrame(rows); FB['mean_len']=0.0; FB=derived(FB); FB.to_csv(OUT+'pbn_all_candidates_features.csv',index=False)
    tabs.append(table(FB.drop(columns='mean_len'),'mc_partial','PBN (24 genes, 253 sets)','n_states'))
    T=pd.concat(tabs); T.to_csv(OUT+'tbs_validation_all_networks.csv',index=False)
    pd.set_option('display.width',200); print(T.round(3).to_string(index=False))

    print('[stage B_tbs finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE B_conformal: Part B: patient-level uncertainty on real BeatAML and FPMTB data
# =====================================================================================
if _run('B_conformal'):
    _t_stage = time.time()
    # Phase 9.1 — conformal vs proper baselines on real per-patient data (≈10–15 min)
    import numpy as np, pandas as pd, time, ast
    from scipy import stats
    from sklearn.linear_model import LinearRegression
    from sklearn.ensemble import GradientBoostingRegressor
    R2=R+'inputs/'; ALPHA=0.10
    def prof(p):
        s=ast.literal_eval(p) if isinstance(p,str) and p.startswith(('set','{')) else set()
        return (int('FLT3_ITD' in s or 'FLT3' in s), int('NPM1' in s), int('DNMT3A' in s))
    b=pd.read_csv(R2+'BeatAML_5drugs_df.csv'); b['drug']=b.inhibitor.str.split(' ').str[0]
    b[['FLT3','NPM1','DNMT3A']]=b.mutation_profile.apply(lambda p:pd.Series(prof(p))); b['y']=b.auc; b['grp']=b.mutation_profile.apply(lambda p:"+".join([n for n,v in zip(["FLT3","NPM1","DNMT3A"],prof(p)) if v]) or "none")
    f=pd.read_csv(R2+'FPMTB_sDSS_5drugs_min5_df.csv'); f['drug']=f.Drug_name
    f[['FLT3','NPM1','DNMT3A']]=f.mutation_profile.apply(lambda p:pd.Series(prof(p))); f['y']=f.DSS; f['grp']=f.mutation_profile.apply(lambda p:"+".join([n for n,v in zip(["FLT3","NPM1","DNMT3A"],prof(p)) if v]) or "none"); f['cohort']='FPMTB'
    XC=['FLT3','NPM1','DNMT3A']
    def wq(vals,w,wtest,level):   # weighted conformal quantile with point mass at +inf (Tibshirani et al. 2019)
        o=np.argsort(vals); v=vals[o]; ww=w[o]; p=ww/(ww.sum()+wtest); c=np.cumsum(p)
        k=np.searchsorted(c,level); return v[k] if k<len(v) else np.inf
    def boot_mean_ci(y,rng,B=2000):
        m=y[rng.integers(0,len(y),(B,len(y)))].mean(1); return np.quantile(m,[ALPHA/2,1-ALPHA/2])
    def intervals(Xtr,ytr,Xcal,ycal,Xte,rng,gcal=None,gte=None,weights=None):
        out={}; m=LinearRegression().fit(Xtr,ytr); pte=m.predict(Xte); n=len(ycal)
        lo,hi=boot_mean_ci(ycal,rng); out['Bootstrap CI of mean (misread)']=(np.full(len(Xte),lo),np.full(len(Xte),hi))
        # OLS Gaussian prediction interval
        Xd=np.column_stack([np.ones(len(Xtr)),Xtr]); res=ytr-m.predict(Xtr); dof=max(len(ytr)-Xd.shape[1],1); s2=res@res/dof
        XtX=np.linalg.pinv(Xd.T@Xd); Xt=np.column_stack([np.ones(len(Xte)),Xte]); h=np.einsum('ij,jk,ik->i',Xt,XtX,Xt); t=stats.t.ppf(1-ALPHA/2,dof); w=t*np.sqrt(s2*(1+h))
        out['OLS Gaussian PI']=(pte-w,pte+w)
        # residual-bootstrap PI (training residuals, no calibration set)
        ql,qh=np.quantile(res,[ALPHA/2,1-ALPHA/2]); out['Residual-bootstrap PI']=(pte+ql,pte+qh)
        # split conformal
        r=np.abs(ycal-m.predict(Xcal)); q=np.quantile(r,min(np.ceil((n+1)*(1-ALPHA))/n,1.0),method='higher'); out['Split conformal']=(pte-q,pte+q)
        # CQR
        try:
            gl=GradientBoostingRegressor(loss='quantile',alpha=ALPHA/2,n_estimators=60,max_depth=2,random_state=0).fit(Xtr,ytr)
            gh=GradientBoostingRegressor(loss='quantile',alpha=1-ALPHA/2,n_estimators=60,max_depth=2,random_state=0).fit(Xtr,ytr)
            sc=np.maximum(gl.predict(Xcal)-ycal,ycal-gh.predict(Xcal)); qc=np.quantile(sc,min(np.ceil((n+1)*(1-ALPHA))/n,1.0),method='higher')
            out['CQR (conformalised quantile)']=(gl.predict(Xte)-qc,gh.predict(Xte)+qc)
        except Exception: pass
        if gcal is not None:   # Mondrian: calibrate within observed profile
            lo_=np.empty(len(Xte)); hi_=np.empty(len(Xte)); rc=np.abs(ycal-m.predict(Xcal))
            for g in np.unique(gte):
                msk=gcal==g; ng=msk.sum()
                if ng>=int(np.ceil(1/ALPHA))-1+1 and ng>=9: qg=np.quantile(rc[msk],min(np.ceil((ng+1)*(1-ALPHA))/ng,1.0),method='higher')
                else: qg=q   # too few calibration points in this profile: fall back to pooled
                lo_[gte==g]=pte[gte==g]-qg; hi_[gte==g]=pte[gte==g]+qg
            out['Mondrian (profile-conditional) conformal']=(lo_,hi_)
        if weights is not None:  # covariate-shift weighted conformal
            rc=np.abs(ycal-m.predict(Xcal)); lo_=np.empty(len(Xte)); hi_=np.empty(len(Xte))
            for i in range(len(Xte)):
                qq=wq(rc,weights['cal'],weights['te'][i],1-ALPHA); lo_[i]=pte[i]-qq; hi_[i]=pte[i]+qq
            out['Weighted conformal (covariate shift)']=(lo_,hi_)
        return out
    def score(lo,hi,y):
        cov=((y>=lo)&(y<=hi)); wid=hi-lo
        iscore=wid+(2/ALPHA)*np.maximum(lo-y,0)+(2/ALPHA)*np.maximum(y-hi,0)
        return cov.mean(),np.mean(np.where(np.isfinite(wid),wid,np.nan)),np.nanmean(np.where(np.isfinite(iscore),iscore,np.nan)),cov
    def run(df,design,reps,seed=0,drug='Venetoclax'):
        d=df[df.drug==drug].reset_index(drop=True); rng=np.random.default_rng(seed); rows=[]; groups=sorted(d.grp.unique())
        X=d[XC].values.astype(float); y=d.y.values; g=d.grp.values
        def split_half(idx):
            idx=rng.permutation(idx); h=len(idx)//2; return idx[:h],idx[h:]
        for r in range(reps):
            jobs=[]
            if design=='random split':
                idx=rng.permutation(len(d)); a,b_,c=np.split(idx,[int(.4*len(d)),int(.7*len(d))]); jobs.append(('all',a,b_,c))
            elif design=='leave-one-profile-out':
                for hg in groups:
                    te=np.where(g==hg)[0]; tr=np.where(g!=hg)[0]
                    if len(te)<3: continue
                    a,b_=split_half(tr); jobs.append((hg,a,b_,te))
            elif design=='cohort shift (Waves1+2 -> Waves3+4)' or design=='cohort shift (Waves3+4 -> Waves1+2)':
                src,dst=('Waves1+2','Waves3+4') if '1+2 ->' in design else ('Waves3+4','Waves1+2')
                tr=np.where(d.cohort.values==src)[0]; te=np.where(d.cohort.values==dst)[0]; a,b_=split_half(tr); jobs.append(('all',a,b_,te))
            for lab,a,b_,te in jobs:
                wts=None
                if 'cohort' in design:
                    pc=pd.Series(g[b_]).value_counts(normalize=True); pt=pd.Series(g[te]).value_counts(normalize=True)
                    wts=dict(cal=np.array([pt.get(k,0)/pc[k] for k in g[b_]]),te=np.array([pt.get(k,0)/pc.get(k,1e-9) for k in g[te]]))
                iv=intervals(X[a],y[a],X[b_],y[b_],X[te],rng,gcal=g[b_] if design=='random split' else None,gte=g[te] if design=='random split' else None,weights=wts)
                for meth,(lo,hi) in iv.items():
                    cv,w_,isc,cvec=score(lo,hi,y[te])
                    rows.append(dict(drug=drug,design=design,heldout=lab,method=meth,rep=r,coverage=cv,width=w_,interval_score=isc,n_test=len(te)))
                    if design=='random split':
                        for gg in groups:
                            mk=g[te]==gg
                            if mk.sum()>0: rows.append(dict(drug=drug,design='random split (per profile)',heldout=gg,method=meth,rep=r,coverage=cvec[mk].mean(),width=np.nanmean((hi-lo)[mk]),interval_score=np.nan,n_test=int(mk.sum())))
        return pd.DataFrame(rows)
    t=time.time(); allr=[]
    for design,reps in [('random split',150),('leave-one-profile-out',100),('cohort shift (Waves1+2 -> Waves3+4)',100),('cohort shift (Waves3+4 -> Waves1+2)',100)]:
        allr.append(run(b,design,reps)); print(design,time.time()-t,flush=True)
    V=pd.concat(allr); V['cohort_data']='BeatAML (real per-patient)'; V.to_csv(OUT+'conformal_venetoclax_raw.csv',index=False)
    fp=[run(f,'random split',150),run(f,'leave-one-profile-out',100)]; Fp=pd.concat(fp); Fp['cohort_data']='FPMTB (independent real cohort)'; Fp.to_csv(OUT+'conformal_fpmtb_raw.csv',index=False)
    # other drugs, LOMGO + random split (fewer reps)
    od=[]
    for dr in ['Ibrutinib','Midostaurin','Entospletinib','Selumetinib','Trametinib']:
        od+= [run(b,'leave-one-profile-out',40,drug=dr),run(b,'random split',60,drug=dr)]
    O=pd.concat(od); O['cohort_data']='BeatAML (real per-patient)'; O.to_csv(OUT+'conformal_otherdrugs_raw.csv',index=False)
    print('done',time.time()-t)

    # Phase 9.2 — summary tables
    def summ(df):
        d = df[~df.design.str.contains('per profile')]
        return d.groupby(['design','method']).agg(coverage=('coverage','mean'), coverage_sd=('coverage','std'),
                                                   width=('width','mean'), interval_score=('interval_score','mean')).round(3)
    V = pd.read_csv(OUT+'conformal_venetoclax_raw.csv'); Fp = pd.read_csv(OUT+'conformal_fpmtb_raw.csv'); O = pd.read_csv(OUT+'conformal_otherdrugs_raw.csv')
    S_bv = summ(V); S_fp = summ(Fp); S_bv.to_csv(OUT+'conformal_summary_beataml_venetoclax.csv'); S_fp.to_csv(OUT+'conformal_summary_fpmtb_venetoclax.csv')
    print('=== BeatAML venetoclax (real per-patient) ==='); print(S_bv.to_string())
    print('\n=== FPMTB venetoclax (independent cohort; tiny profile groups, n<=7) ==='); print(S_fp.to_string())
    allD = pd.concat([V[~V.design.str.contains('per profile')], O[~O.design.str.contains('per profile')]])
    S_all = allD[allD.design.isin(['random split','leave-one-profile-out'])].groupby(['drug','design','method']).coverage.mean().unstack().round(3)
    S_all.to_csv(OUT+'conformal_all_drugs_summary.csv'); print('\n=== all six drugs ==='); print(S_all.to_string())
    cond = V[V.design=='random split (per profile)'].groupby(['heldout','method']).coverage.mean().unstack().round(3)
    cond.to_csv(OUT+'conformal_conditional_coverage_by_profile.csv'); print('\n=== profile-conditional coverage (random split) ==='); print(cond.to_string())
    # real-data distribution shape (tests the normal-approximation used in Part A)
    from scipy import stats as _st
    _b = pd.read_csv(R+'inputs/BeatAML_5drugs_df.csv'); _v = _b[_b.inhibitor=='Venetoclax']
    shape = _v.groupby('mutation_profile').auc.agg(n='count', mean='mean', sd='std', skew=lambda x:_st.skew(x), shapiro_p=lambda x:_st.shapiro(x)[1]).round(3)
    shape.to_csv(OUT+'beataml_venetoclax_group_distribution_shape.csv'); print('\n=== real per-patient venetoclax distribution by profile ==='); print(shape.to_string())
    try:
        print('\nPart A synthetic-patient LOMGO (v1): bootstrap %.1f%%, conformal %.1f%%' % (df_lomgo['bootstrap_coverage_%'].mean(), df_lomgo['conformal_coverage_%'].mean()))
    except NameError: pass


    print('[stage B_conformal finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE B_calib: Part B: calibration quality and combination-benchmark scaffold
# =====================================================================================
if _run('B_calib'):
    _t_stage = time.time()
    # Phase 10.1 — is the 'r = 0.879' calibration claim driven by between-drug differences?
    from scipy.stats import pearsonr
    d_ = pd.read_csv(R+'optimization_results/BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW/detailed_results.csv')
    m_ = pd.read_csv(R+'inputs/BeatAML_AUC_5drugs_Waves3+4.csv')
    mm = d_.merge(m_[['Experiments','drug','mutation_profile']], left_on='Experiment_ID', right_on='Experiments')
    rows = [dict(subset='pooled (40 drug x genotype points)', n=len(mm), pearson_r=pearsonr(mm.Predicted_Value, mm.Measured_Value)[0], spearman_rho=spearmanr(mm.Predicted_Value, mm.Measured_Value)[0])]
    for dr, x in mm.groupby('drug'):
        rows.append(dict(subset=f'within {dr} (8 genotypes)', n=len(x), pearson_r=pearsonr(x.Predicted_Value, x.Measured_Value)[0], spearman_rho=spearmanr(x.Predicted_Value, x.Measured_Value)[0]))
    calib = pd.DataFrame(rows).round(3); calib.to_csv(OUT+'kgbn_calibration_within_drug.csv', index=False); print(calib.to_string(index=False))


    # Phase 10.2 — Optional external comparison (scaffold only; nothing in the manuscript depends on it)
    #
    # If a table of published synergy values for pairs among the five calibrated drugs is ever supplied, this cell reports a rank correlation
    # with the model's predicted excess over additivity. No such table is used in the manuscript, so this cell is a documented scaffold, not a result.
    # CSV columns:  drug_a, drug_b, synergy.  Drug names must be among: Venetoclax, Ibrutinib, Entospletinib, Selumetinib, Midostaurin.
    COMBO_CSV = f"{PROJECT_DIR}/data/measured_combination_synergy.csv"
    def combination_benchmark(csv_path, predicted_excess):
        """predicted_excess: dict {(drugA, drugB): model synergy (excess over additivity, pp)}. Reports Spearman + permutation p."""
        if not os.path.exists(csv_path):
            print(f"[skipped] {csv_path} not found. Optional scaffold: no external synergy table supplied."); return None
        m = pd.read_csv(csv_path); m['key'] = [tuple(sorted(x)) for x in zip(m.drug_a, m.drug_b)]
        pred = {tuple(sorted(k)): v for k, v in predicted_excess.items()}
        m = m[m.key.isin(pred)]; m['pred'] = m.key.map(pred)
        if len(m) < 4: print('Need >=4 overlapping pairs.'); return None
        rho = spearmanr(m.pred, m.synergy)[0]; rng = np.random.default_rng(0)
        null = [spearmanr(rng.permutation(m.pred.values), m.synergy)[0] for _ in range(5000)]
        print(f"n pairs={len(m)}  Spearman={rho:.3f}  permutation p={(np.sum(np.abs(null)>=abs(rho))+1)/5001:.4f}"); return m
    _syn = pd.read_csv(OUT+'pbn_synergy_additivity.csv')
    predicted_excess = {tuple(p.split(' + ')): e for p, e in zip(_syn.pair, _syn.excess_over_additive_pp)}
    print('Model-predicted excess over additivity (pp):', {k: round(v,2) for k, v in predicted_excess.items()})
    _ = combination_benchmark(COMBO_CSV, predicted_excess)


    print('[stage B_calib finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE B_manifest: Part B: results manifest
# =====================================================================================
if _run('B_manifest'):
    _t_stage = time.time()
    # Phase 12 — results manifest
    import json
    man = {}
    H_ = pd.read_csv(OUT+'pbn_hoeffding_ranking.csv').set_index('candidate'); S_ = pd.read_csv(OUT+'pbn_synergy_additivity.csv')
    man['pbn_headline'] = dict(untreated=H_.loc['untreated','partial'], mido_ven=H_.loc[HEADP,'partial'], mido_ven_strict=H_.loc[HEADP,'strict'],
        n_hoeffding=26492, excess_over_additive_pp=float(S_[S_.pair==HEAD_LABEL].excess_over_additive_pp.iloc[0]), excess_over_HSA_pp=float(S_[S_.pair==HEAD_LABEL].excess_over_HSA_pp.iloc[0]))
    NN = pd.read_csv(OUT+'pbn_all_clamp_sets.csv'); d3 = NN[NN.k==3]; v = man['pbn_headline']['mido_ven']
    man['size_matched_null'] = dict(n_sets=int(len(d3)), percentile=float((d3.partial<v).mean()*100), rank=int((d3.partial>v).sum()+1), best_set=d3.loc[d3.partial.idxmax(),'genes'], best_score=float(d3.partial.max()))
    for n in (300, 1000): man[f'rank_stability_n{n}'] = pd.read_csv(OUT+f'pbn_rank_stability_n{n}.csv').head(3).to_dict('records')
    man['effect_sizes'] = pd.read_csv(OUT+'pbn_effect_sizes.csv').to_dict('records')
    man['genotype_strata'] = pd.read_csv(OUT+'pbn_genotype_strata.csv').to_dict('records'); man['class_level_flt3'] = pd.read_csv(OUT+'pbn_class_level_flt3.csv').to_dict('records')
    A_ = pd.read_csv(OUT+'pbn_alternative_calibrations.csv'); man['alt_calibrations'] = dict(n=int(len(A_)), rank1=int((A_.Head_rank==1).sum()), rank2=int((A_.Head_rank==2).sum()), mean_tau=float(A_.kendall_tau_vs_reference.mean()))
    man['rule_prob_perturbation'] = pd.read_csv(OUT+'pbn_rule_prob_perturbation.csv').to_dict('records'); man['horizon_init'] = pd.read_csv(OUT+'pbn_horizon_init_sensitivity.csv').to_dict('records')
    man['tbs_validation'] = pd.read_csv(OUT+'tbs_validation_all_networks.csv').to_dict('records'); man['tbs_stability_pilot'] = pd.read_csv(OUT+'pilot_tbs_stability.csv').to_dict('records')
    man['conformal_beataml_venetoclax'] = pd.read_csv(OUT+'conformal_summary_beataml_venetoclax.csv').to_dict('records'); man['conformal_fpmtb_venetoclax'] = pd.read_csv(OUT+'conformal_summary_fpmtb_venetoclax.csv').to_dict('records')
    man['conformal_conditional'] = pd.read_csv(OUT+'conformal_conditional_coverage_by_profile.csv').to_dict('records'); man['kgbn_calibration'] = pd.read_csv(OUT+'kgbn_calibration_within_drug.csv').to_dict('records')
    json.dump(man, open(RESULTS_DIR+'/results_manifest.json','w'), indent=1, default=float); print('Saved', RESULTS_DIR+'/results_manifest.json'); print(json.dumps(man['pbn_headline'], indent=1)); print(json.dumps(man['alt_calibrations'], indent=1))


    print('[stage B_manifest finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE C_benchmark: Part C: pre-specified benchmark, criteria check, untreated baselines
# =====================================================================================
if _run('C_benchmark'):
    _t_stage = time.time()
    # C.4 — benchmark runner
    def run_benchmark(name, reps, prefix='', rep_start=0):
        t0 = time.time(); net = AMLNet() if name == 'aml_pbn_kgbn' else BoolNoisy(name, SPEC[name]); pr = Problem(net); K = pr.K; rng = np.random.default_rng(7)
        scr = pr.draw(np.arange(K), 2000, rng).mean(1); top = np.argsort(-scr)[:30]
        ref = np.array([pr.draw([a], 60000, rng).mean() for a in top]); truth = float(ref.max()); refmap = {int(a): float(r) for a, r in zip(top, ref)}
        nu = int(np.ceil(np.log(2 * K / DELTA) / (2 * EPS ** 2))); utot = nu * K
        print(f'{name}: nodes={net.n} K={K} truth_best={"+".join(pr.arms[int(top[np.argmax(ref)])])} {truth:.4f} uniform_bound={utot:,} ({time.time()-t0:.0f}s)', flush=True)
        score = lambda a: refmap[a] if a in refmap else float(pr.draw([a], 60000, np.random.default_rng(99 + a)).mean())
        rows = []
        for r in range(rep_start, reps):
            a, tot, cert = certified(pr, np.random.default_rng(1000 + r)); sc = score(a)
            rows.append(dict(network=name, K=K, rep=r, method='Certified (EB successive elimination)', total=tot, certified=cert, returned="+".join(pr.arms[a]), true_score=sc, gap=truth - sc, success=truth - sc <= EPS, uniform_bound=utot, reduction=utot / tot))
            for nm, f in (('Uniform (budget-matched)', uniform), ('Successive halving (budget-matched)', succ_halving), ('Greedy forward (budget-matched)', greedy)):
                a2, used = f(pr, tot, np.random.default_rng(2000 + r)); s2 = score(a2)
                rows.append(dict(network=name, K=K, rep=r, method=nm, total=used, certified=False, returned="+".join(pr.arms[a2]), true_score=s2, gap=truth - s2, success=truth - s2 <= EPS, uniform_bound=utot, reduction=utot / max(used, 1)))
            print(f'  rep{r}: certified total={tot:,} ({utot/tot:.1f}x) cert={cert} success={rows[-4]["success"]} | uniform {rows[-3]["success"]} halving {rows[-2]["success"]} greedy {rows[-1]["success"]} ({time.time()-t0:.0f}s)', flush=True)
            _path = OUT + f'{prefix}bench_{name}.csv'; _new = pd.DataFrame(rows)
            if rep_start > 0 and os.path.exists(_path):
                _old = pd.read_csv(_path); _new = pd.concat([_old[_old.rep < rep_start], _new], ignore_index=True)
            _new.to_csv(_path, index=False)
        pd.DataFrame(dict(arm=["+".join(pr.arms[a]) for a in top], screen=scr[top], refined=ref)).sort_values('refined', ascending=False).to_csv(OUT + f'{prefix}bench_{name}_reference.csv', index=False)
    if FULL_RUN:
        for nm, reps in (('calzone_cellfate', 5), ('grieco_mapk', 5), ('remy_tumorigenesis', 3), ('aml_pbn_kgbn', 5)): run_benchmark(nm, reps)
    elif ARGS.bench_plan:
        for _item in ARGS.bench_plan.split(','):
            _nm, _a, _b = _item.split(':'); run_benchmark(_nm, int(_b), rep_start=int(_a))
    else:
        print('QUICK verification: 1 repetition on grieco_mapk (full-run results are read from results/bench_*.csv)')
        run_benchmark('grieco_mapk', 1, prefix='quick_')


    # C.4b — summary against the three pre-registered criteria (reads full-run CSVs)
    import glob
    files = [f for f in glob.glob(OUT + 'bench_*.csv') if not f.endswith(('reference.csv', 'baselines.csv', 'summary.csv', 'margin.csv'))]
    assert files, 'Place the shipped results/bench_*.csv files in results/ (or set FULL_RUN=True).'
    D = pd.concat([pd.read_csv(f) for f in files]); D['method'] = D.method.str.replace(r' \(.*\)', '', regex=True)
    S = D.groupby(['network', 'method']).agg(runs=('rep', 'count'), success=('success', 'sum'), certified=('certified', 'sum'), mean_total_sims=('total', 'mean'), reduction_vs_uniform_bound=('reduction', 'mean')).round(2)
    S.to_csv(OUT + 'bench_summary.csv'); print(S.to_string())
    c = D[D.method == 'Certified']
    print(f"\nC1  epsilon-optimal in {int(c.success.sum())}/{len(c)} certified runs (criterion: >=95%)  -> {'MET' if c.success.mean() >= 0.95 else 'NOT MET'}")
    mins = c.groupby('network').reduction.min(); print('C2  minimum reduction per network (criterion: >=10x in EVERY network):'); print(mins.round(1).to_string()); print('    ->', 'MET' if (mins >= 10).all() else 'NOT MET')
    for m in ['Uniform', 'Successive halving', 'Greedy forward']:
        x = D[D.method == m]; print(f'C3  {m}: {int(x.success.sum())}/{len(x)} success (certified search: {int(c.success.sum())}/{len(c)})')
    from scipy.stats import beta as _beta, norm as _norm
    _k = int(c.success.sum()); _n = len(c); _lo = float(_beta.ppf(0.05, _k, _n - _k + 1)) if _k > 0 else 0.0
    print(f'    exact (Clopper-Pearson) one-sided 95% lower bound on the success probability: {_lo:.3f} ({_k}/{_n})')
    # ground-truth margin: could a set outside the re-estimated top 30 have beaten the reported optimum?
    _gm = []
    for _nm, _K in c.groupby('network').K.first().items():
        try: _r = pd.read_csv(OUT + f'bench_{_nm}_reference.csv')
        except Exception: continue
        _margin = float(_r.refined.max() - _r.screen.min()); _se = 0.5 / np.sqrt(2000)
        _gm.append(dict(network=_nm, K=int(_K), best_refined=float(_r.refined.max()), screen_30th=float(_r.screen.min()), margin=_margin, margin_in_worst_case_SE=_margin / _se, union_bound_miss=float(min(1.0, (_K - 30) * _norm.sf(_margin / _se)))))
    if _gm: pd.DataFrame(_gm).to_csv(OUT + 'bench_groundtruth_margin.csv', index=False); print(pd.DataFrame(_gm).round(4).to_string(index=False))


    # C.5 — untreated baselines
    rows = []
    for nm in ['calzone_cellfate', 'grieco_mapk', 'remy_tumorigenesis', 'zhang_tlgl', 'aml_pbn_kgbn']:
        net = AMLNet() if nm == 'aml_pbn_kgbn' else BoolNoisy(nm, SPEC[nm]); x = net.sim(np.zeros((20000 if not FULL_RUN else 40000, net.n), bool), np.random.default_rng(11))
        try: best = float(pd.read_csv(OUT + f'bench_{nm}_reference.csv').refined.max())
        except Exception: best = np.nan
        rows.append(dict(network=nm, untreated_mean=x.mean(), untreated_sd=x.std(), best_set_score=best))
    U = pd.DataFrame(rows); U.loc[U.network == 'remy_tumorigenesis', 'best_set_score'] = U.loc[U.network == 'remy_tumorigenesis', 'best_set_score'].fillna(0.6595)
    U['gain'] = U.best_set_score - U.untreated_mean; U.to_csv(OUT + 'bench_untreated_baselines.csv', index=False); print(U.round(3).to_string(index=False))
    print('\nzhang_tlgl untreated is already 0.924: no headroom, so near-ties cannot be separated (reported, not benchmarked).')


    print('[stage C_benchmark finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE C_druggable: Part C: certified search over druggable combinations and 15-calibration stress test
# =====================================================================================
if _run('C_druggable'):
    _t_stage = time.time()
    # C.6a — certified search over druggable combinations + full ranking with additivity
    UNITS = {"Venetoclax": ["BCL2"], "Ibrutinib": ["BTK"], "Entospletinib": ["SYK"], "Selumetinib": ["MAP2K1", "MAP2K2"], "Midostaurin": ["FLT3", "KIT"],
             "FLT3-inhibitor (gilteritinib-class)": ["FLT3"], "AKT-inhibitor class": ["AKT1"], "ERK-inhibitor class": ["MAPK1"]}
    aml = AMLNet(); drug_pr = Problem(aml, units=UNITS, kmax=3); K = drug_pr.K; EPSd = 0.01
    trace = []; t0 = time.time(); a, total, cert = certified(drug_pr, np.random.default_rng(31), eps=EPSd, m=200, cap=60000, trace=trace)
    nu = int(np.ceil(np.log(2 * K / DELTA) / (2 * EPSd ** 2))); print(f'certified={cert}  best={" + ".join(drug_pr.arms[a])}  total={total:,}  uniform bound={nu*K:,}  reduction={nu*K/total:.1f}x  rounds={len(trace)}  ({time.time()-t0:.0f}s)')
    pd.DataFrame(trace).to_csv(OUT + 'constrained_elimination_trace.csv', index=False)
    det = draw_detail(drug_pr, np.arange(K), 30000, np.random.default_rng(5)); mk_ref = det.mean(1); mu_ref = mk_ref.mean(1); sd = det.mean(2).std(1)
    u_mk = untreated_markers(aml, 60000, 6); untr = float(u_mk.mean())
    tab = pd.DataFrame(dict(combination=[" + ".join(x) for x in drug_pr.arms], n_drugs=[len(x) for x in drug_pr.arms], score=mu_ref, sd=sd)).sort_values('score', ascending=False).reset_index(drop=True)
    single = {x[0]: mu_ref[i] for i, x in enumerate(drug_pr.arms) if len(x) == 1}; single_mk = {x[0]: mk_ref[i] for i, x in enumerate(drug_pr.arms) if len(x) == 1}
    tab['additive_expected'] = [untr + sum(single[d] - untr for d in c.split(' + ')) for c in tab.combination]; tab['excess_over_additive'] = tab.score - tab.additive_expected; tab['untreated'] = untr
    tab['bliss_expected'] = [bliss_expected(u_mk, [single_mk[d] for d in c.split(' + ')]) for c in tab.combination]; tab['excess_over_bliss'] = tab.score - tab.bliss_expected
    tab.to_csv(OUT + 'constrained_druggable_ranking.csv', index=False)
    json.dump(dict(certified=cert, total=int(total), uniform_bound=int(nu * K), reduction=nu * K / total, certified_best=" + ".join(drug_pr.arms[a]), K=K, eps=EPSd, delta=DELTA, untreated=float(untr)), open(OUT + 'constrained_summary.json', 'w'), indent=1)
    pd.set_option('display.width', 200)
    for k in (1, 2, 3): print(f'--- best {k}-drug sets'); print(tab[tab.n_drugs == k].head(3)[['combination', 'score', 'additive_expected', 'excess_over_additive', 'bliss_expected', 'excess_over_bliss']].round(3).to_string(index=False))


    # C.6b — stress test: does the super-additive triplet survive across independent calibrations?
    files = [REF] + [f for f in sorted(glob.glob(R + 'optimization_results/**/pbn.txt', recursive=True)) if f != REF]; seen = set(); alts = []
    for f in files:
        g, _ = parse_pbn(f); h = hashlib.md5(open(f, 'rb').read()).hexdigest()
        if set(g) == set(aml.P.genes) and 'Test_Evaluation' not in f and h not in seen: seen.add(h); alts.append(f)
    Um = {"Ven": ["BCL2"], "Ibr": ["BTK"], "Ento": ["SYK"], "Sel": ["MAP2K1", "MAP2K2"], "Mido": ["FLT3", "KIT"], "Gilt": ["FLT3"], "AKTi": ["AKT1"], "ERKi": ["MAPK1"]}
    combos = {"Ibr+Mido+ERKi": ("Ibr", "Mido", "ERKi"), "Ven+Ento+ERKi": ("Ven", "Ento", "ERKi"), "Ven+Mido+ERKi": ("Ven", "Mido", "ERKi"), "Ven+Mido": ("Ven", "Mido")}
    rows = []
    for f in alts:
        Q = VecPBN(f); lab = f.split('optimization_results/')[1].replace('/pbn.txt', '')
        def sc(ds): return marker_scores(Q, Q.run(6000, frozenset(g for d in ds for g in Um[d]), np.random.default_rng(3), steps=40))[0].mean()
        u = sc(()); s1 = {d: sc((d,)) for d in Um}
        for nm, ds in combos.items():
            obs = sc(ds); add = u + sum(s1[d] - u for d in ds); rows.append(dict(model=lab, combo=nm, observed=obs, additive=add, excess=obs - add, untreated=u))
    ST = pd.DataFrame(rows); ST.to_csv(OUT + 'constrained_stress_alt_calibrations.csv', index=False)
    print(f'{len(alts)} distinct calibrations')
    print(ST.groupby('combo').agg(mean_excess=('excess', 'mean'), min_excess=('excess', 'min'), max_excess=('excess', 'max'), frac_positive=('excess', lambda x: (x > 0.02).mean()), mean_score=('observed', 'mean')).round(3).to_string())
    piv = ST.pivot(index='model', columns='combo', values='observed'); print('Ibr+Mido+ERKi highest of the 4 sets in', int((piv.idxmax(axis=1) == 'Ibr+Mido+ERKi').sum()), 'of', len(piv), 'calibrations')


    print('[stage C_druggable finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# ====================================================================================
# STAGE E_robust: Revision: clamping policy, Bliss null, per-calibration search, structural sensitivity, strict-delta cost, hard audit, LUCB
# ====================================================================================
if _run('E_robust'):

    # E.0 shared definitions -------------------------------------------------------------
    _tE = time.time()
    UNITS = {"Venetoclax": ["BCL2"], "Ibrutinib": ["BTK"], "Entospletinib": ["SYK"], "Selumetinib": ["MAP2K1", "MAP2K2"], "Midostaurin": ["FLT3", "KIT"],
             "FLT3-inhibitor (gilteritinib-class)": ["FLT3"], "AKT-inhibitor class": ["AKT1"], "ERK-inhibitor class": ["MAPK1"]}
    TRIP = "Ibrutinib + Midostaurin + ERK-inhibitor class"
    aml_e = AMLNet(); drug_e = Problem(aml_e, units=UNITS, kmax=3); KE = drug_e.K; P0 = aml_e.P
    _names_e = [" + ".join(x) for x in drug_e.arms]
    CAL_FILES = []; _seen = set()
    for _f in [REF] + [f for f in sorted(glob.glob(R + 'optimization_results/**/pbn.txt', recursive=True)) if f != REF]:
        _g, _ = parse_pbn(_f); _h = hashlib.md5(open(_f, 'rb').read()).hexdigest()
        if set(_g) == set(P0.genes) and 'Test_Evaluation' not in _f and _h not in _seen: _seen.add(_h); CAL_FILES.append(_f)
    CAL_LAB = [f.split('optimization_results/')[1].replace('/pbn.txt', '') for f in CAL_FILES]
    print(f'AML policy: {AML_POLICY}; clampable genes: {len(aml_e.targets)}; reward markers: {aml_e.marker_names}; distinct calibrations: {len(CAL_FILES)}', flush=True)

    # E.1 clamping-policy comparison: reward definitions on the SAME simulations --------------
    _rg = [r for r in P0.raw if any(('BCL2' in e) for e, _ in P0.raw[r]) and r != 'BCL2']
    print('rules (of genes other than BCL2) that use BCL2 as a regulator:', len(_rg), _rg)
    _sets = {'untreated': [], 'Venetoclax (BCL2)': ['BCL2'], 'Ibrutinib (BTK)': ['BTK'], 'Entospletinib (SYK)': ['SYK'], 'Selumetinib (MAP2K1/2)': ['MAP2K1', 'MAP2K2'], 'Midostaurin (FLT3+KIT)': ['FLT3', 'KIT'],
             'AKT-inhibitor class (AKT1)': ['AKT1'], 'ERK-inhibitor class (MAPK1)': ['MAPK1'], 'Midostaurin + Venetoclax': ['FLT3', 'KIT', 'BCL2'], 'Midostaurin + Ibrutinib': ['FLT3', 'KIT', 'BTK'], 'Ibrutinib + Venetoclax': ['BTK', 'BCL2'],
             'BCL2 + MYC + SYK (best 3-gene set under legacy policy)': ['BCL2', 'MYC', 'SYK']}
    _rows = []
    for _k, _v in _sets.items():
        _S = P0.run(26492, frozenset(_v), np.random.default_rng(123), steps=40)
        _leg = marker_scores(P0, _S, apop=('TP53', 'CDKN2A'), surv=('BCL2', 'MYC', 'CCND1', 'AKT1', 'STAT5A'))[0].mean()
        _str = marker_scores(P0, _S, apop=('TP53', 'CDKN2A'), surv=('MYC', 'CCND1', 'STAT5A'))[0].mean(); _rows.append(dict(candidate=_k, legacy_7marker=_leg * 100, strict_5marker=_str * 100))
    POL = pd.DataFrame(_rows); _u = POL.iloc[0]; POL['legacy_gain'] = POL.legacy_7marker - _u.legacy_7marker; POL['strict_gain'] = POL.strict_5marker - _u.strict_5marker
    POL.to_csv(OUT + 'e_policy_comparison.csv', index=False); print(POL.round(2).to_string(index=False))

    # E.2 dependence among the distinct calibrations -------------------------------------------
    from scipy.stats import spearmanr as _sp
    _vec = []
    for _f in CAL_FILES:
        _, _raw = parse_pbn(_f); _d = {}
        for _gene, _rl in _raw.items():
            _tot = sum(p for _, p in _rl)
            for _ex, _p in _rl: _d[(_gene, _ex)] = _p / _tot
        _vec.append(_d)
    _keys = sorted(set().union(*[v.keys() for v in _vec])); _V = np.array([[v.get(k, 0.0) for k in _keys] for v in _vec])
    _same = all(set(v) == set(_vec[0]) for v in _vec)
    _Rm = np.array([[_sp(_V[i], _V[j])[0] for j in range(len(_V))] for i in range(len(_V))]); _iu = np.triu_indices(len(_V), 1)
    _cs = {'Ibr': ['BTK'], 'Mido': ['FLT3', 'KIT'], 'Ven': ['BCL2'], 'Ento': ['SYK'], 'Sel': ['MAP2K1', 'MAP2K2']}
    _pairs = [('Mido', 'Ven'), ('Mido', 'Ibr'), ('Mido', 'Ento'), ('Mido', 'Sel'), ('Ibr', 'Ven')]
    _score_vecs = []
    for _f in CAL_FILES:
        _Q = VecPBN(_f); _sv = []
        for _k in _cs: _sv.append(marker_scores(_Q, _Q.run(3000, frozenset(_cs[_k]), np.random.default_rng(3), steps=40))[0].mean())
        for _a, _b in _pairs: _sv.append(marker_scores(_Q, _Q.run(3000, frozenset(_cs[_a] + _cs[_b]), np.random.default_rng(3), steps=40))[0].mean())
        _score_vecs.append(_sv)
    _Rs = np.array([[_sp(_score_vecs[i], _score_vecs[j])[0] for j in range(len(_score_vecs))] for i in range(len(_score_vecs))])
    DEP = pd.DataFrame(_Rm, index=CAL_LAB, columns=CAL_LAB); DEP.to_csv(OUT + 'e_calibration_rule_probability_spearman.csv')
    pd.DataFrame([dict(n_calibrations=len(CAL_FILES), identical_rule_sets=_same, n_rule_probabilities=len(_keys), rule_prob_spearman_mean=float(_Rm[_iu].mean()), rule_prob_spearman_min=float(_Rm[_iu].min()),
                       candidate_score_spearman_mean=float(_Rs[_iu].mean()), candidate_score_spearman_min=float(_Rs[_iu].min()))]).to_csv(OUT + 'e_calibration_dependence_summary.csv', index=False)
    print(f'{len(CAL_FILES)} distinct calibrations; identical rule sets across calibrations: {_same}; pairwise Spearman of rule-probability vectors: mean {_Rm[_iu].mean():.3f}, min {_Rm[_iu].min():.3f}; of the 10 candidate scores: mean {_Rs[_iu].mean():.3f}, min {_Rs[_iu].min():.3f}', flush=True)

    # E.3 certified search inside EVERY calibration (not only four pre-selected sets) ----------
    _rows = []
    for _f, _lab in zip(CAL_FILES, CAL_LAB):
        _net = AMLNet(path=_f); _pr = Problem(_net, units=UNITS, kmax=3)
        _a, _tot, _cert = certified(_pr, np.random.default_rng(31), eps=0.01, m=200, cap=60000)
        _det = draw_detail(_pr, np.arange(_pr.K), 3000, np.random.default_rng(5)); _mk = _det.mean(1); _mu = _mk.mean(1); _u = untreated_markers(_net, 30000, 6)
        _sg = {x[0]: _mk[i] for i, x in enumerate(_pr.arms) if len(x) == 1}; _ti = _names_e.index(TRIP); _order = np.argsort(-_mu); _comp = TRIP.split(' + ')
        _lin = _mu[_ti] - (_u.mean() + sum(_sg[d].mean() - _u.mean() for d in _comp)); _bl = _mu[_ti] - bliss_expected(_u, [_sg[d] for d in _comp])
        _rows.append(dict(calibration=_lab, certified=_cert, total=_tot, certified_best=_names_e[_a], triplet_is_certified_best=_names_e[_a] == TRIP, triplet_rank=int(np.where(_order == _ti)[0][0] + 1), triplet_score=_mu[_ti], untreated=_u.mean(), excess_linear=_lin, excess_bliss=_bl))
        print(_rows[-1]['calibration'], _rows[-1]['certified_best'], 'rank', _rows[-1]['triplet_rank'], f"lin {_lin:+.3f} bliss {_bl:+.3f}", flush=True)
    PC = pd.DataFrame(_rows); PC.to_csv(OUT + 'e_per_calibration_search.csv', index=False)
    print(f"triplet is the certified best in {int(PC.triplet_is_certified_best.sum())}/{len(PC)} calibrations; rank<=3 in {int((PC.triplet_rank <= 3).sum())}; linear excess>0 in {int((PC.excess_linear > 0).sum())}, Bliss excess>0 in {int((PC.excess_bliss > 0).sum())}", flush=True)

    # E.4 structural sensitivity: remove or perturb the MAPK1 -> STAT5A input, and random rewiring ----------
    def _drop_reg(expr, g):
        e = re.sub(r'\s*[|&]\s*' + g + r'\b', '', expr); return re.sub(r'\b' + g + r'\s*[|&]\s*', '', e)
    def _variant(edit):
        raw = {g: list(v) for g, v in P0.raw.items()}; edit(raw); return VecPBN(genes=P0.genes, raw=raw)
    _cdrug = {'Ibr': ['BTK'], 'Mido': ['FLT3', 'KIT'], 'ERKi': ['MAPK1'], 'Ento': ['SYK']}
    _trips = {'Ibr+Mido+ERKi': ('Ibr', 'Mido', 'ERKi'), 'Ibr+Ento+ERKi': ('Ibr', 'Ento', 'ERKi'), 'Mido+Ento+ERKi': ('Mido', 'Ento', 'ERKi'), 'Ibr+Mido+Ento': ('Ibr', 'Mido', 'Ento')}
    def _eval_net(Q, n, seed):
        def mk(ds): return marker_matrix(Q, Q.run(n, frozenset(g for d in ds for g in _cdrug[d]), np.random.default_rng(seed), steps=40)).mean(0)
        u = marker_matrix(Q, Q.run(n, frozenset(), np.random.default_rng(seed), steps=40)).mean(0); sg = {d: mk((d,)) for d in ('Ibr', 'Mido', 'ERKi')}
        sc = {k: mk(v).mean() for k, v in _trips.items()}; t = mk(('Ibr', 'Mido', 'ERKi'))
        lin = t.mean() - (u.mean() + sum(sg[d].mean() - u.mean() for d in sg)); bl = t.mean() - bliss_expected(u, [sg[d] for d in sg])
        return dict(excess_linear=lin, excess_bliss=bl, triplet_top=max(sc, key=sc.get) == 'Ibr+Mido+ERKi', triplet_score=t.mean(), untreated=u.mean())
    _rows = []
    _rows.append(dict(scenario='reference network', rep=0, **_eval_net(P0, 8000, 1)))
    def _e_drop(raw): raw['STAT5A'] = [(_drop_reg(e, 'MAPK1'), p) for e, p in raw['STAT5A']]
    _rows.append(dict(scenario='MAPK1 input to STAT5A removed', rep=0, **_eval_net(_variant(_e_drop), 8000, 1)))
    def _e_swap(raw):
        rl = list(raw['STAT5A']); io = [i for i, (e, _) in enumerate(rl) if 'MAPK1' in e and '|' in e]; ia = [i for i, (e, _) in enumerate(rl) if 'MAPK1' in e and '&' in e]
        if io and ia: (eo, po), (ea, pa) = rl[io[0]], rl[ia[0]]; rl[io[0]] = (eo, pa); rl[ia[0]] = (ea, po)
        raw['STAT5A'] = rl
    _rows.append(dict(scenario='STAT5A OR-rule and AND-rule probabilities swapped', rep=0, **_eval_net(_variant(_e_swap), 8000, 1)))
    _rng = np.random.default_rng(2027); _tok = re.compile(r'\b[A-Za-z0-9]+\b'); _allr = [(g, i) for g in P0.genes for i in range(len(P0.raw[g]))]
    def _rewire(n_edits):
        def edit(raw):
            for _ in range(n_edits):
                while True:
                    g, i = _allr[_rng.integers(len(_allr))]; e, p = raw[g][i]; toks = [m for m in _tok.finditer(e) if m.group(0) in P0.idx]
                    if toks: break
                m = toks[_rng.integers(len(toks))]; new = P0.genes[_rng.integers(len(P0.genes))]; raw[g][i] = (e[:m.start()] + new + e[m.end():], p)
        return edit
    for _ne, _nr in ((1, 60), (3, 60)):
        for _r in range(_nr):
            try: _rows.append(dict(scenario=f'random rewiring of {_ne} regulator(s)', rep=_r, **_eval_net(_variant(_rewire(_ne)), 4000, 100 + _r)))
            except Exception as _ex: pass
    SS = pd.DataFrame(_rows); SS.to_csv(OUT + 'e_structural_sensitivity.csv', index=False)
    print(SS.groupby('scenario').agg(n=('rep', 'count'), mean_excess_linear=('excess_linear', 'mean'), frac_linear_pos=('excess_linear', lambda x: (x > 0.02).mean()), mean_excess_bliss=('excess_bliss', 'mean'), frac_bliss_pos=('excess_bliss', lambda x: (x > 0.02).mean()), frac_triplet_top=('triplet_top', 'mean')).round(3).to_string(), flush=True)

    # E.5 cost of the strict 1-delta constant versus the implemented 1-2*delta constant -------------
    def _certified_c(pr, rng, c, eps=0.01, delta=0.05, m=200, cap=60000):
        K = pr.K; n = np.zeros(K); s_ = np.zeros(K); ss = np.zeros(K); act = np.arange(K); t = 0; total = 0
        while True:
            t += 1; x = pr.draw(act, m, rng); n[act] += m; s_[act] += x.sum(1); ss[act] += (x ** 2).sum(1); total += x.size
            nn = n[act]; mu = s_[act] / nn; var = np.maximum(ss[act] / nn - mu ** 2, 0) * nn / np.maximum(nn - 1, 1); L = np.log(c * K * t * (t + 1) / delta)
            r = np.sqrt(2 * var * L / np.maximum(nn - 1, 1)) + 7 * L / (3 * np.maximum(nn - 1, 1)); lcb, ucb = mu - r, mu + r; b = int(np.argmax(mu))
            oth = np.delete(ucb, b) if len(act) > 1 else np.array([-9.])
            if len(act) == 1 or lcb[b] >= oth.max() - eps or n[act].max() >= cap: return int(act[b]), total
            act = act[ucb >= lcb.max()]
    _rows = []
    for _r in range(20):
        for _c in (2, 4): _a, _tot = _certified_c(drug_e, np.random.default_rng(8000 + _r), _c); _rows.append(dict(run=_r, constant=_c, total=_tot, returned=_names_e[_a]))
    SD = pd.DataFrame(_rows); SD.to_csv(OUT + 'e_strict_delta_cost.csv', index=False); _m = SD.groupby('constant').total.mean()
    print(f'implemented (ln 2K t(t+1)/delta, proven 1-2*delta): {_m[2]:,.0f} simulations; strict (ln 4K t(t+1)/delta, proven 1-delta): {_m[4]:,.0f}; ratio {_m[4]/_m[2]:.3f}', flush=True)

    # E.6 a harder audit of the guarantee: many near-ties ------------------------------------------
    def _subproblem(pr, ids):
        sp = Problem.__new__(Problem); sp.net = pr.net; sp.units = pr.units; sp.arms = [pr.arms[i] for i in ids]; sp.K = len(ids); sp.M = pr.M[ids]; sp.lookup = {frozenset(c): i for i, c in enumerate(sp.arms)}; return sp
    def _certified_audit(pr, rng, eps, truth, delta=0.05, m=100, cap=40000):
        K = pr.K; n = np.zeros(K); s_ = np.zeros(K); ss = np.zeros(K); act = np.arange(K); t = 0; total = 0; viol = False
        while True:
            t += 1; x = pr.draw(act, m, rng); n[act] += m; s_[act] += x.sum(1); ss[act] += (x ** 2).sum(1); total += x.size
            nn = n[act]; mu = s_[act] / nn; var = np.maximum(ss[act] / nn - mu ** 2, 0) * nn / np.maximum(nn - 1, 1); L = np.log(2 * K * t * (t + 1) / delta)
            r = np.sqrt(2 * var * L / np.maximum(nn - 1, 1)) + 7 * L / (3 * np.maximum(nn - 1, 1)); viol |= bool(np.any(np.abs(mu - truth[act]) > r)); lcb, ucb = mu - r, mu + r; b = int(np.argmax(mu))
            oth = np.delete(ucb, b) if len(act) > 1 else np.array([-9.]); cert = bool(len(act) == 1 or lcb[b] >= oth.max() - eps)
            if cert or n[act].max() >= cap: return int(act[b]), total, cert, viol
            act = act[ucb >= lcb.max()]
    gene_e = Problem(aml_e); _scr = gene_e.draw(np.arange(gene_e.K), 1500, np.random.default_rng(41)).mean(1); _top = np.sort(np.argsort(-_scr)[:15]); hard = _subproblem(gene_e, _top)
    _truth_h = hard.draw(np.arange(hard.K), 60000, np.random.default_rng(777)).mean(1); _EPSH = 0.02; _ties = int((_truth_h >= _truth_h.max() - _EPSH).sum())
    print(f'hard family: {hard.K} sets drawn from {gene_e.K}; sets within {_EPSH} of the best: {_ties}; best {"+".join(hard.arms[int(np.argmax(_truth_h))])} {_truth_h.max():.4f}', flush=True)
    _rows = []
    for _r in range(15):
        _a, _tot, _cert, _viol = _certified_audit(hard, np.random.default_rng(6000 + _r), _EPSH, _truth_h)
        _rows.append(dict(run=_r, certified=_cert, eps_optimal=bool(_truth_h.max() - _truth_h[_a] <= _EPSH), ci_violation=_viol, total=_tot, returned="+".join(hard.arms[_a]), near_ties=_ties)); print(_rows[-1], flush=True)
    HA = pd.DataFrame(_rows); HA.to_csv(OUT + 'e_hard_audit.csv', index=False)

    # E.7 an established fixed-confidence comparator: LUCB with the same empirical-Bernstein radius ---------
    def _lucb(pr, rng, eps, delta=0.05, m=100, cap=40000):
        K = pr.K; n = np.full(K, float(m)); x0 = pr.draw(np.arange(K), m, rng); s_ = x0.sum(1); ss = (x0 ** 2).sum(1); total = x0.size; t = 0
        while True:
            t += 1; mu = s_ / n; var = np.maximum(ss / n - mu ** 2, 0) * n / np.maximum(n - 1, 1); L = np.log(2 * K * t * (t + 1) / delta)
            r = np.sqrt(2 * var * L / np.maximum(n - 1, 1)) + 7 * L / (3 * np.maximum(n - 1, 1)); h = int(np.argmax(mu)); ucb = mu + r; uo = ucb.copy(); uo[h] = -9; l = int(np.argmax(uo))
            if mu[h] - r[h] >= ucb[l] - eps: return h, total, True
            if n[h] >= cap and n[l] >= cap: return h, total, False
            for a in (h, l):
                if n[a] < cap: x = pr.draw([a], m, rng)[0]; s_[a] += x.sum(); ss[a] += (x ** 2).sum(); n[a] += m; total += m
    _truth_d = drug_e.draw(np.arange(KE), 20000, np.random.default_rng(12)).mean(1); _rows = []
    for _r in range(4):
        _a, _tot, _cert = certified(drug_e, np.random.default_rng(500 + _r), eps=0.01, m=200, cap=60000); _rows.append(dict(family='druggable (K=92, eps=0.01)', method='Certified search', run=_r, total=_tot, certified=_cert, eps_optimal=bool(_truth_d.max() - _truth_d[_a] <= 0.01)))
        _a, _tot, _cert = _lucb(drug_e, np.random.default_rng(500 + _r), 0.01, m=200, cap=60000); _rows.append(dict(family='druggable (K=92, eps=0.01)', method='LUCB (EB radius)', run=_r, total=_tot, certified=_cert, eps_optimal=bool(_truth_d.max() - _truth_d[_a] <= 0.01))); print(_rows[-2:], flush=True)
    LU = pd.DataFrame(_rows); LU.to_csv(OUT + 'e_lucb_comparison.csv', index=False); print(LU.groupby(['family', 'method']).agg(runs=('run', 'count'), certified=('certified', 'sum'), eps_optimal=('eps_optimal', 'sum'), mean_total=('total', 'mean')).round(0).to_string(), flush=True)
    print('[stage E_robust finished in %.0f s]' % (time.time() - _tE), flush=True)


# ====================================================================================
# STAGE E_mechanism: Revision: marker-level decomposition of the triplet after removing STAT5A inputs
# ====================================================================================
if _run('E_mechanism'):

    _tM = time.time()
    aml_m = AMLNet(); P0m = aml_m.P; mk_names = aml_m.marker_names
    def _drop_reg_m(expr, g):
        e = re.sub(r'\s*[|&]\s*' + g + r'\b', '', expr); return re.sub(r'\b' + g + r'\s*[|&]\s*', '', e)
    def _marker_decomp(Q, n=40000, seed=11):
        cd = {'Ibr': ['BTK'], 'Mido': ['FLT3', 'KIT'], 'ERKi': ['MAPK1']}
        def mk(ds): return marker_matrix(Q, Q.run(n, frozenset(g for d in ds for g in cd[d]), np.random.default_rng(seed), steps=40)).mean(0)
        u = mk(()); sg = [mk((d,)) for d in cd]; t = mk(tuple(cd)); dd = np.clip(1 - u, 1e-6, None)
        bl = u + dd * (1 - np.prod([1 - (x - u) / dd for x in sg], axis=0)); lin = u + sum(x - u for x in sg)
        return pd.DataFrame(dict(marker=mk_names, untreated=u, triplet=t, additive=lin, bliss=bl, excess_linear=t - lin, excess_bliss=t - bl))
    _rows = []
    for _name, _edit in (('reference network', None), ('MAPK1 input to STAT5A removed', 1), ('BTK and MAPK1 inputs to STAT5A removed', 2)):
        _raw = {g: list(v) for g, v in P0m.raw.items()}
        if _edit: _raw['STAT5A'] = [((_drop_reg_m(_drop_reg_m(e, 'MAPK1'), 'BTK') if _edit == 2 else _drop_reg_m(e, 'MAPK1')), p) for e, p in _raw['STAT5A']]
        _Q = VecPBN(genes=P0m.genes, raw=_raw) if _edit else P0m
        _d = _marker_decomp(_Q); _d.insert(0, 'network', _name); _rows.append(_d)
    MD = pd.concat(_rows); MD.to_csv(OUT + 'e_mechanism_ablation.csv', index=False); print(MD.round(3).to_string(index=False))
    print('[stage E_mechanism finished in %.0f s]' % (time.time() - _tM), flush=True)

# =====================================================================================
# STAGE C_figures: Part C: figures and manifest
# =====================================================================================
if _run('C_figures'):
    _t_stage = time.time()
    # C.7 — figures for the manuscript
    import matplotlib; import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 130})
    CP, CS, CH, CW, CG = '#3B6FA0', '#7F8C8D', '#E8873A', '#C0392B', '#1B7F5C'
    D = pd.concat([pd.read_csv(f) for f in glob.glob(OUT + 'bench_*.csv') if not f.endswith(('reference.csv', 'baselines.csv', 'summary.csv', 'margin.csv'))]); D['m'] = D.method.str.replace(r' \(.*\)', '', regex=True)
    tr = pd.read_csv(OUT + 'constrained_elimination_trace.csv'); T = pd.read_csv(OUT + 'constrained_druggable_ranking.csv'); ST = pd.read_csv(OUT + 'constrained_stress_alt_calibrations.csv')
    order = ['aml_pbn_kgbn', 'calzone_cellfate', 'grieco_mapk', 'remy_tumorigenesis']; lab = {'aml_pbn_kgbn': 'AML PBN\n(K=1,793)', 'calzone_cellfate': 'Calzone\ncell fate\n(K=2,951)', 'grieco_mapk': 'Grieco\nMAPK\n(K=1,275)', 'remy_tumorigenesis': 'Remy\ntumorigenesis\n(K=5,488)'}
    fig, ax = plt.subplots(1, 3, figsize=(13.5, 3.9), gridspec_kw={'width_ratios': [1.1, 1.2, 1.3]})
    a = ax[0]; a.plot(tr.total / 1e3, tr.n_active, color=CP, lw=2); a.set_yscale('log'); a.set_xlabel('simulations used (thousands)'); a.set_ylabel('candidate sets still active'); a.set_title('a  Elimination trace (92 druggable sets)', loc='left', fontsize=9.5, fontweight='bold')
    a.axvline(tr.total.iloc[-1] / 1e3, color=CH, ls='--'); a.text(tr.total.iloc[-1] / 1e3 * 0.97, 60, 'certified', color=CH, ha='right')
    c = D[D.m == 'Certified']; a = ax[1]
    for i, nme in enumerate(order):
        v = c[c.network == nme].reduction.values; a.scatter(np.full(len(v), i) + np.linspace(-0.12, 0.12, len(v)), v, color=CP, s=28, zorder=3)
    a.axhline(10, color=CW, ls='--', lw=1.2); a.text(3.45, 10.4, 'pre-registered\n10x criterion', color=CW, ha='right', fontsize=8); a.set_xticks(range(4)); a.set_xticklabels([lab[o] for o in order], fontsize=7); a.set_ylabel('fewer simulations than uniform design\nwith the same guarantee (x)'); a.set_ylim(0, 35); a.set_title('b  Cost reduction per network', loc='left', fontsize=9.5, fontweight='bold')
    a = ax[2]; meths = ['Certified', 'Uniform', 'Successive halving', 'Greedy forward']; cols = [CH, CS, '#B0B7BA', CW]; w = 0.2
    for j, m in enumerate(meths):
        vals = [100 * D[(D.network == nme) & (D.m == m)].success.mean() for nme in order]; a.bar(np.arange(4) + (j - 1.5) * w, vals, w, color=cols[j], label=m, edgecolor='white')
    a.set_xticks(range(4)); a.set_xticklabels([lab[o].split('\n')[0] for o in order], fontsize=7.5); a.set_ylabel('returned an eps-optimal set (%)'); a.set_ylim(0, 135); a.legend(fontsize=7, ncol=2, loc='upper center'); a.set_yticks([0, 20, 40, 60, 80, 100])
    for j, m in enumerate(meths):
        for i_, nme in enumerate(order):
            v_ = 100 * D[(D.network == nme) & (D.m == m)].success.mean()
            if v_ == 0: a.text(i_ + (j - 1.5) * w, 2, '0%', ha='center', fontsize=7, color=CW); a.set_title('c  Accuracy at matched budget', loc='left', fontsize=9.5, fontweight='bold')
    plt.tight_layout(); fig.savefig(OUT + 'fig_certified_search.png', dpi=300, bbox_inches='tight'); plt.show()
    fig, ax = plt.subplots(1, 2, figsize=(12.5, 4.1), gridspec_kw={'width_ratios': [1.35, 1]}); a = ax[0]; top = T.sort_values('score', ascending=False).head(8).iloc[::-1]
    a.barh(range(len(top)), top.score, color=[CH if i == len(top) - 1 else CP for i in range(len(top))], zorder=3); a.plot(top.additive_expected, range(len(top)), 'D', color='black', ms=5, zorder=5, label='additive expectation')
    a.axvline(T.untreated.iloc[0], color=CW, ls='--', lw=1); a.set_yticks(range(len(top))); a.set_yticklabels([x.replace('FLT3-inhibitor (gilteritinib-class)', 'FLT3i').replace('ERK-inhibitor class', 'ERKi').replace('AKT-inhibitor class', 'AKTi') for x in top.combination], fontsize=7.5); a.set_xlabel('model score (fraction of 5 markers at desired state)'); a.legend(fontsize=8, loc='lower right'); a.set_title('a  Certified best druggable combinations', loc='left', fontsize=9.5, fontweight='bold')
    a = ax[1]; ords = ['Ibr+Mido+ERKi', 'Ven+Ento+ERKi', 'Ven+Mido+ERKi', 'Ven+Mido']
    for i, cn in enumerate(ords):
        v = ST[ST.combo == cn].excess.values; a.scatter(np.full(len(v), i) + np.random.default_rng(1).uniform(-0.15, 0.15, len(v)), v, s=22, color=CH if i == 0 else CS, zorder=3); a.hlines(v.mean(), i - 0.28, i + 0.28, color='black', lw=2)
    a.axhline(0, color='#333', lw=0.8); a.set_xticks(range(4)); a.set_xticklabels(ords, rotation=18, fontsize=8); a.set_ylabel('excess over additive expectation'); a.set_title('b  15 related calibrations', loc='left', fontsize=9.5, fontweight='bold')
    plt.tight_layout(); fig.savefig(OUT + 'fig_aml_application.png', dpi=300, bbox_inches='tight'); plt.show()


    # C.8 — manifest of every number the manuscript quotes
    S = pd.read_csv(OUT + 'bench_summary.csv'); U = pd.read_csv(OUT + 'bench_untreated_baselines.csv'); cs_ = json.load(open(OUT + 'constrained_summary.json')); ST = pd.read_csv(OUT + 'constrained_stress_alt_calibrations.csv'); T = pd.read_csv(OUT + 'constrained_druggable_ranking.csv')
    Dd = pd.concat([pd.read_csv(f) for f in glob.glob(OUT + 'bench_*.csv') if not f.endswith(('reference.csv', 'baselines.csv', 'summary.csv', 'margin.csv'))]); cc = Dd[Dd.method.str.startswith('Certified')]
    man = dict(benchmark_summary=S.to_dict('records'), untreated=U.to_dict('records'), constrained=cs_, certified_runs=int(len(cc)), certified_eps_optimal=int(cc.success.sum()),
               reduction_range={n: [float(x.reduction.min()), float(x.reduction.max())] for n, x in cc.groupby('network')},
               top_triplet=dict(mean_excess=float(ST[ST.combo == 'Ibr+Mido+ERKi'].excess.mean()), min_excess=float(ST[ST.combo == 'Ibr+Mido+ERKi'].excess.min()), n_calibrations=int(ST.model.nunique()), n_positive=int((ST[ST.combo == 'Ibr+Mido+ERKi'].excess > 0.02).sum())))
    json.dump(man, open(OUT + 'partC_manifest.json', 'w'), indent=1, default=float); print(json.dumps(man['top_triplet'], indent=1), '\ncertified runs:', man['certified_eps_optimal'], '/', man['certified_runs'])


    print('[stage C_figures finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE D_extended: Part D: guarantee audit, cost sensitivity, bound ablation, scaling, noise, genotype, mechanism
# =====================================================================================
if _run('D_extended'):
    _t_stage = time.time()
    # D.2b — extensions: held mutation status + marker-level output, sub-families, audited search
    class AMLNetX(AMLNet):
        """Alias kept for readability: AMLNet already supports held mutation status and marker-level output."""
        pass
    def subproblem(pr, ids):
        sp = Problem.__new__(Problem); sp.net = pr.net; sp.units = pr.units; sp.arms = [pr.arms[i] for i in ids]; sp.K = len(ids)
        sp.M = pr.M[ids]; sp.lookup = {frozenset(c): i for i, c in enumerate(sp.arms)}; return sp
    def certified_ext(pr, rng, eps=0.01, delta=0.05, m=200, cap=60000, bound='EB', truth=None):
        """Same procedure as `certified`, with a selectable radius and an audit of the confidence-interval event against known truth."""
        K = pr.K; n = np.zeros(K); s = np.zeros(K); ss = np.zeros(K); act = np.arange(K); t = 0; total = 0; viol = False
        while True:
            t += 1; x = pr.draw(act, m, rng); n[act] += m; s[act] += x.sum(1); ss[act] += (x ** 2).sum(1); total += x.size
            nn = n[act]; mu = s[act] / nn; var = np.maximum(ss[act] / nn - mu ** 2, 0) * nn / np.maximum(nn - 1, 1)
            L = np.log(2 * K * t * (t + 1) / delta)
            r = np.sqrt(2 * var * L / np.maximum(nn - 1, 1)) + 7 * L / (3 * np.maximum(nn - 1, 1)) if bound == 'EB' else np.sqrt(L / (2 * nn))
            if truth is not None: viol |= bool(np.any(np.abs(mu - truth[act]) > r))
            lcb, ucb = mu - r, mu + r; b = int(np.argmax(mu)); oth = np.delete(ucb, b) if len(act) > 1 else np.array([-9.])
            cert = bool(len(act) == 1 or lcb[b] >= oth.max() - eps)
            if cert or n[act].max() >= cap: return int(act[b]), total, cert, viol, t
            act = act[ucb >= lcb.max()]
    UNITS = {"Venetoclax": ["BCL2"], "Ibrutinib": ["BTK"], "Entospletinib": ["SYK"], "Selumetinib": ["MAP2K1", "MAP2K2"], "Midostaurin": ["FLT3", "KIT"],
             "FLT3-inhibitor (gilteritinib-class)": ["FLT3"], "AKT-inhibitor class": ["AKT1"], "ERK-inhibitor class": ["MAPK1"]}
    aml = AMLNetX(); drug_pr = Problem(aml, units=UNITS, kmax=3); K92 = drug_pr.K
    print('druggable family K =', K92)


    # D.1 — audit of the guarantee
    t0 = time.time(); truth = drug_pr.draw(np.arange(K92), 60000, np.random.default_rng(777)).mean(1); best_true = truth.max()
    print(f'reference done ({time.time()-t0:.0f}s); true best = {" + ".join(drug_pr.arms[int(np.argmax(truth))])} {best_true:.4f}; sets within 0.01 of best: {(truth >= best_true - 0.01).sum()}')
    rows = []
    _have = lambda f: os.path.exists(OUT + f) and not FULL_RUN
    for r in range(0 if _have('d_missrate_runs.csv') else 60):
        a, tot, cert, viol, rounds = certified_ext(drug_pr, np.random.default_rng(5000 + r), truth=truth)
        rows.append(dict(run=r, returned=" + ".join(drug_pr.arms[a]), true_score=truth[a], gap=best_true - truth[a], eps_optimal=bool(best_true - truth[a] <= 0.01), certified=cert, ci_violation=viol, total=tot, rounds=rounds))
    A = pd.DataFrame(rows) if rows else pd.read_csv(OUT + 'd_missrate_runs.csv'); A.to_csv(OUT + 'd_missrate_runs.csv', index=False)
    print(f"{len(A)} runs: certified {int(A.certified.sum())}; eps-optimal {int(A.eps_optimal.sum())}; any CI violation {int(A.ci_violation.sum())}; max gap {A.gap.max():.4f}; mean cost {A.total.mean():,.0f} (SD {A.total.std():,.0f}); {time.time()-t0:.0f}s")
    print('returned sets:', A.returned.value_counts().to_dict())


    # D.2 — sensitivity of cost to epsilon and delta (6 runs each)
    rows = []; uni = lambda e, d: int(np.ceil(np.log(2 * K92 / d) / (2 * e ** 2))) * K92
    for eps_, del_ in ([] if _have('d_sensitivity.csv') else [(0.005, 0.05), (0.01, 0.05), (0.02, 0.05), (0.05, 0.05), (0.01, 0.01), (0.01, 0.2)]):
        for r in range(6):
            a, tot, cert, viol, rounds = certified_ext(drug_pr, np.random.default_rng(9000 + r), eps=eps_, delta=del_, cap=100000, truth=truth)
            rows.append(dict(eps=eps_, delta=del_, run=r, total=tot, certified=cert, eps_optimal=bool(truth.max() - truth[a] <= eps_), uniform_bound=uni(eps_, del_), reduction=uni(eps_, del_) / tot))
    S = pd.DataFrame(rows) if rows else pd.read_csv(OUT + 'd_sensitivity.csv'); S.to_csv(OUT + 'd_sensitivity.csv', index=False)
    print(S.groupby(['eps', 'delta']).agg(runs=('run', 'count'), certified=('certified', 'sum'), eps_optimal=('eps_optimal', 'sum'), mean_total=('total', 'mean'), mean_reduction=('reduction', 'mean')).round(1).to_string())


    # D.3 — bound ablation
    rows = []
    for bound in ('EB', 'Hoeffding'):
        for r in range(3):
            a, tot, cert, viol, rounds = certified_ext(drug_pr, np.random.default_rng(300 + r), eps=0.02, bound=bound, cap=40000, truth=truth)
            rows.append(dict(bound=bound, run=r, total=tot, certified=cert, eps_optimal=bool(truth.max() - truth[a] <= 0.02), rounds=rounds, uniform_bound=uni(0.02, 0.05), reduction=uni(0.02, 0.05) / tot))
    B = pd.DataFrame(rows); B.to_csv(OUT + 'd_bound_ablation.csv', index=False); print(B.round(2).to_string(index=False))


    # D.4 — scaling in K
    gene_pr = Problem(AMLNetX()); Kall = gene_pr.K; t0 = time.time()
    scr = gene_pr.draw(np.arange(Kall), 1500, np.random.default_rng(41)).mean(1); print(f'screen of {Kall} sets done ({time.time()-t0:.0f}s)')
    rows = []; rs = np.random.default_rng(2024)
    for Ksub in (50, 100, 250, 500, 800):
        for rep in range(3):
            ids = np.sort(rs.choice(Kall, Ksub, replace=False)); sp = subproblem(gene_pr, ids)
            a, tot, cert, viol, rounds = certified_ext(sp, np.random.default_rng(700 + rep), eps=0.02, m=100, cap=40000)
            ties = int((scr[ids] >= scr[ids].max() - 0.04).sum()); ub = int(np.ceil(np.log(2 * Ksub / 0.05) / (2 * 0.02 ** 2))) * Ksub
            rows.append(dict(K=Ksub, rep=rep, total=tot, certified=cert, near_ties=ties, uniform_bound=ub, reduction=ub / tot))
            print(rows[-1], f'{time.time()-t0:.0f}s', flush=True)
    SC = pd.DataFrame(rows); SC.to_csv(OUT + 'd_scaling.csv', index=False); print(SC.groupby('K').agg(mean_reduction=('reduction', 'mean'), mean_near_ties=('near_ties', 'mean'), certified=('certified', 'sum')).round(2).to_string())


    # D.5 — noise sensitivity
    rows = []; t0 = time.time()
    _skip_noise = os.path.exists(OUT + 'd_noise.csv') and not FULL_RUN   # Calzone only: unaffected by the AML policy, so reuse
    for pn in (() if _skip_noise else (0.005, 0.02, 0.05)):
        net = BoolNoisy('calzone_cellfate', SPEC['calzone_cellfate'], pnoise=pn); net.kmax = 2; pr = Problem(net); K = pr.K; rng = np.random.default_rng(13)
        scr_ = pr.draw(np.arange(K), 2000, rng).mean(1); top = np.argsort(-scr_)[:30]; ref = np.array([pr.draw([a], 60000, rng).mean() for a in top]); truth_ = float(ref.max()); refmap = {int(a): float(r) for a, r in zip(top, ref)}
        untr = float(net.sim(np.zeros((20000, net.n), bool), np.random.default_rng(3)).mean()); ub = int(np.ceil(np.log(2 * K / DELTA) / (2 * EPS ** 2))) * K
        for rep in range(3):
            a, tot, cert = certified(pr, np.random.default_rng(100 + rep)); sc = refmap.get(a, float(pr.draw([a], 60000, np.random.default_rng(5)).mean()))
            rows.append(dict(noise=pn, K=K, rep=rep, untreated=untr, best=truth_, returned="+".join(pr.arms[a]), true_score=sc, eps_optimal=bool(truth_ - sc <= EPS), certified=cert, total=tot, uniform_bound=ub, reduction=ub / tot))
            print(rows[-1]['noise'], rep, f"{rows[-1]['reduction']:.1f}x opt={rows[-1]['eps_optimal']} cert={cert} ({time.time()-t0:.0f}s)", flush=True)
    NZ = pd.DataFrame(rows) if rows else pd.read_csv(OUT + 'd_noise.csv'); NZ.to_csv(OUT + 'd_noise.csv', index=False); print(NZ.groupby('noise').agg(untreated=('untreated', 'mean'), best=('best', 'mean'), eps_optimal=('eps_optimal', 'sum'), mean_reduction=('reduction', 'mean')).round(3).to_string())


    # D.6 — genotype-conditional search
    rows = []; t0 = time.time(); trip = "Ibrutinib + Midostaurin + ERK-inhibitor class"
    for f_, n_ in [(1, 1), (1, 0), (0, 1), (0, 0)]:
        g = AMLNetX(); g.hold_on = [x for x, v in zip(['FLT3', 'NPM1'], [f_, n_]) if v]; g.hold_off = [x for x, v in zip(['FLT3', 'NPM1'], [f_, n_]) if not v]
        pr = Problem(g, units=UNITS, kmax=3); a, tot, cert, viol, rounds = certified_ext(pr, np.random.default_rng(55), eps=0.01, m=200, cap=60000)
        det = draw_detail(pr, np.arange(pr.K), 20000, np.random.default_rng(66)); mkm = det.mean(1); ref = mkm.mean(1); g.detail = True; u_mk = g.sim(np.zeros((40000, g.n), bool), np.random.default_rng(67)).mean(0); g.detail = False; untr = float(u_mk.mean())
        single_mk = {x[0]: mkm[i] for i, x in enumerate(pr.arms) if len(x) == 1}; bl = lambda c: bliss_expected(u_mk, [single_mk[d] for d in c.split(' + ')])
        names_ = [" + ".join(x) for x in pr.arms]; single = {x[0]: ref[i] for i, x in enumerate(pr.arms) if len(x) == 1}
        add = lambda c: untr + sum(single[d] - untr for d in c.split(' + ')); order = np.argsort(-ref); ti = names_.index(trip)
        rows.append(dict(FLT3=f_, NPM1=n_, certified=cert, total=tot, certified_best=names_[a], best_score=ref[a], untreated=untr, best_excess=ref[a] - add(names_[a]), best_excess_bliss=ref[a] - bl(names_[a]), triplet_excess_bliss=ref[names_.index(trip)] - bl(trip),
                         triplet_score=ref[ti], triplet_rank=int(np.where(order == ti)[0][0] + 1), triplet_excess=ref[ti] - add(trip), best_pair=names_[[i for i in order if len(pr.arms[i]) == 2][0]]))
        print(rows[-1], f'{time.time()-t0:.0f}s', flush=True)
    GT = pd.DataFrame(rows); GT.to_csv(OUT + 'd_genotype.csv', index=False); print(GT.round(3).to_string(index=False))


    # D.7 — marker-level decomposition
    mk = AMLNetX(); mk.detail = True; names7 = mk.marker_names
    comp = {'Ibrutinib': ['BTK'], 'Midostaurin': ['FLT3', 'KIT'], 'ERK-inhibitor class': ['MAPK1']}
    def mprob(genes_): 
        cl = np.zeros((60000, mk.n), bool)
        for g in genes_: cl[:, mk.idx[g]] = True
        return mk.sim(cl, np.random.default_rng(8)).mean(0)
    subs = {'untreated': []}
    for r_ in (1, 2, 3):
        for c in itertools.combinations(comp, r_): subs[' + '.join(c)] = sorted({g for d in c for g in comp[d]})
    MP = pd.DataFrame({k: mprob(v) for k, v in subs.items()}, index=names7).T; MP.to_csv(OUT + 'd_marker_probs.csv')
    u = MP.loc['untreated']; trip_obs = MP.loc['Ibrutinib + Midostaurin + ERK-inhibitor class']
    indep = 1 - np.prod([1 - (MP.loc[d] - u) / (1 - u) for d in comp], axis=0); trip_bliss = u + (1 - u) * indep
    EX = pd.DataFrame(dict(untreated=u, observed_triplet=trip_obs, bliss_expected=trip_bliss, excess=trip_obs - trip_bliss)); EX.to_csv(OUT + 'd_marker_excess.csv'); print(MP.round(3).to_string()); print(); print(EX.round(3).to_string())


    print('[stage D_extended finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE D_figures: Part D: figures
# =====================================================================================
if _run('D_figures'):
    _t_stage = time.time()
    # D.8 — figures
    import matplotlib; import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
    CP, CS, CH, CW, CG = '#3B6FA0', '#7F8C8D', '#E8873A', '#C0392B', '#1B7F5C'
    A = pd.read_csv(OUT + 'd_missrate_runs.csv'); S = pd.read_csv(OUT + 'd_sensitivity.csv'); SC = pd.read_csv(OUT + 'd_scaling.csv'); NZ = pd.read_csv(OUT + 'd_noise.csv'); GT = pd.read_csv(OUT + 'd_genotype.csv'); MP = pd.read_csv(OUT + 'd_marker_probs.csv', index_col=0); EX = pd.read_csv(OUT + 'd_marker_excess.csv', index_col=0)
    fig, ax = plt.subplots(1, 3, figsize=(13.5, 3.9))
    a = ax[0]; a.hist(A.total / 1e3, bins=15, color=CP, edgecolor='white'); a.set_xlabel('simulations to certificate (thousands)'); a.set_ylabel('runs'); a.set_title(f'a  Cost over {len(A)} runs (K = 92)', loc='left', fontsize=9.5, fontweight='bold')
    a.text(0.97, 0.93, f"eps-optimal {int(A.eps_optimal.sum())}/{len(A)}\\nCI violations {int(A.ci_violation.sum())}/{len(A)}", transform=a.transAxes, ha='right', va='top', fontsize=8)
    a = ax[1]; g = S[S.delta == 0.05].groupby('eps').total.mean(); a.loglog(g.index, g.values / 1e3, 'o-', color=CP, label='certified search'); gu = S[S.delta == 0.05].groupby('eps').uniform_bound.mean(); a.loglog(gu.index, gu.values / 1e3, 's--', color=CS, label='uniform, same guarantee')
    a.set_xlabel('accuracy target epsilon'); a.set_ylabel('simulations (thousands)'); a.legend(fontsize=8); a.set_title('b  Cost versus epsilon (delta = 0.05)', loc='left', fontsize=9.5, fontweight='bold')
    a = ax[2]; m_ = SC.groupby('K').reduction.agg(['mean', 'min', 'max']); a.errorbar(m_.index, m_['mean'], yerr=[m_['mean'] - m_['min'], m_['max'] - m_['mean']], fmt='o-', color=CH, capsize=3); a.set_xscale('log'); a.set_xlabel('candidate sets K (random sub-families)'); a.set_ylabel('reduction vs uniform (x)'); a.set_ylim(0, None); a.set_title('c  Scaling with family size', loc='left', fontsize=9.5, fontweight='bold')
    plt.tight_layout(); fig.savefig(OUT + 'fig_extended_guarantee_scaling.png', dpi=300, bbox_inches='tight'); plt.show()
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.0), gridspec_kw={'width_ratios': [0.9, 1.1, 1.3]})
    a = ax[0]; n_ = NZ.groupby('noise').agg(untr=('untreated', 'mean'), best=('best', 'mean'), red=('reduction', 'mean')); x = np.arange(len(n_)); a.bar(x - 0.2, n_.untr, 0.4, color=CS, label='untreated'); a.bar(x + 0.2, n_.best, 0.4, color=CP, label='best set')
    for i, v in enumerate(n_.red): a.text(i, max(n_.untr.iloc[i], n_.best.iloc[i]) + 0.02, f"{v:.1f}x", ha='center', fontsize=8)
    a.set_xticks(x); a.set_xticklabels(n_.index); a.set_xlabel('per-node noise'); a.set_ylabel('model score'); a.set_ylim(0, 1.15); a.legend(fontsize=7.5, loc='upper left', ncol=2); a.set_title('a  Noise sensitivity (Calzone)', loc='left', fontsize=9.5, fontweight='bold')
    a = ax[1]; lab = [f"FLT3{'+' if r.FLT3 else '-'} NPM1{'+' if r.NPM1 else '-'}" for r in GT.itertuples()]; x = np.arange(len(GT)); a.bar(x - 0.27, GT.untreated, 0.27, color=CS, label='untreated'); a.bar(x, GT.triplet_score, 0.27, color=CH, label='Ibr+Mido+ERKi'); a.bar(x + 0.27, GT.best_score, 0.27, color=CP, label='certified best')
    for i, r in enumerate(GT.itertuples()): a.text(i, max(r.triplet_score, r.best_score) + 0.015, f"rank {r.triplet_rank}", ha='center', fontsize=8)
    a.set_xticks(x); a.set_xticklabels(lab, fontsize=8); a.set_ylabel('model score'); a.set_ylim(0, 1.2); a.legend(fontsize=7, loc='upper center', ncol=3); a.set_title('b  Genotype-conditional search', loc='left', fontsize=9.5, fontweight='bold')
    a = ax[2]; ex = EX.copy(); x = np.arange(len(ex)); a.bar(x - 0.27, ex.untreated, 0.27, color=CS, label='untreated'); a.bar(x, ex.bliss_expected, 0.27, color=CP, label='independence expectation'); a.bar(x + 0.27, ex.observed_triplet, 0.27, color=CH, label='triplet observed')
    a.set_xticks(x); a.set_xticklabels(ex.index, rotation=25, ha='right', fontsize=8); a.set_ylabel('P(marker in desired state)'); a.set_ylim(0, 1.3); a.legend(fontsize=7, loc='upper left', ncol=3); a.set_title('c  Marker-level decomposition', loc='left', fontsize=9.5, fontweight='bold')
    plt.tight_layout(); fig.savefig(OUT + 'fig_extended_genotype_mechanism.png', dpi=300, bbox_inches='tight'); plt.show()


    print('[stage D_figures finished in %.0f s]' % (time.time() - _t_stage), flush=True)


# =====================================================================================
# STAGE F_validation: retrospective out-of-sample check of the calibrated model on held-out PUBLIC data
# Uses only files shipped in the KGBN repository (held-out folds and cross-cohort evaluations). No new data are generated.
# It tests whether the fitted network predicts SINGLE-drug response in data it was not fitted to. It cannot test combinations.
# =====================================================================================
if _run('F_validation'):
    _t_stage = time.time()
    IN_ = R + 'inputs/'; OPT_ = R + 'optimization_results/'
    ALL_ = pd.read_csv(IN_ + 'BeatAML_AUC_5drugs.csv')[['Experiments', 'drug', 'mutation_profile', 'Measured_values']].rename(columns={'Measured_values': 'auc'})
    rng_v = np.random.default_rng(2026)
    def _perm_p(x, y, nperm=20000):
        """two-sided permutation p-value of Spearman rho (exact enumeration when n <= 8)."""
        x = np.asarray(x, float); y = np.asarray(y, float); n = len(x)
        if n < 4: return np.nan
        r0 = spearmanr(x, y)[0]
        if np.isnan(r0): return np.nan
        if n <= 8: nulls = [spearmanr(x, np.array(pp))[0] for pp in itertools.permutations(y)]
        else: nulls = [spearmanr(x, rng_v.permutation(y))[0] for _ in range(nperm)]
        return float((np.sum(np.abs(nulls) >= abs(r0) - 1e-12) + (0 if n <= 8 else 1)) / (len(nulls) + (0 if n <= 8 else 1)))
    def _boot_ci(x, y, fn, B=4000):
        x = np.asarray(x, float); y = np.asarray(y, float); out = []
        for _ in range(B):
            i = rng_v.integers(0, len(x), len(x))
            if np.ptp(x[i]) == 0 or np.ptp(y[i]) == 0: continue
            out.append(fn(x[i], y[i]))
        return (float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))) if out else (np.nan, np.nan)
    def _stats(pred, meas):
        pred = np.asarray(pred, float); meas = np.asarray(meas, float)
        return dict(n=len(pred), pearson=float(pearsonr(pred, meas)[0]) if len(pred) > 2 else np.nan, spearman=float(spearmanr(pred, meas)[0]), perm_p=_perm_p(pred, meas))
    rows = []
    # ---- (1) held-out drug (LODO) and held-out mutation profile (LOCO) folds ----
    held = []
    for kind, nfold in (('held-out drug', 5), ('held-out genotype', 8)):
        tag_ = 'LODO' if kind == 'held-out drug' else 'LOCO'
        for k in range(nfold):
            d = OPT_ + f'BeatAML_AUC_5drugs_{tag_}_fold_{k}/'
            te = pd.read_csv(d + 'Test_Evaluation/detailed_results.csv').merge(ALL_, left_on='Experiment_ID', right_on='Experiments')
            te['fold'] = k; te['kind'] = kind; te['label'] = te.drug.iloc[0] if kind == 'held-out drug' else te.mutation_profile.iloc[0]
            if kind == 'held-out drug': te['baseline'] = [ALL_[(ALL_.mutation_profile == g) & (ALL_.drug != dr)].auc.mean() for g, dr in zip(te.mutation_profile, te.drug)]
            else: te['baseline'] = [ALL_[(ALL_.drug == dr) & (ALL_.mutation_profile != g)].auc.mean() for g, dr in zip(te.mutation_profile, te.drug)]
            held.append(te)
            for who, col in (('network model', 'Predicted_Value'), ('trivial baseline', 'baseline')):
                st = _stats(te[col], te.Original_Measured_Value); rows.append(dict(analysis=kind, test_set=te.label.iloc[0], predictor=who, **st))
    H = pd.concat(held)
    for kind in ('held-out drug', 'held-out genotype'):
        h = H[H.kind == kind]
        for who, col in (('network model', 'Predicted_Value'), ('trivial baseline', 'baseline')):
            st = _stats(h[col], h.Original_Measured_Value); lo, hi = _boot_ci(h[col], h.Original_Measured_Value, lambda a, b: spearmanr(a, b)[0])
            rows.append(dict(analysis=kind, test_set='all held-out points pooled', predictor=who, **st, spearman_lo=lo, spearman_hi=hi))
    # ---- (2) cross-cohort evaluation of the fitted models ----
    cross = [('Waves 3+4 fit -> Waves 1+2 data', OPT_ + 'BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW/Waves1+2/detailed_results.csv', IN_ + 'BeatAML_AUC_5drugs_Waves1+2.csv', IN_ + 'BeatAML_AUC_5drugs_Waves3+4.csv'),
             ('Waves 1+2 fit -> Waves 3+4 data', OPT_ + 'BeatAML_-AUC_5drugs_Waves1+2_AND+OR+IW/Waves3+4/detailed_results.csv', IN_ + 'BeatAML_AUC_5drugs_Waves3+4.csv', IN_ + 'BeatAML_AUC_5drugs_Waves1+2.csv'),
             ('Waves 3+4 fit -> FPMTB cohort', OPT_ + 'BeatAML_-AUC_5drugs_Waves3+4_AND+OR+IW/FPMTB_sDSS_5drugs_min5/detailed_results.csv', IN_ + 'FPMTB_sDSS_5drugs_min5.csv', IN_ + 'BeatAML_AUC_5drugs_Waves3+4.csv'),
             ('Waves 1+2 fit -> FPMTB cohort', OPT_ + 'BeatAML_-AUC_5drugs_Waves1+2_AND+OR+IW/FPMTB_sDSS_5drugs_min5/detailed_results.csv', IN_ + 'FPMTB_sDSS_5drugs_min5.csv', IN_ + 'BeatAML_AUC_5drugs_Waves1+2.csv')]
    crossd = []
    for name, dres, test_in, train_in in cross:
        if not os.path.exists(dres): print('[skipped]', name, '(file missing)'); continue
        te = pd.read_csv(dres).merge(pd.read_csv(test_in)[['Experiments', 'drug'] + (['mutation_profile'] if 'mutation_profile' in pd.read_csv(test_in).columns else [])], left_on='Experiment_ID', right_on='Experiments')
        tr = pd.read_csv(train_in)
        key = ['drug', 'mutation_profile'] if 'mutation_profile' in te.columns else ['drug']
        te = te.merge(tr.groupby(key, as_index=False).Measured_values.mean().rename(columns={'Measured_values': 'baseline'}), on=key, how='left') if 'mutation_profile' in te.columns else te.merge(tr[tr.mutation_profile == 'No mutation'][['drug', 'Measured_values']].rename(columns={'Measured_values': 'baseline'}), on='drug', how='left')
        if 'FPMTB' in name:   # sDSS is a sensitivity score (higher = more sensitive) whereas AUC and the network output increase with resistance: reverse the sign so agreement is positive
            te['Predicted_Value'] = -te.Predicted_Value; te['baseline'] = -te.baseline; name = name + ' (sign reversed)'
        te['name'] = name; crossd.append(te)
        for who, col in (('network model', 'Predicted_Value'), ('persistence of training-cohort data', 'baseline')):
            t_ = te.dropna(subset=[col])
            if len(t_) < 4: continue
            st = _stats(t_[col], t_.Original_Measured_Value); lo, hi = _boot_ci(t_[col], t_.Original_Measured_Value, lambda a, b: spearmanr(a, b)[0])
            rows.append(dict(analysis='cross-cohort', test_set=name, predictor=who, **st, spearman_lo=lo, spearman_hi=hi))
        # within-drug (genotype ordering) for the two drugs that form the pair/triplet
        if 'mutation_profile' in te.columns:
            for dr in ('Ibrutinib', 'Midostaurin'):
                t_ = te[te.drug == dr]
                if len(t_) >= 5: rows.append(dict(analysis='cross-cohort, within drug', test_set=f'{name}: {dr}', predictor='network model', **_stats(t_.Predicted_Value, t_.Original_Measured_Value)))
    V = pd.DataFrame(rows).round(4); V.to_csv(OUT + 'validation_heldout_summary.csv', index=False)
    H.to_csv(OUT + 'validation_heldout_points.csv', index=False)
    if crossd: pd.concat(crossd).to_csv(OUT + 'validation_crosscohort_points.csv', index=False)
    print(V.to_string(index=False))
    # ---- (3) does the triplet ranking depend on how well a calibration predicts held-out data? ----
    if os.path.exists(OUT + 'e_per_calibration_search.csv'):   # optional: only available after stages C_druggable / E_robust
        PC_ = pd.read_csv(OUT + 'e_per_calibration_search.csv'); PC_['kind'] = np.where(PC_.calibration.str.contains('LODO'), 'held-out drug fit', np.where(PC_.calibration.str.contains('LOCO'), 'held-out genotype fit', 'cohort fit'))
        print(PC_.groupby('kind').agg(n=('triplet_rank', 'size'), best=('triplet_is_certified_best', 'sum'), exc_min=('excess_linear', 'min'), exc_max=('excess_linear', 'max')))
    else: print('[note] e_per_calibration_search.csv not found (run C_druggable and E_robust first); skipping the calibration summary')
    # ---- figure ----
    CM_, CB_, INK_ = '#2f6f9f', '#9aa5a6', '#2b2b2b'
    S_ = V[(V.predictor.isin(['network model', 'trivial baseline', 'persistence of training-cohort data'])) & (V.analysis.isin(['held-out drug', 'held-out genotype', 'cross-cohort'])) & (V.test_set != 'all held-out points pooled')]
    order = list(S_[S_.predictor == 'network model'].drop_duplicates('test_set').test_set)
    fig, ax = plt.subplots(1, 2, figsize=(12.5, 5.2), gridspec_kw={'width_ratios': [1.25, 1]}); a = ax[0]
    for i, t in enumerate(order):
        m_ = S_[(S_.test_set == t) & (S_.predictor == 'network model')].iloc[0]; b_ = S_[(S_.test_set == t) & (S_.predictor != 'network model')]
        if len(b_): a.plot([m_.spearman, b_.iloc[0].spearman], [i, i], color='#cfd4d4', lw=1.2, zorder=1); a.scatter(b_.iloc[0].spearman, i, s=42, color=CB_, zorder=3, edgecolor='white', linewidth=1.2)
        a.scatter(m_.spearman, i, s=52, color=CM_, zorder=4, edgecolor='white', linewidth=1.2)
    a.axvline(0, color=INK_, lw=0.8); a.set_yticks(range(len(order))); a.set_yticklabels([({'held-out drug': 'Held-out drug: ', 'held-out genotype': 'Held-out genotype: '}.get(S_[S_.test_set == o].analysis.iloc[0], '') + o.replace('_', ' ')) for o in order], fontsize=7.5); a.invert_yaxis()
    a.set_xlabel('Spearman correlation with measured AUC on held-out data', fontsize=8.5); a.set_title('a  Held-out agreement (network model vs trivial baseline)', loc='left', fontsize=9.5, fontweight='bold')
    a.scatter([], [], s=52, color=CM_, label='network model'); a.scatter([], [], s=42, color=CB_, label='baseline (trivial or training-data persistence)'); a.legend(frameon=False, fontsize=8, loc='lower left')
    for s_ in ('top', 'right'): a.spines[s_].set_visible(False)
    a = ax[1]
    if crossd:
        te = crossd[0]; cols = {'Venetoclax': '#2f6f9f', 'Ibrutinib': '#c8782a', 'Entospletinib': '#6a9a5a', 'Selumetinib': '#8e6bb0', 'Midostaurin': '#b5473f'}
        for dr, g in te.groupby('drug'): a.scatter(g.Predicted_Value, g.Original_Measured_Value, s=34, color=cols.get(dr, '#777'), label=dr, edgecolor='white', linewidth=0.8, zorder=3)
        r_ = spearmanr(te.Predicted_Value, te.Original_Measured_Value)[0]; a.set_xlabel('network prediction (fit on Waves 3+4)', fontsize=8.5); a.set_ylabel('measured AUC, Waves 1+2', fontsize=8.5)
        a.set_title(f'b  Waves 1+2 held-out cohort ($n$={len(te)}, Spearman {r_:.2f})', loc='left', fontsize=9.5, fontweight='bold'); a.legend(frameon=False, fontsize=7.5)
    for s_ in ('top', 'right'): a.spines[s_].set_visible(False)
    plt.tight_layout(); fig.savefig(OUT + 'fig_validation_heldout.png', dpi=300, bbox_inches='tight'); plt.close(fig)
    print('[stage F_validation finished in %.0f s]' % (time.time() - _t_stage), flush=True)


# =====================================================================================
# STAGE G_decoy: computational null tests of the triplet (no external data)
#   (1) decoy drug-target maps: keep the 8 drug units and their sizes but give each unit random targets among the 17 clampable genes;
#       run the same 92-set search and record the best set's score and its excess over the additive / Bliss expectation.
#       This asks whether a result as strong as the real one needs the real drug-to-gene map or arises for arbitrary maps.
#   (2) single-gene loss of function: hold one gene off throughout (also when untreated) and repeat the 92-set search.
# =====================================================================================
if _run('G_decoy'):
    _t_stage = time.time()
    UN_ = {"Venetoclax": ["BCL2"], "Ibrutinib": ["BTK"], "Entospletinib": ["SYK"], "Selumetinib": ["MAP2K1", "MAP2K2"], "Midostaurin": ["FLT3", "KIT"],
           "FLT3-inhibitor (gilteritinib-class)": ["FLT3"], "AKT-inhibitor class": ["AKT1"], "ERK-inhibitor class": ["MAPK1"]}
    TRIP_ = 'Ibrutinib + Midostaurin + ERK-inhibitor class'
    NDEC = int(os.environ.get('DECOY_N', 400)); MDEC = int(os.environ.get('DECOY_M', 500))
    def _search92(net, units, m, seed):
        pr = Problem(net, units=units, kmax=3); det = draw_detail(pr, np.arange(pr.K), m, np.random.default_rng(seed)); mk = det.mean(1); mu = mk.mean(1)
        u_mk = untreated_markers(net, 20000, seed + 1); u = float(u_mk.mean()); names = [' + '.join(x) for x in pr.arms]
        sg = {x[0]: i for i, x in enumerate(pr.arms) if len(x) == 1}
        add = np.array([u + sum(mu[sg[d]] - u for d in x) for x in pr.arms]); bl = np.array([bliss_expected(u_mk, [mk[sg[d]] for d in x]) for x in pr.arms])
        return pr, names, mu, mu - add, mu - bl, u
    net = AMLNet(); clampable = list(net.targets)
    rows = []
    # real map, replicated to show the noise of this procedure
    real_rows = []
    for rep in range(int(os.environ.get('DECOY_REPS', 10))):
        pr, names, mu, ea, eb, u = _search92(net, UN_, MDEC, 9000 + rep); b = int(np.argmax(mu)); ti = names.index(TRIP_)
        real_rows.append(dict(map='real', rep=rep, best=names[b], best_score=mu[b], best_excess_add=ea[b], best_excess_bliss=eb[b], triplet_rank=int((mu > mu[ti]).sum() + 1), triplet_score=mu[ti], triplet_excess_add=ea[ti], untreated=u, max_excess_add=ea.max()))
    R_ = pd.DataFrame(real_rows); print(R_.round(3).to_string(index=False))
    rng_d = np.random.default_rng(777); t0 = time.time()
    for k in range(NDEC):
        un = {d: list(rng_d.choice(clampable, size=len(g), replace=False)) for d, g in UN_.items()}
        pr, names, mu, ea, eb, u = _search92(net, un, MDEC, 20000 + k); b = int(np.argmax(mu))
        rows.append(dict(map='decoy', rep=k, best=names[b], best_genes='|'.join(sorted(set(g for d in pr.arms[b] for g in un[d]))), best_score=mu[b], best_excess_add=ea[b], best_excess_bliss=eb[b], untreated=u, max_excess_add=ea.max()))
        if k % 50 == 0: print(f'decoy map {k}/{NDEC}  ({time.time()-t0:.0f}s)', flush=True)
    D_ = pd.DataFrame(rows); D_.to_csv(OUT + 'decoy_maps.csv', index=False); R_.to_csv(OUT + 'decoy_real_replicates.csv', index=False)
    rs, re_ = R_.best_score.mean(), R_.best_excess_add.mean()
    summ = dict(n_decoy=NDEC, sims_per_set=MDEC, real_best_score=float(rs), real_best_excess_add=float(re_), real_best_excess_bliss=float(R_.best_excess_bliss.mean()),
                p_score=float((1 + (D_.best_score >= rs).sum()) / (1 + NDEC)), p_excess_add=float((1 + (D_.best_excess_add >= re_).sum()) / (1 + NDEC)), p_excess_bliss=float((1 + (D_.best_excess_bliss >= R_.best_excess_bliss.mean()).sum()) / (1 + NDEC)),
                p_max_excess_add=float((1 + (D_.max_excess_add >= R_.max_excess_add.mean()).sum()) / (1 + NDEC)),
                decoy_score_median=float(D_.best_score.median()), decoy_score_q95=float(D_.best_score.quantile(0.95)), decoy_excess_median=float(D_.best_excess_add.median()), decoy_excess_q95=float(D_.best_excess_add.quantile(0.95)),
                frac_decoy_score_ge_real=float((D_.best_score >= rs).mean()), frac_decoy_excess_ge_real=float((D_.best_excess_add >= re_).mean()))
    json.dump(summ, open(OUT + 'decoy_summary.json', 'w'), indent=1); print(json.dumps(summ, indent=1))
    # ---- single-gene loss of function ----
    KO = []; keep = [g for g in net.P.genes if g not in AML_APOP + AML_SURV + ('NPM1', 'DNMT3A')]
    for g in [None] + keep:
        n2 = AMLNet(); n2.hold_off = (g,) if g else ()
        pr, names, mu, ea, eb, u = _search92(n2, UN_, 1500, 31000); b = int(np.argmax(mu)); ti = names.index(TRIP_)
        order = np.argsort(-mu)
        KO.append(dict(gene_off=g or 'none (reference)', best=names[b], triplet_is_best=(b == ti), triplet_rank=int((mu > mu[ti]).sum() + 1), second=names[order[1]], triplet_score=mu[ti], best_score=mu[b], untreated=u, triplet_excess_add=ea[ti], triplet_excess_bliss=eb[ti]))
        print(KO[-1]['gene_off'], KO[-1]['best'], 'rank', KO[-1]['triplet_rank'], f"exc {ea[ti]:+.3f}", flush=True)
    KOd = pd.DataFrame(KO); KOd.to_csv(OUT + 'gene_loss_of_function.csv', index=False)
    # ---- figure ----
    CM_, CH_ = '#2f6f9f', '#c8782a'
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.9))
    for a, col, rv, ttl, xl in ((ax[0], 'best_score', R_.best_score.mean(), 'a  Best set score', 'model score of the best 92-set member'), (ax[1], 'best_excess_add', R_.best_excess_add.mean(), 'b  Excess of the best set over additivity', 'excess over additive expectation')):
        a.hist(D_[col], bins=30, color='#9aa5a6', zorder=3); a.axvline(rv, color=CH_, lw=2, zorder=4); a.set_xlabel(xl, fontsize=8.5); a.set_ylabel('decoy maps', fontsize=8.5); a.set_title(ttl, loc='left', fontsize=9.5, fontweight='bold')
        a.text(rv, a.get_ylim()[1] * 0.92, ' real map', color=CH_, fontsize=8, va='top', ha='left' if rv < D_[col].max() else 'right')
        for s_ in ('top', 'right'): a.spines[s_].set_visible(False)
    a = ax[2]; kk = KOd.iloc[1:]; a.scatter(kk.triplet_rank, range(len(kk)), s=40, color=[CH_ if r == 1 else CM_ for r in kk.triplet_rank], zorder=3, edgecolor='white', linewidth=0.8)
    a.set_yticks(range(len(kk))); a.set_yticklabels(kk.gene_off, fontsize=7.5); a.invert_yaxis(); a.set_xlabel('rank of the triplet when the gene is held off', fontsize=8.5); a.set_title('c  Single-gene loss of function', loc='left', fontsize=9.5, fontweight='bold'); a.axvline(1, color='#cfd4d4', lw=1, zorder=1)
    for s_ in ('top', 'right'): a.spines[s_].set_visible(False)
    plt.tight_layout(); fig.savefig(OUT + 'fig_decoy_knockout.png', dpi=300, bbox_inches='tight'); plt.close(fig)
    print('[stage G_decoy finished in %.0f s]' % (time.time() - _t_stage), flush=True)


# =====================================================================================
# STAGE H_pools: simulate fixed reward pools for the method comparison (counts of each reward level per candidate)
# STAGE H_methods: certified search against other fixed-confidence methods, ablations, and a controlled gap-structure test
# =====================================================================================
H_UNITS = {"Venetoclax": ["BCL2"], "Ibrutinib": ["BTK"], "Entospletinib": ["SYK"], "Selumetinib": ["MAP2K1", "MAP2K2"], "Midostaurin": ["FLT3", "KIT"],
           "FLT3-inhibitor (gilteritinib-class)": ["FLT3"], "AKT-inhibitor class": ["AKT1"], "ERK-inhibitor class": ["MAPK1"]}
H_POOL_N = {'f1': 100000, 'f2': 40000, 'calzone_cellfate': 40000, 'grieco_mapk': 40000, 'remy_tumorigenesis': 40000}     # simulations per candidate in each pool
def _h_problem(name):
    if name in SPEC and name != 'aml_pbn_kgbn': return Problem(BoolNoisy(name, SPEC[name]))     # published Boolean networks, pre-registered objectives
    return Problem(AMLNet(), units=H_UNITS, kmax=3) if name == 'f1' else Problem(AMLNet())
if _run('H_pools'):
    _t_stage = time.time()
    for _name in os.environ.get('POOLS', 'f1,f2').split(','):
        _fn = OUT + f'pool_{_name}_counts.npy'; _pf = OUT + f'pool_{_name}_partial.npz'
        if os.path.exists(_fn): print('pool', _name, 'exists'); continue
        _pr = _h_problem(_name); _nm = (len(_pr.net.on) + len(_pr.net.off)) if hasattr(_pr.net, 'on') else (len(AML_APOP) + len(AML_SURV)); _step = 2000; _n = H_POOL_N[_name]; _C = np.zeros((_pr.K, _nm + 1), np.int64); _done = 0
        _seed0 = {'f1': 7100, 'f2': 7200, 'calzone_cellfate': 7300, 'grieco_mapk': 7400, 'remy_tumorigenesis': 7500}[_name]; _rng = np.random.default_rng(_seed0)
        if os.path.exists(_pf): _z = np.load(_pf); _C = _z['C']; _done = int(_z['done']); _rng = np.random.default_rng(_seed0 + _done)   # resume with a fresh stream
        while _done < _n:
            _x = _pr.draw(np.arange(_pr.K), _step, _rng, chunk=200000); _lv = np.rint(_x * _nm).astype(int)
            for _k in range(_nm + 1): _C[:, _k] += (_lv == _k).sum(1)
            _done += _step
            if (_done // _step) % 5 == 0: np.savez(_pf, C=_C, done=_done); print(f'  pool {_name}: {_done}/{_n}  ({time.time()-_t_stage:.0f}s)', flush=True)
        np.save(_fn, _C); print('pool', _name, 'saved', _C.shape, _C.sum(1)[:3], flush=True)
    print('[stage H_pools finished in %.0f s]' % (time.time() - _t_stage), flush=True)

class PoolArms:
    """Candidate family replayed from a simulated pool: every candidate's reward distribution is the pool's empirical distribution (a finite set of
    reward levels), so draws are i.i.d. with a KNOWN true mean and ground truth is exact. Draws are multinomial counts over the reward levels."""
    def __init__(self, C):
        C = np.asarray(C, float); self.K, self.S = C.shape; self.p = C / C.sum(1, keepdims=True); self.v = np.arange(self.S) / (self.S - 1.0); self.v2 = self.v ** 2
        self.truth = self.p @ self.v; self.best = float(self.truth.max())
    def sub(self, ids): Q = PoolArms.__new__(PoolArms); Q.K = len(ids); Q.S = self.S; Q.p = self.p[ids]; Q.v = self.v; Q.v2 = self.v2; Q.truth = self.truth[ids]; Q.best = float(Q.truth.max()); return Q
    def draw(self, ids, m, rng):
        c = rng.multinomial(int(m), self.p[np.asarray(ids)]); return c @ self.v, c @ self.v2          # sum and sum of squares of the m rewards, per candidate
WS = (1, 16, 128)      # parallel workers for the wall-clock model
def _wall(parts, W): return float(sum(-(-a // W) * b for a, b in parts))     # parts = [(batches run in the round, simulations per batch)]; a round takes ceil(batches/W) batch-times
def _eb(var, n, L): return np.sqrt(2 * var * L / np.maximum(n - 1, 1)) + 7 * L / (3 * np.maximum(n - 1, 1))
def _ok(P, a, eps): return bool(P.best - P.truth[a] <= eps)
def run_elim(P, rng, eps, delta=0.05, m=100, cap=40000, radius='eb', eliminate=True, schedule='linear'):
    """Certified search (successive elimination) and its ablations: radius='hoeffding'; eliminate=False (stop rule only); schedule='doubling' (checks at n = m, 2m, 4m, ...)."""
    K = P.K; n = np.zeros(K); s = np.zeros(K); ss = np.zeros(K); act = np.arange(K); total = 0; t = 0; viol = False; nprev = 0; parts = []
    while True:
        t += 1; nt = m * t if schedule == 'linear' else m * 2 ** (t - 1); add = nt - nprev; nprev = nt; parts.append((len(act), add))
        a_s, a_ss = P.draw(act, add, rng); s[act] += a_s; ss[act] += a_ss; n[act] = nt; total += add * len(act)
        mu = s[act] / nt; L = np.log(2 * K * t * (t + 1) / delta)
        if radius == 'eb': var = np.maximum(ss[act] / nt - mu ** 2, 0) * nt / (nt - 1); r = _eb(var, nt, L)
        else: r = np.full(len(act), np.sqrt(L / (2 * nt)))
        viol |= bool(np.any(np.abs(mu - P.truth[act]) > r)); lcb, ucb = mu - r, mu + r; b = int(np.argmax(mu))
        oth = np.delete(ucb, b) if len(act) > 1 else np.array([-9.])
        if len(act) == 1 or lcb[b] >= oth.max() - eps: return int(act[b]), total, True, viol, t, {W: _wall(parts, W) for W in WS}
        if (nt >= cap) if schedule == 'linear' else (2 * nt > cap): return int(act[b]), total, False, viol, t, {W: _wall(parts, W) for W in WS}
        if eliminate: act = act[ucb >= lcb.max()]
def run_index(P, rng, eps, delta=0.05, m=100, cap=40000, rule='lucb'):
    """LUCB (Kaufmann et al. 2016) and UGapE (Gabillon et al. 2012) with the SAME empirical-Bernstein radius and the SAME confidence sequence as certified
    search. The union bound is over (candidate, number of batches pulled), which is valid under adaptive sampling when each candidate has its own reward stream."""
    K = P.K; s, ss = P.draw(np.arange(K), m, rng); n = np.full(K, float(m)); total = m * K; viol = False; ar = np.arange(K); rounds = 1; parts = [(K, m)]
    while True:
        j = n / m; mu = s / n; var = np.maximum(ss / n - mu ** 2, 0) * n / (n - 1); L = np.log(2 * K * j * (j + 1) / delta); r = _eb(var, n, L); lcb, ucb = mu - r, mu + r
        viol |= bool(np.any(np.abs(mu - P.truth) > r))
        if rule == 'lucb':
            h = int(np.argmax(mu)); uo = ucb.copy(); uo[h] = -9; l = int(np.argmax(uo))
            if lcb[h] >= ucb[l] - eps: return h, total, True, viol, rounds, {W: _wall(parts, W) for W in WS}
            pulls = (h, l); out = h
        else:   # UGapE: B_k = max_{i != k} UCB_i - LCB_k; recommend J = argmin B_k, stop when B_J <= eps
            o = np.argsort(-ucb)[:2]; maxo = np.where(ar == o[0], ucb[o[1]], ucb[o[0]]); B = maxo - lcb; J = int(np.argmin(B))
            if B[J] <= eps: return J, total, True, viol, rounds, {W: _wall(parts, W) for W in WS}
            uo = ucb.copy(); uo[J] = -9; l = int(np.argmax(uo)); pulls = (J, l) if r[J] >= r[l] else (l, J); out = J
        # LUCB samples both the leader and its strongest challenger each round; UGapE samples only the one with the wider interval
        todo = [x for x in (pulls if rule == 'lucb' else pulls[:1] + pulls[1:]) if n[x] < cap]
        if rule == 'ugape': todo = todo[:1]
        if not todo: return out, total, False, viol, rounds, {W: _wall(parts, W) for W in WS}
        for a in todo: x, y = P.draw([a], m, rng); s[a] += x[0]; ss[a] += y[0]; n[a] += m; total += m
        rounds += 1; parts.append((len(todo), m))
def run_uniform_B(P, B, rng):
    m = max(int(B // P.K), 1); x, _ = P.draw(np.arange(P.K), m, rng); return int(np.argmax(x)), m * P.K
def run_halving_B(P, B, rng):
    act = np.arange(P.K); Rr = int(np.ceil(np.log2(P.K))); used = 0
    for _ in range(Rr):
        if len(act) == 1: break
        m = max(int(B // (len(act) * Rr)), 1); x, _y = P.draw(act, m, rng); used += m * len(act); act = act[np.argsort(-x)[:int(np.ceil(len(act) / 2))]]
    return int(act[0]), used
def uniform_bound(K, eps, delta=0.05): return int(np.ceil(np.log(2 * K / delta) / (2 * eps ** 2))) * K

if _run('H_methods'):
    _t_stage = time.time(); _pools = {}
    for _nm_ in ('f1', 'f2', 'calzone_cellfate', 'grieco_mapk', 'remy_tumorigenesis'):
        _fn = OUT + f'pool_{_nm_}_counts.npy'
        if not os.path.exists(_fn):
            if _nm_ in ('f1', 'f2'): sys.exit(f'missing {_fn}; run stage H_pools first')
            continue
        _pools[_nm_] = PoolArms(np.load(_fn))
    _top15 = np.argsort(-_pools['f2'].truth)[:15]
    FAMS = {'AML druggable sets (K=92)': (_pools['f1'], 200, 100000), 'AML 3-gene sets (K=833)': (_pools['f2'], 100, 40000), 'AML top-15 gene sets': (_pools['f2'].sub(_top15), 100, 40000)}
    for _k_, _lab_ in (('calzone_cellfate', 'Calzone cell fate (K=2,951)'), ('grieco_mapk', 'Grieco MAPK (K=1,275)'), ('remy_tumorigenesis', 'Remy tumorigenesis (K=5,488)')):
        if _k_ in _pools: FAMS[_lab_] = (_pools[_k_], 100, 40000)
    PLAN = [('AML druggable sets (K=92)', 0.01, 100), ('AML druggable sets (K=92)', 0.02, 100), ('AML druggable sets (K=92)', 0.05, 100),
            ('AML 3-gene sets (K=833)', 0.02, 50), ('AML 3-gene sets (K=833)', 0.05, 50), ('AML top-15 gene sets', 0.02, 100), ('AML top-15 gene sets', 0.01, 100),
            ('Calzone cell fate (K=2,951)', 0.02, 30), ('Calzone cell fate (K=2,951)', 0.05, 30), ('Grieco MAPK (K=1,275)', 0.02, 30), ('Grieco MAPK (K=1,275)', 0.05, 30),
            ('Remy tumorigenesis (K=5,488)', 0.02, 20), ('Remy tumorigenesis (K=5,488)', 0.05, 20)]
    PLAN = [x for x in PLAN if x[0] in FAMS]
    METHODS = [('Certified search (EB, successive elimination)', lambda P, r, e, m, c: run_elim(P, r, e, m=m, cap=c)),
               ('LUCB (same EB radius)', lambda P, r, e, m, c: run_index(P, r, e, m=m, cap=c, rule='lucb')),
               ('UGapE (same EB radius)', lambda P, r, e, m, c: run_index(P, r, e, m=m, cap=c, rule='ugape')),
               ('Ablation: no elimination (stop rule only)', lambda P, r, e, m, c: run_elim(P, r, e, m=m, cap=c, eliminate=False)),
               ('Ablation: Hoeffding radius', lambda P, r, e, m, c: run_elim(P, r, e, m=m, cap=c, radius='hoeffding')),
               ('Ablation: doubling checkpoints', lambda P, r, e, m, c: run_elim(P, r, e, m=m, cap=c, schedule='doubling'))]
    rows = []; acc = []
    for fam, eps, R in PLAN:
        P, m, cap = FAMS[fam]; ub = uniform_bound(P.K, eps); near = int((P.best - P.truth <= eps).sum()) - 1
        print(f'== {fam}  eps={eps}  K={P.K}  near-ties(within eps)={near}  uniform bound={ub:,}', flush=True)
        for mi, (mn, fn_) in enumerate(METHODS):
            for rep in range(R):
                rng = np.random.default_rng(910000 + 1000 * mi + rep + int(eps * 1e4) + 17 * len(fam))
                a, tot, cert, viol, rnd, wl = fn_(P, rng, eps, m, cap)
                rows.append(dict(family=fam, K=P.K, eps=eps, method=mn, rep=rep, total=tot, certified=cert, eps_optimal=_ok(P, a, eps), violation=viol, rounds=rnd, wall1=wl[1], wall16=wl[16], wall128=wl[128], uniform_bound=ub, near_ties=near))
                if mn.startswith('Certified'):     # matched-budget fixed-budget baselines, same budget as this certified run
                    r2 = np.random.default_rng(990000 + rep + int(eps * 1e4) + 17 * len(fam)); a_u, _b = run_uniform_B(P, tot, r2); a_h, _b2 = run_halving_B(P, tot, r2)
                    acc.append(dict(family=fam, eps=eps, rep=rep, budget=tot, uniform_ok=_ok(P, a_u, eps), halving_ok=_ok(P, a_h, eps)))
        d = pd.DataFrame([x for x in rows if x['family'] == fam and x['eps'] == eps]); g = d.groupby('method', sort=False).agg(mean=('total', 'mean'), cert=('certified', 'mean'), opt=('eps_optimal', 'mean'), viol=('violation', 'sum'))
        print(g.round(3).to_string(), flush=True)
    pd.DataFrame(rows).to_csv(OUT + 'h_method_comparison.csv', index=False); pd.DataFrame(acc).to_csv(OUT + 'h_matched_budget.csv', index=False)
    # uniform design with the Hoeffding guarantee (analytic cost; accuracy by simulation)
    ur = []
    for fam, eps, R in PLAN:
        P, m, cap = FAMS[fam]; n_u = int(np.ceil(np.log(2 * P.K / 0.05) / (2 * eps ** 2))); ok = 0
        for rep in range(R):
            x, _ = P.draw(np.arange(P.K), n_u, np.random.default_rng(770000 + rep)); ok += _ok(P, int(np.argmax(x)), eps)
        ur.append(dict(family=fam, eps=eps, runs=R, per_candidate=n_u, total=n_u * P.K, eps_optimal=ok))
    pd.DataFrame(ur).to_csv(OUT + 'h_uniform_guaranteed.csv', index=False)
    # batch-size ablation
    br = []
    for fam, eps, R in (('AML druggable sets (K=92)', 0.01, 60), ('AML 3-gene sets (K=833)', 0.02, 30)):
        P, _m, cap = FAMS[fam]
        for m in (50, 100, 200, 400, 1000):
            for rep in range(R):
                a, tot, cert, viol, _r, _w = run_elim(P, np.random.default_rng(830000 + 31 * m + rep), eps, m=m, cap=cap); br.append(dict(family=fam, eps=eps, m=m, rep=rep, total=tot, certified=cert, eps_optimal=_ok(P, a, eps), violation=viol))
    pd.DataFrame(br).to_csv(OUT + 'h_batch_ablation.csv', index=False)
    # controlled test: family size K and number of near-ties j varied separately (candidates from the 833-set pool; j best sets always included, others random)
    P0 = _pools['f2']; order = np.argsort(-P0.truth); gr = []; eps = 0.02; rngc = np.random.default_rng(850000)
    for K_, j_ in [(100, 1), (100, 3), (100, 5), (100, 10), (100, 20), (50, 5), (200, 5), (400, 5), (833, 5)]:
        for fam_i in range(5):
            rest = rngc.choice(order[j_:], K_ - j_, replace=False) if K_ < 833 else order[j_:]; ids = np.concatenate([order[:j_], rest]); P = P0.sub(ids)
            gap = P.best - P.truth; Hc = float((1.0 / np.maximum(gap, eps) ** 2).sum()); near = int((gap <= 0.04).sum() - 1); ub = uniform_bound(K_, eps)
            for rep in range(6):
                a, tot, cert, viol, _r, _w = run_elim(P, np.random.default_rng(870000 + 100 * fam_i + rep + K_ + 7 * j_), eps, m=100, cap=40000)
                gr.append(dict(K=K_, top_j=j_, subfamily=fam_i, rep=rep, H_eps=Hc, near_ties_004=near, total=tot, certified=cert, eps_optimal=_ok(P, a, eps), violation=viol, uniform_bound=ub))
    pd.DataFrame(gr).to_csv(OUT + 'h_gap_structure.csv', index=False)
    print('[stage H_methods finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE H_batch: batch-parallel LUCB (B arms per round, in the spirit of Jun et al. 2016) against certified search, on elapsed time with W = B workers
# =====================================================================================
def run_batch_lucb(P, rng, eps, delta=0.05, m=100, cap=40000, B=16):
    """Each round samples the empirical best and the B-1 challengers with the highest upper bounds, m simulations each, in parallel (one batch time when B <= W).
    Same empirical-Bernstein radius and per-(candidate, batch) union bound as run_index; stops under the certified-search rule."""
    K = P.K; s, ss = P.draw(np.arange(K), m, rng); n = np.full(K, float(m)); total = m * K; viol = False; rounds = 1; parts = [(K, m)]
    while True:
        j = n / m; mu = s / n; var = np.maximum(ss / n - mu ** 2, 0) * n / (n - 1); L = np.log(2 * K * j * (j + 1) / delta); r = _eb(var, n, L); lcb, ucb = mu - r, mu + r
        viol |= bool(np.any(np.abs(mu - P.truth) > r)); h = int(np.argmax(mu)); uo = ucb.copy(); uo[h] = -9; l = int(np.argmax(uo))
        if lcb[h] >= ucb[l] - eps: return h, total, True, viol, rounds, parts
        k = min(B - 1, K - 1); ch = np.argpartition(-uo, k - 1)[:k] if k > 0 else np.array([], int); todo = np.array([x for x in [h, *ch.tolist()] if n[x] < cap], int)
        if len(todo) == 0: return h, total, False, viol, rounds, parts
        x, y = P.draw(todo, m, rng); s[todo] += x; ss[todo] += y; n[todo] += m; total += m * len(todo); rounds += 1; parts.append((len(todo), m))

if _run('H_batch'):
    _t_stage = time.time(); _pools = {}
    for _nm_ in ('f1', 'f2', 'calzone_cellfate', 'grieco_mapk', 'remy_tumorigenesis'):
        _fn = OUT + f'pool_{_nm_}_counts.npy'
        if os.path.exists(_fn): _pools[_nm_] = PoolArms(np.load(_fn))
    _top15 = np.argsort(-_pools['f2'].truth)[:15]
    _F = {'AML druggable sets (K=92)': (_pools['f1'], 200, 100000), 'AML 3-gene sets (K=833)': (_pools['f2'], 100, 40000), 'AML top-15 gene sets': (_pools['f2'].sub(_top15), 100, 40000),
          'Calzone cell fate (K=2,951)': (_pools['calzone_cellfate'], 100, 40000), 'Grieco MAPK (K=1,275)': (_pools['grieco_mapk'], 100, 40000), 'Remy tumorigenesis (K=5,488)': (_pools['remy_tumorigenesis'], 100, 40000)}
    _plan = [('AML druggable sets (K=92)', 0.01, 100), ('AML druggable sets (K=92)', 0.02, 100), ('AML druggable sets (K=92)', 0.05, 100), ('AML 3-gene sets (K=833)', 0.02, 50), ('AML 3-gene sets (K=833)', 0.05, 50),
             ('AML top-15 gene sets', 0.02, 100), ('Calzone cell fate (K=2,951)', 0.02, 30), ('Calzone cell fate (K=2,951)', 0.05, 30), ('Grieco MAPK (K=1,275)', 0.02, 30), ('Grieco MAPK (K=1,275)', 0.05, 30),
             ('Remy tumorigenesis (K=5,488)', 0.02, 20), ('Remy tumorigenesis (K=5,488)', 0.05, 20)]
    _rows = []
    for fam, eps, R in _plan:
        P, m, cap = _F[fam]
        for B in (4, 16, 128):
            for rep in range(R):
                a, tot, cert, viol, rnd, parts = run_batch_lucb(P, np.random.default_rng(940000 + 1000 * B + rep + int(eps * 1e4) + 17 * len(fam)), eps, m=m, cap=cap, B=B)
                _rows.append(dict(family=fam, eps=eps, B=B, rep=rep, total=tot, certified=cert, eps_optimal=_ok(P, a, eps), violation=viol, rounds=rnd, wall_own=_wall(parts, B), wall1=_wall(parts, 1), wall16=_wall(parts, 16), wall128=_wall(parts, 128)))
        print(fam, eps, pd.DataFrame([x for x in _rows if x['family'] == fam and x['eps'] == eps]).groupby('B')[['total', 'rounds', 'wall16', 'wall128']].mean().round(0).to_dict('index'), flush=True)
    pd.DataFrame(_rows).to_csv(OUT + 'h_batch_lucb.csv', index=False); print('[stage H_batch finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE I_theory: numerical check of the explicit-constant sample-complexity bound (Supplementary Note 1, Theorem 3) and of the radius inequality it uses
# =====================================================================================
def thm3_bound(P, eps, delta=0.05, m=100):
    """Explicit bound of Theorem 3 on the number of simulations of successive elimination, from the true means and variances of the replayed family."""
    mu = P.truth; var = P.p @ P.v2 - mu ** 2; K = P.K; gap = P.best - mu; star = int(np.argmax(mu)); s2 = np.maximum(var, var[star]); dt = np.maximum(gap, eps)
    T = 2.0
    for _ in range(200):
        L = np.log(2 * K * T * (T + 1) / delta); tau = np.ceil((2 + np.maximum(128 * s2 * L / dt ** 2, (104 / 3) * L / dt)) / m); Tn = float(tau.max())
        if abs(Tn - T) < 0.5: break
        T = Tn
    n = np.where(gap > eps, m * tau, m * Tn)       # candidates within eps of the best are sampled until the search stops
    return float(n.sum()), float(Tn), float(L)
if _run('I_theory'):
    _t_stage = time.time(); _rows = []; _hm = pd.read_csv(OUT + 'h_method_comparison.csv'); _hm = _hm[_hm.method.str.startswith('Certified')]
    _P = {'AML druggable sets (K=92)': (PoolArms(np.load(OUT + 'pool_f1_counts.npy')), 200), 'AML 3-gene sets (K=833)': (PoolArms(np.load(OUT + 'pool_f2_counts.npy')), 100),
          'Calzone cell fate (K=2,951)': (PoolArms(np.load(OUT + 'pool_calzone_cellfate_counts.npy')), 100), 'Grieco MAPK (K=1,275)': (PoolArms(np.load(OUT + 'pool_grieco_mapk_counts.npy')), 100),
          'Remy tumorigenesis (K=5,488)': (PoolArms(np.load(OUT + 'pool_remy_tumorigenesis_counts.npy')), 100)}
    for (fam, eps), g in _hm.groupby(['family', 'eps']):
        if fam not in _P: continue
        P, m = _P[fam]; b, T, L = thm3_bound(P, eps, m=m); _rows.append(dict(family=fam, eps=eps, runs=len(g), observed_mean=g.total.mean(), observed_max=g.total.max(), bound=b, bound_over_observed=b / g.total.mean(), bound_holds_all_runs=bool((g.total <= b).all()), rounds_bound=T))
    pd.DataFrame(_rows).to_csv(OUT + 'i_theory_bound_check.csv', index=False); print(pd.DataFrame(_rows).round(2).to_string(), flush=True)
    # radius inequality: on the variance event, r_t <= sqrt(2 sigma^2 L/(n-1)) + (13/3) L/(n-1); check the frequency of violation over simulated streams (should be below the nominal level)
    _rng = np.random.default_rng(31337); _P1 = _P['AML 3-gene sets (K=833)'][0]; _viol = 0; _tot = 0; _K = _P1.K; _arms = _rng.choice(_K, 100, replace=False); _delta = 0.05
    for a in _arms:
        var_a = float(_P1.p[a] @ _P1.v2 - _P1.truth[a] ** 2)
        for _rep in range(20):
            x = _rng.choice(_P1.v, size=4000, p=_P1.p[a])
            for t in range(1, 41):
                n = 100 * t; xs = x[:n]; mu = xs.mean(); V = xs.var(ddof=1); L = np.log(2 * _K * t * (t + 1) / _delta); r = np.sqrt(2 * V * L / (n - 1)) + 7 * L / (3 * (n - 1)); R = np.sqrt(2 * var_a * L / (n - 1)) + (13 / 3) * L / (n - 1)
                _tot += 1; _viol += bool(r > R)
    pd.DataFrame([dict(checks=_tot, radius_exceeds_bound=_viol, frequency=_viol / _tot, nominal_union_level=_delta)]).to_csv(OUT + 'i_theory_radius_check.csv', index=False); print('radius inequality violated in', _viol, 'of', _tot, flush=True)
    # pooled exact confidence bound for epsilon-optimality of certified search over the replayed runs at the pre-registered eps = 0.02
    from scipy.stats import beta as _beta
    _g = _hm[_hm.eps == 0.02]; _n = len(_g); _k = int(_g.eps_optimal.sum()); _lo = _beta.ppf(0.05, _k, _n - _k + 1) if _k > 0 else 0.0
    pd.DataFrame([dict(runs=_n, eps_optimal=_k, certified=int(_g.certified.sum()), exact_one_sided_95_lower=_lo, interval_violations=int(_g.violation.sum()))]).to_csv(OUT + 'i_replay_pooled_guarantee.csv', index=False)
    print('replay pooled (eps=0.02): %d/%d eps-optimal, exact 95%% lower bound %.4f' % (_k, _n, _lo), flush=True); print('[stage I_theory finished in %.0f s]' % (time.time() - _t_stage), flush=True)

# =====================================================================================
# STAGE I_drugcomb: retrospective check of the model's predicted drug-pair synergy against a public combination screen (DrugComb summary export)
# Analysis fixed BEFORE looking at any combination data. Input: DRUGCOMB_CSV=/path/summary.csv (columns: drug_row, drug_col, cell_line_name, synergy_zip, synergy_bliss, ...).
# Model prediction: excess over the Bliss expectation of each two-drug set in results/constrained_druggable_ranking.csv. Observed: median synergy_bliss over all AML blocks for the pair.
# Primary outcome: Spearman correlation (one-sided permutation p, 100,000 permutations) over all matched pairs; secondary: sign agreement, and the three pairs inside the predicted triplet.
# =====================================================================================
DC_UNITS = {'Venetoclax': ['venetoclax', 'abt-199', 'abt199'], 'Ibrutinib': ['ibrutinib'], 'Entospletinib': ['entospletinib', 'gs-9973'], 'Selumetinib': ['selumetinib', 'azd6244', 'azd-6244'],
            'Midostaurin': ['midostaurin', 'pkc412', 'pkc-412'], 'FLT3-inhibitor (gilteritinib-class)': ['gilteritinib', 'quizartinib', 'crenolanib', 'lestaurtinib'],
            'AKT-inhibitor class': ['mk-2206', 'mk2206', 'ipatasertib', 'capivasertib', 'azd5363', 'gdc-0068'], 'ERK-inhibitor class': ['ulixertinib', 'sch772984', 'vx-11e', 'ravoxertinib', 'gdc-0994', 'ly3214996']}
DC_AML_LINES = ['molm-13', 'molm-14', 'molm13', 'molm14', 'mv4-11', 'mv-4-11', 'oci-aml2', 'oci-aml3', 'thp-1', 'thp1', 'hl-60', 'hl60', 'kg-1', 'kg1', 'u937', 'u-937', 'nomo-1', 'kasumi-1', 'hel', 'nb4', 'skm-1', 'molm-16', 'eol-1', 'ociaml2', 'ociaml3', 'mono-mac-6', 'f-36p', 'ml-2', 'ml2']
if _run('I_drugcomb'):
    _src = os.environ.get('DRUGCOMB_CSV', '')
    if not _src or not os.path.exists(_src):
        print('I_drugcomb: set DRUGCOMB_CSV to a DrugComb summary export (https://drugcomb.org/download/) and re-run. Nothing was computed.'); sys.exit(0)
    from scipy.stats import spearmanr as _sp, mannwhitneyu as _mw
    _d = pd.read_csv(_src, low_memory=False); _d.columns = [c.lower() for c in _d.columns]
    _unit_of = {n: u for u, ns in DC_UNITS.items() for n in ns}; _d['ua'] = _d.drug_row.astype(str).str.lower().map(_unit_of); _d['ub'] = _d.drug_col.astype(str).str.lower().map(_unit_of)
    _d['line'] = _d.cell_line_name.astype(str).str.lower().str.replace(' ', '')
    _d = _d[_d.ua.notna() & _d.ub.notna() & (_d.ua != _d.ub) & _d.line.isin([x.replace(' ', '') for x in DC_AML_LINES])].copy(); _d['pair'] = [' + '.join(sorted([a, b])) for a, b in zip(_d.ua, _d.ub)]
    _obs = _d.groupby('pair').agg(blocks=('line', 'size'), lines=('line', 'nunique'), bliss=('synergy_bliss', 'median'), zip_=('synergy_zip', 'median')).reset_index()
    _rk = pd.read_csv(OUT + 'constrained_druggable_ranking.csv'); _rk = _rk[_rk.n_drugs == 2].copy(); _rk['pair'] = [' + '.join(sorted(x.split(' + '))) for x in _rk.combination]
    _m = _obs.merge(_rk[['pair', 'score', 'excess_over_bliss']], on='pair'); _m['model_excess_bliss_pp'] = 100 * _m.excess_over_bliss
    _m.to_csv(OUT + 'i_drugcomb_matched_pairs.csv', index=False); print(_m.round(3).to_string(), flush=True)
    _res = dict(matched_pairs=len(_m), total_model_pairs=len(_rk), observed_pairs_available=len(_obs))
    if len(_m) >= 4:
        _rho, _ = _sp(_m.model_excess_bliss_pp, _m.bliss); _rng = np.random.default_rng(1); _perm = np.array([_sp(_rng.permutation(_m.model_excess_bliss_pp.values), _m.bliss)[0] for _ in range(100000)])
        _res.update(spearman_rho=float(_rho), permutation_p_one_sided=float((_perm >= _rho).mean()), sign_agreement=float(((_m.model_excess_bliss_pp > 0) == (_m.bliss > 0)).mean()))
    _tri = _m[_m.pair.isin([' + '.join(sorted(x)) for x in (('Ibrutinib', 'Midostaurin'), ('Ibrutinib', 'ERK-inhibitor class'), ('Midostaurin', 'ERK-inhibitor class'))])]; _res['triplet_pairs_observed'] = {r.pair: float(r.bliss) for r in _tri.itertuples()}
    json.dump(_res, open(OUT + 'i_drugcomb_summary.json', 'w'), indent=1); print(json.dumps(_res, indent=1), flush=True)

# =====================================================================================
# STAGE paper: figures, numbers.tex and LaTeX tables used by the manuscript
# =====================================================================================
if _run('paper'):
    import matplotlib.pyplot as plt
    os.makedirs(PAPER_DIR+'/figures',exist_ok=True)
    from scipy.stats import spearmanr
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    CP,CS,CH,CW,CG,CA='#3B6FA0','#7F8C8D','#E8873A','#C0392B','#1B7F5C','#8E5BB0'
    V=OUT; F=PAPER_DIR+'/figures/'
    # ---- Fig 3: safeguards (baseline, additivity, size-matched null)
    H=pd.read_csv(V+'pbn_hoeffding_ranking.csv'); S=pd.read_csv(V+'pbn_synergy_additivity.csv'); NN=pd.read_csv(V+'pbn_all_clamp_sets.csv')
    fig,axs=plt.subplots(1,2,figsize=(12.5,4.4),gridspec_kw={'width_ratios':[1.25,1]}); ax=axs[0]; H=H.sort_values('partial',ascending=False).reset_index(drop=True)
    cols=[CH if i==0 else (CA if c=='untreated' else CP) for i,c in enumerate(H.candidate)]; ax.bar(range(len(H)),H.partial,color=cols,zorder=3)
    ax.set_xticks(range(len(H))); ax.set_xticklabels([c.replace('pair: ','').replace('single: ','') for c in H.candidate],rotation=40,ha='right',fontsize=7.5)
    u=H[H.candidate=='untreated'].partial.iloc[0]; ax.axhline(u,color=CA,ls='--',lw=1.2,label=f'untreated ({u:.1f}%)')
    for _,r in S.iterrows(): k=H.index[H.candidate==f"pair: {r.pair}"][0]; ax.plot(k,r.additive_expected,'D',color='black',ms=5.5,zorder=5)
    BLs=pd.read_csv(V+'pbn_synergy_bliss.csv')
    for _,r in BLs.iterrows():
        k=H.index[H.candidate==f"pair: {r.pair}"][0]; ax.plot(k,r.bliss_expected,'x',color=CW,ms=7,mew=2,zorder=6)
    ax.plot([],[],'D',color='black',label='additive expectation'); ax.plot([],[],'x',color=CW,mew=2,label='Bliss expectation'); ax.set_ylabel('Model score (%)'); ax.legend(fontsize=8); ax.set_title('a  Five calibrated drugs and pairs (n = 26,492 each)',loc='left',fontsize=9.5,fontweight='bold')
    ax=axs[1]; d3=NN[NN.k==3]; ax.hist(d3.partial,bins=40,color=CP,alpha=0.85,zorder=3); v=H[H.candidate==HEADP].partial.iloc[0]
    ax.axvline(v,color=CH,lw=2.2,label=f'Midostaurin+Venetoclax (percentile {100*(d3.partial<v).mean():.1f})'); ax.axvline(d3.partial.max(),color=CW,lw=1.5,ls='--',label=f'best 3-gene set ({d3.loc[d3.partial.idxmax(),"genes"]})')
    ax.set_xlabel(f'Model score (%) over all {len(d3):,} three-gene sets'); ax.set_ylabel('number of sets'); ax.legend(fontsize=7.5,loc='upper left'); ax.set_title('b  Size-matched null',loc='left',fontsize=9.5,fontweight='bold')
    plt.tight_layout(); fig.savefig(F+'fig3_safeguards.png',dpi=300,bbox_inches='tight'); plt.close()
    # ---- Fig 4: genotype strata + robustness
    G=pd.read_csv(V+'pbn_genotype_strata.csv'); A=pd.read_csv(V+'pbn_alternative_calibrations.csv'); P=pd.read_csv(V+'pbn_rule_prob_perturbation.csv')
    fig,axs=plt.subplots(1,3,figsize=(14.5,4.3),gridspec_kw={'width_ratios':[1.5,1,1]}); ax=axs[0]
    lab=[f"FLT3{'+' if r.FLT3 else '-'} NPM1{'+' if r.NPM1 else '-'} DNMT3A{'+' if r.DNMT3A else '-'}" for r in G.itertuples()]; x=np.arange(len(G))
    ax.bar(x-0.2,G.untreated,0.4,color=CA,label='untreated',zorder=3); ax.bar(x+0.2,G.Head,0.4,color=CH,label=HEAD_LABEL,zorder=3)
    ax.set_xticks(x); ax.set_xticklabels(lab,rotation=45,ha='right',fontsize=7.5); ax.set_ylabel('Model score (%)'); ax.legend(fontsize=8,loc='lower right')
    for i,r in enumerate(G.itertuples()): ax.text(i,max(r.untreated,r.Head)+1,f"rank {r.rank_Head}",ha='center',fontsize=7.5)
    ax.set_ylim(0,80); ax.set_title('a  Mutation status held fixed',loc='left',fontsize=9.5,fontweight='bold')
    ax=axs[1]; A2=A.sort_values('kendall_tau_vs_reference'); ax.barh(range(len(A2)),A2.kendall_tau_vs_reference,color=[CH if r==1 else CW for r in A2.Head_rank],zorder=3)
    ax.set_yticks(range(len(A2))); ax.set_yticklabels([m.replace('BeatAML_AUC_5drugs_','').replace('BeatAML_-AUC_5drugs_','')[:26] for m in A2.model],fontsize=6.3); ax.set_xlabel('Kendall tau vs reference ranking'); ax.set_title('b  15 related calibrations\n(orange: pair ranked first)',loc='left',fontsize=9.5,fontweight='bold')
    ax=axs[2]; ax.plot(P.kappa,P.top1_freq*100,'o-',color=CG); ax.set_xscale('log'); ax.invert_xaxis(); ax.set_ylim(0,105); ax.set_xlabel('Dirichlet concentration kappa (noise rises to the right)'); ax.set_ylabel('pair ranked first (%)'); ax.set_title('c  Rule-probability noise',loc='left',fontsize=9.5,fontweight='bold')
    plt.tight_layout(); fig.savefig(F+'fig4_genotype_robustness.png',dpi=300,bbox_inches='tight'); plt.close()
    # ---- Fig S1: TBS validation
    FPl=pd.read_csv(V+'pilot_all_candidates_features.csv'); FPa=pd.read_csv(V+'palma_all_candidates_features.csv'); FPb=pd.read_csv(V+'pbn_all_candidates_features.csv')
    fig,axs=plt.subplots(1,3,figsize=(12.5,3.7))
    for ax,(F_,yc,ttl) in zip(axs,[(FPl,'exact_conv','Pilot (13 genes, 66 sets)'),(FPa,'exact_func','Palma (18 genes, 136 sets)'),(FPb,'mc_partial','AML PBN (24 genes, 253 sets)')]):
        ax.scatter(F_.TBS,F_[yc],s=15,color=CP,alpha=0.65,edgecolor='white',linewidth=0.4); r_=spearmanr(F_.TBS,F_[yc])[0]; ax.set_title(f"{ttl}\nSpearman rho = {r_:+.2f}",fontsize=9); ax.set_xlabel('Topological Bottleneck Score')
        ax.set_ylabel({'exact_conv':'exact convergence (%)','exact_func':'exact functional score (%)','mc_partial':'Monte-Carlo score (%)'}[yc])
    plt.tight_layout(); fig.savefig(F+'figS1_tbs_vs_truth.png',dpi=300,bbox_inches='tight'); plt.close()
    # ---- Fig S2: conformal comparison + conditional coverage
    Vc=pd.read_csv(V+'conformal_venetoclax_raw.csv'); Vm=Vc[~Vc.design.str.contains('per profile')]
    designs=['random split','leave-one-profile-out','cohort shift (Waves1+2 -> Waves3+4)','cohort shift (Waves3+4 -> Waves1+2)']
    methods=['Bootstrap CI of mean (misread)','OLS Gaussian PI','Residual-bootstrap PI','Split conformal','CQR (conformalised quantile)','Mondrian (profile-conditional) conformal','Weighted conformal (covariate shift)']
    cm=[CW,CS,'#B0B7BA',CP,CA,CG,CH]; fig,axs=plt.subplots(1,2,figsize=(13.5,4.6))
    for ax,col,yl in zip(axs,['coverage','width'],['Empirical coverage (%)','Mean interval width (AUC units)']):
        w=0.115
        for j,m in enumerate(methods):
            vals=[Vm[(Vm.design==d)&(Vm.method==m)][col].mean()*(100 if col=='coverage' else 1) for d in designs]; ax.bar(np.arange(4)+(j-3)*w,vals,w,color=cm[j],label=m,zorder=3,edgecolor='white',linewidth=0.4)
        ax.set_xticks(range(4)); ax.set_xticklabels([d.replace(' (','\n(') for d in designs],fontsize=7.5); ax.set_ylabel(yl)
    axs[0].axhline(90,color='#333',ls='--',lw=1.2); axs[0].set_ylim(0,105); axs[0].legend(fontsize=6.8,ncol=2,loc='lower center',bbox_to_anchor=(0.5,-0.52))
    plt.tight_layout(); fig.savefig(F+'figS2_conformal_real_patients.png',dpi=300,bbox_inches='tight'); plt.close()
    # ---- policy figure
    PO=pd.read_csv(V+'e_policy_comparison.csv').iloc[1:]; fig,ax=plt.subplots(figsize=(10.5,4.3)); x=np.arange(len(PO))
    ax.bar(x-0.2,PO.legacy_gain,0.4,color=CW,label='original 7-marker reward',zorder=3); ax.bar(x+0.2,PO.strict_gain,0.4,color=CP,label='strict 5-marker reward',zorder=3)
    ax.set_xticks(x); ax.set_xticklabels([c.replace(' (best 3-gene set under legacy policy)','') for c in PO.candidate],rotation=40,ha='right',fontsize=7.5); ax.set_ylabel('Gain over untreated (percentage points)'); ax.axhline(0,color='#333',lw=0.8); ax.legend(fontsize=8)
    plt.tight_layout(); fig.savefig(F+'fig_policy.png',dpi=300,bbox_inches='tight'); plt.close()
    # ---- robustness figure
    PC=pd.read_csv(V+'e_per_calibration_search.csv'); SS=pd.read_csv(V+'e_structural_sensitivity.csv'); fig,axs=plt.subplots(1,2,figsize=(12.5,4.3),gridspec_kw={'width_ratios':[1,1.25]})
    ax=axs[0]; rr=np.random.default_rng(1)
    for i,(col,lab,c) in enumerate((('excess_linear','additive',CP),('excess_bliss','Bliss',CH))):
        v=PC[col].values; ax.scatter(np.full(len(v),i)+rr.uniform(-0.12,0.12,len(v)),v,s=24,color=c,zorder=3); ax.hlines(v.mean(),i-0.3,i+0.3,color='black',lw=2)
    ax.axhline(0,color='#333',lw=0.8); ax.set_xticks([0,1]); ax.set_xticklabels(['excess over\nadditive expectation','excess over\nBliss expectation']); ax.set_ylabel('triplet excess'); ax.set_title(f'a  {len(PC)} distinct calibrations',loc='left',fontsize=9.5,fontweight='bold')
    ax=axs[1]; sc=['reference network','MAPK1 input to STAT5A removed','STAT5A OR-rule and AND-rule probabilities swapped','random rewiring of 1 regulator(s)','random rewiring of 3 regulator(s)']; lab=['reference','MAPK1 to STAT5A\nremoved','STAT5A rule\nprobs swapped','1 rewiring','3 rewirings']
    for i,sn in enumerate(sc):
        v=SS[SS.scenario==sn].excess_linear.values; ax.scatter(np.full(len(v),i)+rr.uniform(-0.15,0.15,len(v)),v,s=14,color=CG,alpha=0.6,zorder=3); ax.hlines(v.mean(),i-0.3,i+0.3,color='black',lw=2)
    ax.axhline(0,color='#333',lw=0.8); ax.set_xticks(range(5)); ax.set_xticklabels(lab,fontsize=8); ax.set_ylabel('triplet excess over additive expectation'); ax.set_title('b  Structural perturbations of the network',loc='left',fontsize=9.5,fontweight='bold')
    plt.tight_layout(); fig.savefig(F+'fig_robustness.png',dpi=300,bbox_inches='tight'); plt.close()
    if os.path.exists(OUT+'fig_validation_heldout.png'): shutil.copy(OUT+'fig_validation_heldout.png', F+'fig_validation_heldout.png')
    if os.path.exists(OUT+'fig_decoy_knockout.png'): shutil.copy(OUT+'fig_decoy_knockout.png', F+'fig_decoy_knockout.png')
    print('figures done')


    V=OUT; C=OUT
    m={}
    def f(x,d=1): return f"{x:.{d}f}"
    # ---- benchmark (Part C)
    files=[x for x in glob.glob(C+'bench_*.csv') if not x.endswith(('reference.csv', 'baselines.csv', 'summary.csv', 'margin.csv'))]
    D=pd.concat([pd.read_csv(x) for x in files]); D['m']=D.method.str.replace(r' \(.*\)','',regex=True); c=D[D.m=='Certified']
    tag={'aml_pbn_kgbn':'AML','calzone_cellfate':'Cal','grieco_mapk':'Gri','remy_tumorigenesis':'Rem'}
    for n,t in tag.items():
        x=c[c.network==n]; m[f'red{t}lo']=f(x.reduction.min()); m[f'red{t}hi']=f(x.reduction.max()); m[f'red{t}mean']=f(x.reduction.mean()); m[f'K{t}']=f"{int(x.K.iloc[0]):,}"; m[f'runs{t}']=str(len(x))
        for meth,k in (('Uniform','Uni'),('Successive halving','Sh'),('Greedy forward','Gr')):
            y=D[(D.network==n)&(D.m==meth)]; m[f'{k}{t}']=f"{int(y.success.sum())}/{len(y)}"
    m['nCert']=str(len(c)); m['nCertOK']=str(int(c.success.sum()))
    for meth,k in (('Uniform','Uni'),('Successive halving','Sh'),('Greedy forward','Gr')):
        y=D[D.m==meth]; m[f'pool{k}']=f"{int(y.success.sum())}/{len(y)}"
    y=D[D.m=='Greedy forward']; m['poolGrMiss']=str(int(len(y)-y.success.sum()))
    U=pd.read_csv(C+'bench_untreated_baselines.csv').set_index('network')
    for n,t in tag.items(): m[f'unt{t}']=f(U.loc[n,'untreated_mean'],3); m[f'best{t}']=f(U.loc[n,'best_set_score'],3)
    m['untZha']=f(U.loc['zhang_tlgl','untreated_mean'],3)
    # ---- constrained
    cs=json.load(open(C+'constrained_summary.json')); T=pd.read_csv(C+'constrained_druggable_ranking.csv')
    m['conTotal']=f"{cs['total']:,}"; m['conBound']=f"{cs['uniform_bound']:,}"; m['conRed']=f(cs['reduction']); m['conK']=str(cs['K']); m['conUnt']=f(cs['untreated'],3)
    t0=T.iloc[0]; m['topBliss']=f(t0.bliss_expected,3); m['topExcBliss']=f(t0.excess_over_bliss,3); m['topScore']=f(t0.score,3); m['topAdd']=f(t0.additive_expected,3); m['topExc']=f(t0.excess_over_additive,3)
    ST=pd.read_csv(C+'constrained_stress_alt_calibrations.csv')
    for combo,t in (('Ibr+Mido+ERKi','Trip'),('Ven+Mido','VM'),('Ven+Mido+ERKi','VME'),('Ven+Ento+ERKi','VEE')):
        x=ST[ST.combo==combo].excess; m[f'ex{t}mean']=f(x.mean(),3); m[f'ex{t}min']=f(x.min(),3); m[f'ex{t}max']=f(x.max(),3); m[f'ex{t}pos']=f"{int((x>0.02).sum())}/{len(x)}"
    m['nCal']=str(ST.model.nunique())
    pv=ST.pivot(index='model',columns='combo',values='observed'); m['tripTop']=f"{int((pv.idxmax(axis=1)=='Ibr+Mido+ERKi').sum())}/{len(pv)}"
    # ---- v2 AML safeguards
    H=pd.read_csv(V+'pbn_hoeffding_ranking.csv').set_index('candidate'); S=pd.read_csv(V+'pbn_synergy_additivity.csv').set_index('pair')
    m['aUnt']=f(H.loc['untreated','partial']); m['aHead']=f(H.loc[HEADP,'partial']); m['aHeadStrict']=f(H.loc[HEADP,'strict'])
    m['aHeadExc']=f(S.loc[HEAD_LABEL,'excess_over_additive_pp'],2); m['aHeadExcSD']=f(S.loc[HEAD_LABEL,'excess_sd_rep_pp'],2); m['aHeadHsa']=f(S.loc[HEAD_LABEL,'excess_over_HSA_pp'],1)
    m['aMEexc']=f(S.loc['Midostaurin + Entospletinib','excess_over_additive_pp'],1)
    N=pd.read_csv(V+'pbn_all_clamp_sets.csv'); d3=N[N.k==3]; v=H.loc[HEADP,'partial']; m['aPct']=f((d3.partial<v).mean()*100); m['aRank']=str(int((d3.partial>v).sum()+1)); m['aNsets']=f"{len(d3):,}"
    b=d3.loc[d3.partial.idxmax()]; m['aBestSet']=b.genes.replace('+','+'); m['aBestScore']=f(b.partial)
    for _n in (300,1000):
        _st=pd.read_csv(V+f'pbn_rank_stability_n{_n}.csv').set_index('candidate'); m['aStabSmall' if _n==300 else 'aStabLarge']=f(_st.loc[HEADP,'top1_freq']*100,0)
    E=pd.read_csv(V+'pbn_effect_sizes.csv'); m['aDmin']=f(E.cohen_d.min(),2); m['aPSmin']=f(E.prob_superiority.min(),2); m['aDmax']=f(E.cohen_d.max(),2)
    A=pd.read_csv(V+'pbn_alternative_calibrations.csv'); m['aAltN']=str(len(A)); m['aAltFirst']=str(int((A.Head_rank==1).sum())); m['aAltSecond']=str(int((A.Head_rank==2).sum())); m['aTau']=f(A.kendall_tau_vs_reference.mean(),2)
    P=pd.read_csv(V+'pbn_rule_prob_perturbation.csv').set_index('kappa'); m['aPertTen']=f(P.loc[10,'top1_freq']*100,0)
    G=pd.read_csv(V+'pbn_genotype_strata.csv'); g1=G[(G.FLT3==1)&(G.NPM1==1)&(G.DNMT3A==1)].iloc[0]; g0=G[(G.FLT3==0)&(G.NPM1==1)&(G.DNMT3A==1)].iloc[0]
    m['aGfu']=f(g1.untreated); m['aGfm']=f(g1.Head); m['aGwu']=f(g0.untreated); m['aGgainM']=f(g1.Head-g1.untreated); m['aGgainW']=f(g0.Head-g0.untreated)
    CL=pd.read_csv(V+'pbn_class_level_flt3.csv').set_index('candidate'); m['aClassMido']=f(CL.loc['Mido(FLT3+KIT)+Ibr','partial'],2); m['aClassFlt']=f(CL.loc['FLT3-only(gilteritinib-like)+Ibr','partial'],2); m['aTriple']=f(CL.loc['FLT3-only+Ven+Ibrutinib','partial'])
    # ---- conformal
    Cs=pd.read_csv(V+'conformal_summary_beataml_venetoclax.csv').set_index(['design','method'])
    def cv(d,mm,c='coverage'): return Cs.loc[(d,mm),c]
    L='leave-one-profile-out'; R_='random split'
    m['cBootL']=f(cv(L,'Bootstrap CI of mean (misread)')*100); m['cBootR']=f(cv(R_,'Bootstrap CI of mean (misread)')*100)
    m['cOLSL']=f(cv(L,'OLS Gaussian PI')*100); m['cConfL']=f(cv(L,'Split conformal')*100); m['cConfLsd']=f(cv(L,'Split conformal','coverage_sd')*100); m['cCQRL']=f(cv(L,'CQR (conformalised quantile)')*100); m['cCQRLsd']=f(cv(L,'CQR (conformalised quantile)','coverage_sd')*100)
    m['cConfR']=f(cv(R_,'Split conformal')*100); m['cOLSR']=f(cv(R_,'OLS Gaussian PI')*100); m['cResL']=f(cv(L,'Residual-bootstrap PI')*100)
    m['cWconf']=f(cv(R_,'Split conformal','width'),0); m['cWols']=f(cv(R_,'OLS Gaussian PI','width'),0); m['cWboot']=f(cv(R_,'Bootstrap CI of mean (misread)','width'),0)
    cc=pd.read_csv(V+'conformal_conditional_coverage_by_profile.csv').set_index('heldout'); m['cCondMinConf']=f(cc['Split conformal'].min()*100); m['cCondMinMond']=f(cc['Mondrian (profile-conditional) conformal'].min()*100)
    m['cCohortAB']=f(cv('cohort shift (Waves1+2 -> Waves3+4)','Split conformal')*100); m['cCohortBA']=f(cv('cohort shift (Waves3+4 -> Waves1+2)','Split conformal')*100)
    cal=pd.read_csv(V+'kgbn_calibration_within_drug.csv').set_index('subset'); m['calPool']=f(cal.iloc[0].pearson_r,3); m['calMido']=f(cal.loc['within Midostaurin (8 genotypes)','pearson_r'],2); m['calVen']=f(cal.loc['within Venetoclax (8 genotypes)','pearson_r'],2)
    # ---- TBS
    Tb=pd.read_csv(V+'tbs_validation_all_networks.csv')
    def tb(net,tgt,feat,col='spearman'): 
        x=Tb[(Tb.network.str.startswith(net))&(Tb.target==tgt)&(Tb.feature==feat)]; return x[col].iloc[0]
    m['tPil']=f(tb('pilot','exact_conv','TBS'),2); m['tPal']=f(tb('palma','exact_conv','TBS'),2); m['tPBN']=f(tb('PBN','mc_partial','TBS'),2)
    m['tPilP']=f(tb('pilot','exact_conv','TBS','partial_given_ctrl'),2); m['tPalP']=f(tb('palma','exact_conv','TBS','partial_given_ctrl'),2); m['tPBNP']=f(tb('PBN','mc_partial','TBS','partial_given_ctrl'),2)
    m['tPilLen']=f(tb('pilot','exact_conv','mean_len'),2); m['tPilStruct']=f(tb('pilot','exact_func','struct'),2); m['tPilTBSf']=f(tb('pilot','exact_func','TBS'),2)
    st=pd.read_csv(V+'pilot_tbs_stability.csv').set_index('n_seeds'); m['tRTforty']=f(st.loc[40,'test_retest_rho'],2); m['tRTlarge']=f(st.loc[160,'test_retest_rho'],2); m['tArgForty']=f(st.loc[40,'modal_argmin_freq']*100,0)

    # ---------------- Part D ----------------
    Dd_=OUT
    A_=pd.read_csv(Dd_+'d_missrate_runs.csv'); m['dRuns']=str(len(A_)); m['dCert']=str(int(A_.certified.sum())); m['dOpt']=str(int(A_.eps_optimal.sum())); m['dViol']=str(int(A_.ci_violation.sum()))
    m['dCostMean']=f"{A_.total.mean():,.0f}"; m['dCostSD']=f"{A_.total.std():,.0f}"; m['dUpper']=f(100*(1-0.05**(1/len(A_))),1)
    S_=pd.read_csv(Dd_+'d_sensitivity.csv'); g_=S_.groupby(['eps','delta']).reduction.mean()
    m['sRedFine']=f(g_[(0.005,0.05)]); m['sRedMid']=f(g_[(0.01,0.05)]); m['sRedLoose']=f(g_[(0.02,0.05)]); m['sRedCoarse']=f(g_[(0.05,0.05)]); m['sRedDlow']=f(g_[(0.01,0.01)]); m['sRedDhigh']=f(g_[(0.01,0.2)])
    m['sCostFine']=f"{S_[(S_.eps==0.005)&(S_.delta==0.05)].total.mean():,.0f}"; m['sCostCoarse']=f"{S_[(S_.eps==0.05)].total.mean():,.0f}"
    B_=pd.read_csv(Dd_+'d_bound_ablation.csv'); eb=B_[B_.bound=='EB']; ho=B_[B_.bound=='Hoeffding']
    m['abEB']=f(eb.reduction.mean()); m['abHo']=f(ho.reduction.mean()); m['abRatio']=f(ho.total.mean()/eb.total.mean()); m['abHoUnc']=str(int((~ho.certified).sum()))
    SC_=pd.read_csv(Dd_+'d_scaling.csv'); m['scMin']=f(SC_.reduction.min()); m['scMax']=f(SC_.reduction.max()); m['scCert']=f"{int(SC_.certified.sum())}/{len(SC_)}"
    gk=SC_.groupby('K').agg(r=('reduction','mean'),t=('near_ties','mean'))
    m['scSmall']=f(gk.r.loc[50]); m['scLarge']=f(gk.r.loc[800]); m['scTiesSmall']=f(gk.t.loc[50]); m['scTiesLarge']=f(gk.t.loc[800]); m['scDip']=f(gk.r.loc[100])
    NZ_=pd.read_csv(Dd_+'d_noise.csv'); gn=NZ_.groupby('noise').reduction.mean(); m['nzLow']=f(gn.loc[0.005]); m['nzMid']=f(gn.loc[0.02]); m['nzHigh']=f(gn.loc[0.05]); m['nzOpt']=f"{int(NZ_.eps_optimal.sum())}/{len(NZ_)}"; m['nzCert']=f"{int(NZ_.certified.sum())}/{len(NZ_)}"
    m['nzBestHigh']=f(NZ_[NZ_.noise==0.05].best.mean(),3); m['nzUntHigh']=f(NZ_[NZ_.noise==0.05].untreated.mean(),3)
    GT_=pd.read_csv(Dd_+'d_genotype.csv')
    for k,(r_) in zip('ABCD',GT_.itertuples()):
        m[f'gt{k}Exc']=f(r_.triplet_excess,3); m[f'gt{k}Rank']=str(int(r_.triplet_rank)); m[f'gt{k}Score']=f(r_.best_score,3); m[f'gt{k}Unt']=f(r_.untreated,3); m[f'gt{k}Tot']=f"{int(r_.total):,}"
        m[f'gt{k}Best']=r_.certified_best.replace('ERK-inhibitor class','ERKi'); m[f'gt{k}BestExc']=f(r_.best_excess,3); m[f'gt{k}ExcBliss']=f(r_.triplet_excess_bliss,3); m[f'gt{k}BestExcBliss']=f(r_.best_excess_bliss,3)
    EX_=pd.read_csv(Dd_+'d_marker_excess.csv',index_col=0)
    for k,row in (('Stat','STAT5A off'),('Tpf','TP53 on'),('Cdk','CDKN2A on'),('Myc','MYC off'),('Ccn','CCND1 off')):
        if row not in EX_.index: continue
        m[f'mk{k}Exc']=f(EX_.loc[row,'excess'],3); m[f'mk{k}Obs']=f(EX_.loc[row,'observed_triplet'],3); m[f'mk{k}Ind']=f(EX_.loc[row,'bliss_expected'],3); m[f'mk{k}Unt']=f(EX_.loc[row,'untreated'],3)
    MP_=pd.read_csv(Dd_+'d_marker_probs.csv',index_col=0); m['mkStatPair']=f(MP_.loc['Ibrutinib + Midostaurin','STAT5A off'],3)


    # ---------------- Revision (stage E_robust and Bliss) ----------------
    from scipy.stats import beta as _beta
    Bl=pd.read_csv(V+'pbn_synergy_bliss.csv').set_index('pair'); m['aHeadBlExc']=f(Bl.loc[HEAD_LABEL,'excess_bliss_pp'],2); m['aHeadBlLin']=f(Bl.loc[HEAD_LABEL,'excess_linear_pp'],2)
    m['aMIblExc']=f(Bl.loc['Midostaurin + Ibrutinib','excess_bliss_pp'],2); m['aMEblExc']=f(Bl.loc['Midostaurin + Entospletinib','excess_bliss_pp'],2)
    PO=pd.read_csv(V+'e_policy_comparison.csv').set_index('candidate')
    m['pVenLeg']=f(PO.loc['Venetoclax (BCL2)','legacy_gain'],1); m['pVenStr']=f(PO.loc['Venetoclax (BCL2)','strict_gain'],1)
    m['pMVLeg']=f(PO.loc['Midostaurin + Venetoclax','legacy_gain'],1); m['pMVStr']=f(PO.loc['Midostaurin + Venetoclax','strict_gain'],1); m['pMidoStr']=f(PO.loc['Midostaurin (FLT3+KIT)','strict_gain'],1)
    m['pTripLegScore']=f(PO.loc['BCL2 + MYC + SYK (best 3-gene set under legacy policy)','legacy_7marker'],1)
    import re as _re
    _raw=parse_pbn(REF)[1]; m['pBclRules']=str(sum(1 for g,rl in _raw.items() if g!='BCL2' and any(_re.search(r'\bBCL2\b',e) for e,_ in rl)))
    DS=pd.read_csv(V+'e_calibration_dependence_summary.csv').iloc[0]; m['eCalN']=str(int(DS.n_calibrations)); m['eRuleRhoMean']=f(DS.rule_prob_spearman_mean,2); m['eRuleRhoMin']=f(DS.rule_prob_spearman_min,2); m['eScoreRhoMean']=f(DS.candidate_score_spearman_mean,2); m['eScoreRhoMin']=f(DS.candidate_score_spearman_min,2)
    PCs=pd.read_csv(V+'e_per_calibration_search.csv'); n_=len(PCs)
    m['ePcBest']=f"{int(PCs.triplet_is_certified_best.sum())}/{n_}"; m['ePcTopThree']=f"{int((PCs.triplet_rank<=3).sum())}/{n_}"; m['ePcLinPos']=f"{int((PCs.excess_linear>0).sum())}/{n_}"; m['ePcBlPos']=f"{int((PCs.excess_bliss>0).sum())}/{n_}"
    m['ePcLinMean']=f(PCs.excess_linear.mean(),3); m['ePcLinMin']=f(PCs.excess_linear.min(),3); m['ePcLinMax']=f(PCs.excess_linear.max(),3); m['ePcBlMean']=f(PCs.excess_bliss.mean(),3); m['ePcBlMin']=f(PCs.excess_bliss.min(),3); m['ePcBlMax']=f(PCs.excess_bliss.max(),3)
    m['ePcCert']=f"{int(PCs.certified.sum())}/{n_}"; m['ePcRankMax']=str(int(PCs.triplet_rank.max()))
    SSs=pd.read_csv(V+'e_structural_sensitivity.csv'); g_=SSs.groupby('scenario')
    def sc_(name,col,fn='mean'): return getattr(g_[col],fn)().loc[name]
    m['eAblLin']=f(sc_('MAPK1 input to STAT5A removed','excess_linear'),3); m['eAblBl']=f(sc_('MAPK1 input to STAT5A removed','excess_bliss'),3); m['eAblTop']=str(bool(sc_('MAPK1 input to STAT5A removed','triplet_top')))
    m['eSwapLin']=f(sc_('STAT5A OR-rule and AND-rule probabilities swapped','excess_linear'),3); m['eSwapBl']=f(sc_('STAT5A OR-rule and AND-rule probabilities swapped','excess_bliss'),3); m['eSwapTop']=str(bool(sc_('STAT5A OR-rule and AND-rule probabilities swapped','triplet_top')))
    m['eRefLin']=f(sc_('reference network','excess_linear'),3)
    for tag,sn in (('One','random rewiring of 1 regulator(s)'),('Three','random rewiring of 3 regulator(s)')):
        x=SSs[SSs.scenario==sn]; m[f'eRw{tag}N']=str(len(x)); m[f'eRw{tag}Pos']=f(100*(x.excess_linear>0.02).mean(),0); m[f'eRw{tag}BlPos']=f(100*(x.excess_bliss>0.02).mean(),0); m[f'eRw{tag}Top']=f(100*x.triplet_top.mean(),0); m[f'eRw{tag}Mean']=f(x.excess_linear.mean(),3); m[f'eRw{tag}Min']=f(x.excess_linear.min(),3)
    SDc=pd.read_csv(V+'e_strict_delta_cost.csv'); mm_=SDc.groupby('constant').total.mean(); m['eStrictRatio']=f(mm_[4]/mm_[2],3); m['eStrictPct']=f(100*(mm_[4]/mm_[2]-1),1)
    HA_=pd.read_csv(V+'e_hard_audit.csv'); m['eHardRuns']=str(len(HA_)); m['eHardCert']=str(int(HA_.certified.sum())); m['eHardOpt']=str(int(HA_.eps_optimal.sum())); m['eHardViol']=str(int(HA_.ci_violation.sum())); m['eHardTies']=str(int(HA_.near_ties.iloc[0])); m['eHardCost']=f"{HA_.total.mean():,.0f}"
    m['eHardUpper']=f(100*(1-0.05**(1/len(HA_))),1)
    LU_=pd.read_csv(V+'e_lucb_comparison.csv'); gl=LU_.groupby('method'); m['eLucbCs']=f"{gl.total.mean().loc['Certified search']:,.0f}"; m['eLucbLu']=f"{gl.total.mean().loc['LUCB (EB radius)']:,.0f}"; m['eLucbRuns']=str(int(gl.run.count().loc['LUCB (EB radius)'])); m['eLucbOpt']=f"{int(gl.eps_optimal.sum().loc['LUCB (EB radius)'])}/{int(gl.run.count().loc['LUCB (EB radius)'])}"
    m['bCPlow']=f(_beta.ppf(0.05,int(c.success.sum()),len(c)-int(c.success.sum())+1)*100,1)
    try:
        GM=pd.read_csv(V+'bench_groundtruth_margin.csv'); m['bGtMiss']=f"{GM.union_bound_miss.max():.2g}"; m['bGtMarginMin']=f(GM.margin.min(),3)
    except Exception: pass

    # ---- retrospective out-of-sample check (stage F_validation)
    try:
        VH=pd.read_csv(V+'validation_heldout_summary.csv')
        def vh(an,ts,pr,col): return VH[(VH.analysis==an)&(VH.test_set==ts)&(VH.predictor==pr)].iloc[0][col]
        for an,t in (('held-out drug','Drug'),('held-out genotype','Gt')):
            for pr,k in (('network model','M'),('trivial baseline','B')):
                m[f'v{t}Pool{k}']=f(vh(an,'all held-out points pooled',pr,'spearman'),2); m[f'v{t}Pool{k}lo']=f(vh(an,'all held-out points pooled',pr,'spearman_lo'),2); m[f'v{t}Pool{k}hi']=f(vh(an,'all held-out points pooled',pr,'spearman_hi'),2)
        for dr,t in (('Ibrutinib','Ibr'),('Midostaurin','Mido')): m[f'vDrug{t}']=f(vh('held-out drug',dr,'network model','spearman'),2); m[f'vDrug{t}P']=f(vh('held-out drug',dr,'network model','perm_p'),2)
        for nm_,t in (('Waves 3+4 fit -> Waves 1+2 data','WA'),('Waves 1+2 fit -> Waves 3+4 data','WB'),('Waves 3+4 fit -> FPMTB cohort (sign reversed)','FA'),('Waves 1+2 fit -> FPMTB cohort (sign reversed)','FB')):
            m[f'vX{t}M']=f(vh('cross-cohort',nm_,'network model','spearman'),2); m[f'vX{t}B']=f(vh('cross-cohort',nm_,'persistence of training-cohort data','spearman'),2); m[f'vX{t}n']=str(int(vh('cross-cohort',nm_,'network model','n')))
        for nm_,t in (('Waves 3+4 fit -> Waves 1+2 data','A'),('Waves 1+2 fit -> Waves 3+4 data','B')):
            for dr,d_ in (('Ibrutinib','Ibr'),('Midostaurin','Mido')): m[f'vW{t}{d_}']=f(vh('cross-cohort, within drug',f'{nm_}: {dr}','network model','spearman'),2)
        PCv=pd.read_csv(V+'e_per_calibration_search.csv'); m['vCalHeld']=str(int(PCv.calibration.str.contains('LODO|LOCO').sum())); m['vCalHeldBest']=str(int((PCv.triplet_is_certified_best&PCv.calibration.str.contains('LODO|LOCO')).sum()))
    except FileNotFoundError: print('[note] validation_heldout_summary.csv not found: run stage F_validation first')

    # ---- decoy maps and single-gene loss of function (stage G_decoy)
    try:
        DS=json.load(open(V+'decoy_summary.json')); KO_=pd.read_csv(V+'gene_loss_of_function.csv'); KO_=KO_[~KO_.gene_off.str.startswith('none')]
        m['decN']=str(DS['n_decoy']); m['decM']=f"{DS['sims_per_set']:,}"; m['decRealScore']=f(DS['real_best_score'],3); m['decRealExc']=f(DS['real_best_excess_add'],3)
        m['decMedScore']=f(DS['decoy_score_median'],2); m['decQScore']=f(DS['decoy_score_q95'],2); m['decMedExc']=f(DS['decoy_excess_median'],3); m['decQExc']=f(DS['decoy_excess_q95'],3)
        m['decFracScore']=f(DS['frac_decoy_score_ge_real']*100,1); m['decFracExc']=f(DS['frac_decoy_excess_ge_real']*100,1)
        m['decPScore']=f(DS['p_score'],3); m['decPExc']=f(DS['p_excess_add'],3); m['decPBliss']=f(DS['p_excess_bliss'],3); m['decPMax']=f(DS['p_max_excess_add'],3)
        m['koN']=str(len(KO_)); m['koFirst']=str(int((KO_.triplet_rank==1).sum())); m['koTopThree']=str(int((KO_.triplet_rank<=3).sum())); m['koPos']=str(int((KO_.triplet_excess_add>0).sum())); m['koMinExc']=f(KO_.triplet_excess_add.min(),3)
    except FileNotFoundError: print('[note] decoy results not found: run stage G_decoy first')
    # ---- all four decoy statistics, raw and Holm-adjusted p-values, and sensitivity to noise in the real-map estimate
    try:
        DM_=pd.read_csv(V+'decoy_maps.csv'); RR_=pd.read_csv(V+'decoy_real_replicates.csv')
        DEC_STATS=[('max_excess_add','Largest excess over additivity among all 92 sets (selection-aware)'),('best_excess_add','Excess over additivity of the best-scoring set'),('best_excess_bliss','Excess over Bliss independence of the best-scoring set'),('best_score','Score of the best-scoring set')]
        pr_=[]; 
        for k,_ in DEC_STATS:
            real=RR_[k].mean(); pr_.append(((DM_[k]>=real).sum()+1)/(len(DM_)+1))
        order_=np.argsort(pr_); holm_=np.zeros(len(pr_)); run_=0.0
        for rank_,i_ in enumerate(order_): run_=max(run_,(len(pr_)-rank_)*pr_[i_]); holm_[i_]=min(1.0,run_)
        rows_=[]; 
        for (k,lab),p_,h_ in zip(DEC_STATS,pr_,holm_):
            real=RR_[k].mean(); reps_=[((DM_[k]>=v).sum()+1)/(len(DM_)+1) for v in RR_[k]]; nge=int((DM_[k]>=real).sum())
            rows_.append([lab,f(real,3),f(DM_[k].median(),3),f(DM_[k].quantile(.95),3),f"{nge}/{len(DM_)}",f(p_,3),f(h_,3),f"{min(reps_):.3f}--{max(reps_):.3f}"])
        DEC_TABLE=rows_
        m['decNreps']=str(len(RR_)); m['decNdecoy']=str(len(DM_))
        for (k,_),t_ in zip(DEC_STATS,('Max','Exc','Bliss','Score')):
            i_=[a for a,_b in DEC_STATS].index(k); m[f'decRaw{t_}']=f(pr_[i_],3); m[f'decHolm{t_}']=f(holm_[i_],3); m[f'decNge{t_}']=str(int((DM_[k]>=RR_[k].mean()).sum()))
            reps_=[((DM_[k]>=v).sum()+1)/(len(DM_)+1) for v in RR_[k]]; m[f'decRepLo{t_}']=f(min(reps_),3); m[f'decRepHi{t_}']=f(max(reps_),3)
    except FileNotFoundError: print('[note] decoy files not found')

    with open(PAPER_DIR+'/numbers.tex','w') as fh:
        fh.write('% auto-generated by make_numbers.py from result CSVs\n')
        for k,vv in m.items(): fh.write(f"\\newcommand{{\\{k}}}{{{vv}}}\n".replace('_','\\_') if False else f"\\newcommand{{\\{k}}}{{{vv}}}\n")
    print(len(m),'macros'); 
    for k in ['redAMLlo','redAMLhi','redCallo','redCalhi','redGrilo','redGrihi','redRemlo','redRemhi','nCertOK','poolGr','poolUni','poolSh','conRed','topScore','topAdd','topExc','exTripmean','exTripmin','exTripmax','exTrippos','exVMmean','aPct','aRank','aMVexc','aUnt','aMV','cBootL','cOLSL','cConfL','tPil','tPal','tPBN','calMido','aGgainM','aGgainW','aClassMido','aClassFlt']: print(k,m.get(k))


    V=C=D=OUT
    os.makedirs(PAPER_DIR+'/tables',exist_ok=True)
    def tex(s): return str(s).replace('_','\\_').replace('&','\\&').replace('%','\\%')
    def write(name,header,rows,colfmt,caption,label,small=True):
        L=['\\begin{table}[H]','\\centering'+('\\small' if small else ''),f'\\caption{{{caption}}}\\label{{{label}}}','\\begin{adjustbox}{max width=\\textwidth}',f'\\begin{{tabular}}{{{colfmt}}}','\\toprule',' & '.join(header)+' \\\\','\\midrule']
        L+=[' & '.join(str(x) for x in r)+' \\\\' for r in rows]; L+=['\\bottomrule','\\end{tabular}','\\end{adjustbox}','\\end{table}']
        open(PAPER_DIR+f'/tables/{name}.tex','w').write('\n'.join(L)+'\n')
    # per-run benchmark
    files=[f for f in glob.glob(C+'bench_*.csv') if not f.endswith(('reference.csv', 'baselines.csv', 'summary.csv', 'margin.csv'))]
    B=pd.concat([pd.read_csv(f) for f in files]); B['m']=B.method.str.replace(r' \(.*\)','',regex=True)
    nm={'aml_pbn_kgbn':'AML PBN','calzone_cellfate':'Calzone','grieco_mapk':'Grieco','remy_tumorigenesis':'Remy'}; rows=[]
    for n in nm:
        for r in sorted(B[(B.network==n)].rep.unique()):
            c=B[(B.network==n)&(B.rep==r)&(B.m=='Certified')].iloc[0]; g=lambda m: 'yes' if B[(B.network==n)&(B.rep==r)&(B.m==m)].success.iloc[0] else 'no'
            rows.append([nm[n],int(r)+1,f"{int(c.total):,}",f"{c.reduction:.1f}",tex(c.returned),'yes' if c.success else 'no',g('Uniform'),g('Successive halving'),g('Greedy forward')])
    write('t_runs',['Network','Run','Simulations','Reduction ($\\times$)','Returned set','Certified correct','Uniform','Halving','Greedy'],rows,'llrrlcccc','\\textbf{Every benchmark run.} Simulations and reduction relative to the guaranteed-uniform design; the last three columns say whether each budget-matched baseline returned an $\\varepsilon$-optimal set.','tab:runs')
    # druggable ranking
    T=pd.read_csv(C+'constrained_druggable_ranking.csv').head(15); ab=lambda s: s.replace('FLT3-inhibitor (gilteritinib-class)','FLT3i').replace('ERK-inhibitor class','ERKi').replace('AKT-inhibitor class','AKTi')
    write('t_druggable',['Rank','Combination','Score','Additive','Excess (additive)','Bliss','Excess (Bliss)'],[[i+1,tex(ab(r.combination)),f"{r.score:.3f}",f"{r.additive_expected:.3f}",f"{r.excess_over_additive:+.3f}",f"{r.bliss_expected:.3f}",f"{r.excess_over_bliss:+.3f}"] for i,r in T.iterrows()],'rlrrrrr',r'\textbf{Fifteen highest-scoring druggable combinations.} Score is the model score from a 30,000-simulation reference. Additive: untreated score plus summed single-drug gains. Bliss: marker-level Bliss independence of fractional effects, averaged over markers. FLT3i: gilteritinib-class FLT3 inhibitor; ERKi, AKTi: inhibitor classes mapped to MAPK1 and AKT1.','tab:drug')
    # per-calibration table
    PCs=pd.read_csv(C+'e_per_calibration_search.csv'); AL=pd.read_csv(V+'pbn_alternative_calibrations.csv').set_index('model'); rows=[]
    for _,r in PCs.iterrows():
        tau=AL.loc[r.calibration,'kendall_tau_vs_reference'] if r.calibration in AL.index else float('nan')
        rows.append([tex(r.calibration.replace('BeatAML_AUC_5drugs_','').replace('BeatAML_-AUC_5drugs_','')),int(r.triplet_rank),'yes' if r.triplet_is_certified_best else 'no',f"{r.excess_linear:+.3f}",f"{r.excess_bliss:+.3f}",f"{tau:.2f}"])
    write('t_calib',['Calibration','Triplet rank','Triplet certified best','Excess (additive)','Excess (Bliss)','Kendall $\\tau$ of drug ranking'],rows,'lccccc',r'\textbf{Certified search inside every distinct calibration.} The full 92-set druggable search was repeated in each calibration shipped with the KGBN toolkit (duplicates removed by file hash). The triplet is ibrutinib + midostaurin + ERK-inhibitor class; its rank is by a 3,000-simulation reference. These calibrations share rule sets and part of their training data and are not statistically independent. LODO: leave-one-drug-out; LOCO: leave-one-cohort-out.','tab:calib')
    # part D tables
    def maybe(f): return pd.read_csv(D+f) if os.path.exists(D+f) else None
    S2=maybe('d_sensitivity.csv')
    if S2 is not None:
        g=S2.groupby(['eps','delta']).agg(runs=('run','count'),cert=('certified','sum'),opt=('eps_optimal','sum'),tot=('total','mean'),ub=('uniform_bound','mean'),red=('reduction','mean')).reset_index()
        write('t_sens',['$\\varepsilon$','$\\delta$','Runs','Certified','$\\varepsilon$-optimal','Mean simulations','Uniform bound','Reduction ($\\times$)'],[[r.eps,r.delta,int(r.runs),int(r.cert),int(r.opt),f"{r.tot:,.0f}",f"{r.ub:,.0f}",f"{r.red:.1f}"] for r in g.itertuples()],'rrrrrrrr','\\textbf{Cost against accuracy and confidence targets} (92 druggable combinations).','tab:sens')
    SC=maybe('d_scaling.csv')
    if SC is not None:
        g=SC.groupby('K').agg(cert=('certified','sum'),n=('rep','count'),ties=('near_ties','mean'),red=('reduction','mean'),lo=('reduction','min'),hi=('reduction','max')).reset_index()
        write('t_scaling',['$K$','Certified','Near-ties (mean)','Reduction mean ($\\times$)','Range'],[[int(r.K),f"{int(r.cert)}/{int(r.n)}",f"{r.ties:.1f}",f"{r.red:.1f}",f"{r.lo:.1f}--{r.hi:.1f}"] for r in g.itertuples()],'rcrrr','\\textbf{Scaling with family size.} Random sub-families of the 1,793 AML gene sets; near-ties are sets within $0.04$ of the best in a 1,500-simulation screen.','tab:scale')
    NZ=maybe('d_noise.csv')
    if NZ is not None:
        g=NZ.groupby('noise').agg(untr=('untreated','mean'),best=('best','mean'),opt=('eps_optimal','sum'),cert=('certified','sum'),n=('rep','count'),red=('reduction','mean'),K=('K','first')).reset_index()
        write('t_noise',['Noise','$K$','Untreated','Best','Certified','$\\varepsilon$-optimal','Reduction ($\\times$)'],[[r.noise,int(r.K),f"{r.untr:.3f}",f"{r.best:.3f}",f"{int(r.cert)}/{int(r.n)}",f"{int(r.opt)}/{int(r.n)}",f"{r.red:.1f}"] for r in g.itertuples()],'rrrrccr','\\textbf{Noise sensitivity} (Calzone network, sets of up to two nodes).','tab:noise')
    GT=maybe('d_genotype.csv')
    if GT is not None:
        write('t_geno',['FLT3','NPM1','Certified best','Score','Untreated','Triplet score','Triplet rank','Triplet excess (additive)','Triplet excess (Bliss)'],[[('mut' if r.FLT3 else 'wt'),('mut' if r.NPM1 else 'wt'),tex(ab(r.certified_best)),f"{r.best_score:.3f}",f"{r.untreated:.3f}",f"{r.triplet_score:.3f}",int(r.triplet_rank),f"{r.triplet_excess:+.3f}",f"{r.triplet_excess_bliss:+.3f}"] for r in GT.itertuples()],'llp{4.4cm}rrrcrr',r'\textbf{Genotype-conditional certified search.} Mutation status held fixed; the triplet is ibrutinib + midostaurin + ERK-inhibitor class.','tab:geno')
    MP=maybe('d_marker_excess.csv')
    if MP is not None:
        write('t_marker',['Marker (desired state)','Untreated','Independence','Observed triplet','Excess'],[[r[0],f"{r[1]:.3f}",f"{r[3]:.3f}",f"{r[2]:.3f}",f"{r[4]:+.3f}"] for r in MP.itertuples(index=False)],'lrrrr','\\textbf{Marker-level decomposition of the triplet.} Independence expectation: $u+(1-u)\\,[1-\\prod_d(1-g_d)]$ with $g_d$ the single-component gain in marker probability.','tab:marker')
    if os.path.exists(C+'validation_heldout_summary.csv'):
        VH=pd.read_csv(C+'validation_heldout_summary.csv'); rows=[]
        def _g(an,ts,pr):
            x=VH[(VH.analysis==an)&(VH.test_set==ts)&(VH.predictor==pr)]; return x.iloc[0] if len(x) else None
        sel=[('held-out drug',d,'Held-out drug',d) for d in ('Venetoclax','Ibrutinib','Entospletinib','Selumetinib','Midostaurin')]+[('held-out drug','all held-out points pooled','Held-out drug','pooled'),('held-out genotype','all held-out points pooled','Held-out genotype','pooled')]+[('cross-cohort',x,'Cross-cohort',x) for x in ('Waves 3+4 fit -> Waves 1+2 data','Waves 1+2 fit -> Waves 3+4 data','Waves 3+4 fit -> FPMTB cohort (sign reversed)','Waves 1+2 fit -> FPMTB cohort (sign reversed)')]
        for an,ts,lab,sub in sel:
            mo=_g(an,ts,'network model'); ba=_g(an,ts,'trivial baseline'); bt='trivial' if ba is not None else 'persistence'
            if ba is None: ba=_g(an,ts,'persistence of training-cohort data')
            ci='' if pd.isna(mo.get('spearman_lo',np.nan)) else f" [{mo.spearman_lo:.2f}, {mo.spearman_hi:.2f}]"
            rows.append([lab,tex(sub.replace('->','$\\to$')),int(mo.n),f"{mo.spearman:.2f}{ci}",("<0.001" if mo.perm_p<0.001 else f"{mo.perm_p:.3f}"),f"{ba.spearman:.2f}",bt])
        write('t_valid',['Analysis','Test set','$n$','Model Spearman $\\rho$','Permutation $p$','Baseline $\\rho$','Baseline'],rows,'llrcrrl',r'\textbf{Out-of-sample agreement of the calibrated network with measured single-drug response (public data only).} Spearman correlation between the network output and measured BeatAML AUC (FPMTB: sensitivity score, sign reversed). Held-out drug: five folds, each fitted without one drug (test $n=8$ genotypes). Held-out genotype: eight folds, each fitted without one mutation profile ($n=5$ drugs). Brackets: bootstrap 95\% interval. Trivial baseline: mean AUC of the other drugs at the same genotype (held-out drug) or of the other genotypes for the same drug (held-out genotype). Persistence: the measured training-cohort values themselves, which a perfect fit to the training cohort would reproduce (FPMTB: drug-level values only). No combination data are involved.','tab:valid')
    if globals().get('DEC_TABLE'):
        write('t_decoy',['Statistic','Real map','Decoy median','Decoy 95th pct','Decoys $\\ge$ real','Raw $p$','Holm $p$','Raw $p$ range over replicates'],DEC_TABLE,'lrrrrrrr',
              r'\textbf{All decoy statistics, with raw and multiplicity-adjusted $p$-values.} Four statistics were computed on the same decoy maps; none was designated primary in advance, and all four are shown. Raw $p=(1+\#\{\text{decoys}\ge\text{real}\})/(1+\#\text{decoys})$ using the mean of the replicate evaluations of the real map. Holm adjustment is over the four statistics. The last column gives the raw $p$ obtained from each single replicate of the real map, which shows how much a single evaluation of the real map would move the result. The first statistic is the most conservative because every decoy map also benefits from selecting the largest excess among its own sets.','tab:decoy')
    if os.path.exists(C+'gene_loss_of_function.csv'):
        KO_=pd.read_csv(C+'gene_loss_of_function.csv'); ab2=lambda x: x.replace('FLT3-inhibitor (gilteritinib-class)','FLT3i').replace('ERK-inhibitor class','ERKi').replace('AKT-inhibitor class','AKTi')
        write('t_ko',['Gene held off','Best set','Triplet rank','Triplet score','Triplet excess (additive)'],[[tex(r.gene_off),tex(ab2(r.best)),int(r.triplet_rank),f"{r.triplet_score:.3f}",f"{r.triplet_excess_add:+.3f}"] for r in KO_.itertuples()],'llrrr',r'\textbf{Single-gene loss of function.} Each row holds one gene off throughout (also when untreated) and repeats the 92-set search with 1,500 simulations per set. The triplet is ibrutinib + midostaurin + ERK-inhibitor class (ERKi); FLT3i: gilteritinib-class FLT3 inhibitor. Reward genes and the mutation nodes were not removed. Ranks of near-tied sets can change between runs because of simulation noise.','tab:ko')
    print(sorted(os.listdir(PAPER_DIR+'/tables')))

    import json
    pr=PREREG['networks']; nm2={'calzone_cellfate':'Calzone cell fate','remy_tumorigenesis':'Remy tumorigenesis','grieco_mapk':'Grieco MAPK','zhang_tlgl':'Zhang T-LGL leukemia (excluded)','aml_pbn_kgbn':'AML PBN (KGBN)'}
    write('t_prereg',['Network','Desired ON','Desired OFF','Max set size'],[[nm2[k],tex(', '.join(v['ON'])),tex(', '.join(v['OFF'])),v['max_set_size']] for k,v in pr.items()],'llll','\\textbf{Reward definition and family size for each network (pre-specified).} Reward is the fraction of the listed output nodes in the desired state at the final step.','tab:prereg')

    # ---- revision tables ----
    def _m(f): return pd.read_csv(OUT_ + f) if os.path.exists(OUT_ + f) else None
    OUT_=C
    PO=_m('e_policy_comparison.csv')
    if PO is not None: write('t_policy',['Candidate','Legacy 7-marker gain (pp)','Strict 5-marker gain (pp)'],[[tex(r.candidate),f"{r.legacy_gain:+.1f}",f"{r.strict_gain:+.1f}"] for r in PO.iloc[1:].itertuples()],'lrr',r'\textbf{Effect of the clamping policy.} Gain over the untreated score (percentage points) for the same simulations scored with the original seven-marker reward (which includes the drug targets BCL2 and AKT1) and the five-marker reward used in the main analysis. No gene rule uses BCL2 as a regulator, so under the strict reward venetoclax cannot change any output.','tab:policy')
    SS_=_m('e_structural_sensitivity.csv')
    if SS_ is not None:
        g=SS_.groupby('scenario').agg(n=('rep','count'),lin=('excess_linear','mean'),linmin=('excess_linear','min'),bl=('excess_bliss','mean'),pos=('excess_linear',lambda x:(x>0.02).mean()),top=('triplet_top','mean')).reset_index()
        write('t_struct',['Scenario','Networks','Mean excess (additive)','Minimum','Mean excess (Bliss)','Excess $>0.02$','Triplet best of four triplets'],[[tex(r.scenario),int(r.n),f"{r.lin:+.3f}",f"{r.linmin:+.3f}",f"{r.bl:+.3f}",f"{100*r.pos:.0f}\\%",f"{100*r.top:.0f}\\%"] for r in g.itertuples()],'lrrrrrr',r'\textbf{Structural sensitivity of the triplet.} Excess over additivity of ibrutinib + midostaurin + ERK-inhibitor class when the MAPK1 input to STAT5A is removed, when the two main STAT5A rule probabilities are swapped, and under random rewiring of one or three regulators. The last column counts networks in which the triplet scores highest among the four triplets that can be formed from ibrutinib, midostaurin, entospletinib and the ERK-inhibitor class.','tab:struct')
    HA_=_m('e_hard_audit.csv')
    if HA_ is not None: write('t_hard',['Runs','Sets','Sets within $0.02$ of best','Certified','$\\varepsilon$-optimal','Interval violations','Mean simulations'],[[len(HA_),15,int(HA_.near_ties.iloc[0]),int(HA_.certified.sum()),int(HA_.eps_optimal.sum()),int(HA_.ci_violation.sum()),f"{HA_.total.mean():,.0f}"]],'rrrrrrr',r'\textbf{A harder audit of the guarantee.} Fifteen AML gene sets with the highest screening scores (many near-ties), $\varepsilon=0.02$, $\delta=0.05$, true scores from 60,000 simulations each.','tab:hard')
    LU_=_m('e_lucb_comparison.csv')
    if LU_ is not None:
        g=LU_.groupby('method').agg(runs=('run','count'),cert=('certified','sum'),opt=('eps_optimal','sum'),tot=('total','mean')).reset_index()
        write('t_lucb',['Method','Runs','Certified','$\\varepsilon$-optimal','Mean simulations'],[[tex(r.method),int(r.runs),int(r.cert),int(r.opt),f"{r.tot:,.0f}"] for r in g.itertuples()],'lrrrr',r'\textbf{Certified search against LUCB} on the 92-set druggable family ($\varepsilon=0.01$, $\delta=0.05$, same empirical-Bernstein radius).','tab:lucb')
    BL_=_m('pbn_synergy_bliss.csv')
    if BL_ is not None: write('t_bliss5',['Pair','Observed (\\%)','Additive (\\%)','Bliss (\\%)','Excess additive (pp)','Excess Bliss (pp)'],[[tex(r.pair),f"{r.observed:.1f}",f"{r.linear_additive:.1f}",f"{r.bliss_expected:.1f}",f"{r.excess_linear_pp:+.2f}",f"{r.excess_bliss_pp:+.2f}"] for r in BL_.itertuples()],'lrrrrr',r'\textbf{Five-drug pairs under the strict reward}, with linear-additive and Bliss expectations.','tab:bliss5')
    MD_=_m('e_mechanism_ablation.csv')
    if MD_ is not None: write('t_mech',['Network','Marker (desired state)','Untreated','Triplet','Additive','Excess (additive)','Bliss','Excess (Bliss)'],[[tex(r.network),r.marker,f"{r.untreated:.3f}",f"{r.triplet:.3f}",f"{r.additive:.3f}",f"{r.excess_linear:+.3f}",f"{r.bliss:.3f}",f"{r.excess_bliss:+.3f}"] for r in MD_.itertuples()],'llrrrrrr',r'\textbf{Marker-level ablation of the triplet.} Marker probabilities of the desired state in the reference network and after removing the MAPK1 input, or both the BTK and MAPK1 inputs, from the STAT5A rules (40,000 simulations per set). The triplet is ibrutinib + midostaurin + ERK-inhibitor class.','tab:mech')
    GM_=_m('bench_groundtruth_margin.csv')
    if GM_ is not None: write('t_gtmargin',['Network','$K$','Best refined','30th screening score','Margin','Union bound on missing a better set'],[[nm2.get(r.network,r.network) if 'nm2' in globals() else tex(r.network),int(r.K),f"{r.best_refined:.3f}",f"{r.screen_30th:.3f}",f"{r.margin:.3f}",f"{r.union_bound_miss:.2g}"] for r in GM_.itertuples()],'lrrrrr',r'\textbf{Ground-truth margin.} A set outside the re-estimated top 30 would have to beat the best refined estimate and still fall below the 30th screening score; the union bound uses the worst-case standard deviation 0.5 of a [0,1] reward.','tab:gtmargin')



    # ---------------- Revision 9: method comparison, ablations, controlled gap structure ----------------
    if os.path.exists(C+'h_method_comparison.csv'):
        HM=pd.read_csv(C+'h_method_comparison.csv'); HU=pd.read_csv(C+'h_uniform_guaranteed.csv'); HB=pd.read_csv(C+'h_batch_ablation.csv'); HG=pd.read_csv(C+'h_gap_structure.csv'); HMB=pd.read_csv(C+'h_matched_budget.csv')
        short={'Certified search (EB, successive elimination)':'Certified search','LUCB (same EB radius)':'LUCB','UGapE (same EB radius)':'UGapE','Ablation: no elimination (stop rule only)':'No elimination','Ablation: Hoeffding radius':'Hoeffding radius','Ablation: doubling checkpoints':'Doubling checkpoints'}
        HM['mth']=HM.method.map(short)
        A=HM.groupby(['family','eps','mth'],sort=False).agg(runs=('rep','count'),tot=('total','mean'),sd=('total','std'),rounds=('rounds','mean'),cert=('certified','sum'),opt=('eps_optimal','sum'),viol=('violation','sum'),ub=('uniform_bound','first')).reset_index()
        piv=A.pivot_table(index=['family','eps'],columns='mth',values='tot',sort=False)
        rat=lambda a,b:(piv[a]/piv[b])        # cost of a relative to b
        mm={}
        mm['hNruns']=f"{len(HM):,}"; mm['hViol']=str(int(HM.violation.sum())); mm['hOptAll']=f"{int(HM.eps_optimal.sum()):,}/{len(HM):,}"
        okc=piv.index[[(A[(A.family==i[0])&(A.eps==i[1])&(A.mth=='Certified search')].cert.iloc[0]>=0.9*A[(A.family==i[0])&(A.eps==i[1])&(A.mth=='Certified search')].runs.iloc[0]) for i in piv.index]]   # settings where certified search certifies
        r_l=rat('Certified search','LUCB').loc[okc]; r_u=rat('Certified search','UGapE').loc[okc]
        mm['hLucbLo']=f"{r_l.min():.1f}"; mm['hLucbHi']=f"{r_l.max():.1f}"; mm['hUgLo']=f"{r_u.min():.1f}"; mm['hUgHi']=f"{r_u.max():.1f}"
        r_n=rat('No elimination','Certified search').loc[okc]; mm['hNoElimLo']=f"{r_n.min():.1f}"; mm['hNoElimHi']=f"{r_n.max():.1f}"
        r_h=rat('Hoeffding radius','Certified search').loc[okc]; mm['hHoeffLo']=f"{r_h.min():.1f}"; mm['hHoeffHi']=f"{r_h.max():.1f}"
        r_d=rat('Doubling checkpoints','Certified search').loc[okc]; mm['hDblLo']=f"{r_d.min():.2f}"; mm['hDblHi']=f"{r_d.max():.2f}"
        rd=A[A.mth.isin(['Certified search','Doubling checkpoints','UGapE','LUCB'])].pivot_table(index=['family','eps'],columns='mth',values='rounds',sort=False).loc[okc]
        mm['hRdDblLo']=f"{rd['Doubling checkpoints'].min():.0f}"; mm['hRdDblHi']=f"{rd['Doubling checkpoints'].max():.0f}"; mm['hRdUgLo']=f"{rd['UGapE'].min():.0f}"; mm['hRdUgHi']=f"{rd['UGapE'].max():.0f}"; mm['hRdCsLo']=f"{rd['Certified search'].min():.0f}"; mm['hRdCsHi']=f"{rd['Certified search'].max():.0f}"
        # Hoeffding failures to certify
        hh=A[A.mth=='Hoeffding radius']; mm['hHoeffUnc']=f"{int((hh.runs-hh.cert).sum())}/{int(hh.runs.sum())}"
        # reductions of each method relative to uniform with the same guarantee (K=833, eps=0.02 and K=92, eps=0.01)
        def red(fam,eps,mth): r=A[(A.family==fam)&(A.eps==eps)&(A.mth==mth)].iloc[0]; return r.ub/r.tot
        mm['hRedCsA']=f"{red('AML druggable sets (K=92)',0.01,'Certified search'):.1f}"; mm['hRedUgA']=f"{red('AML druggable sets (K=92)',0.01,'UGapE'):.1f}"; mm['hRedLuA']=f"{red('AML druggable sets (K=92)',0.01,'LUCB'):.1f}"
        mm['hRedCsB']=f"{red('AML 3-gene sets (K=833)',0.02,'Certified search'):.1f}"; mm['hRedUgB']=f"{red('AML 3-gene sets (K=833)',0.02,'UGapE'):.1f}"
        mm['hUniOk']=f"{int(HU.eps_optimal.sum())}/{int(HU.runs.sum())}"
        mm['hMbU']=f"{int(HMB.uniform_ok.sum())}/{len(HMB)}"; mm['hMbH']=f"{int(HMB.halving_ok.sum())}/{len(HMB)}"
        # batch size
        bg=HB.groupby(['family','m']).total.mean().unstack(0); mm['hBatchBest']=f"{(bg.min()/bg.loc[100]).min():.2f}"; mm['hBatchK']=f"{(bg.loc[1000]/bg.loc[100]).min():.2f}"; mm['hBatchKHi']=f"{(bg.loc[1000]/bg.loc[100]).max():.2f}"
        # controlled gap-structure
        GG=HG.groupby(['K','top_j']).agg(H=('H_eps','mean'),tot=('total','mean'),ub=('uniform_bound','first'),cert=('certified','mean'),near=('near_ties_004','mean')).reset_index(); GG['red']=GG.ub/GG.tot
        mm['gRho']=f"{spearmanr(HG.H_eps,HG.total)[0]:.2f}"
        a=GG[GG.K==100].sort_values('top_j'); mm['gRedJa']=f"{a.red.iloc[0]:.1f}"; mm['gRedJb']=f"{a.red.iloc[-1]:.1f}"; mm['gCostJa']=f"{a.tot.iloc[0]:,.0f}"; mm['gCostJb']=f"{a.tot.iloc[-1]:,.0f}"
        b=GG[GG.top_j==5].sort_values('K'); mm['gRedKa']=f"{b.red.iloc[0]:.1f}"; mm['gRedKb']=f"{b.red.iloc[-1]:.1f}"; mm['gCostKa']=f"{b.tot.iloc[0]:,.0f}"; mm['gCostKb']=f"{b.tot.iloc[-1]:,.0f}"
        WP=HM.groupby(['family','eps','mth'],sort=False)[['wall1','wall16','wall128']].mean().reset_index()
        def wratio(Wc, idx=None):
            q=WP.pivot_table(index=['family','eps'],columns='mth',values=Wc,sort=False); r=(q[['LUCB','UGapE']].min(axis=1)/q['Certified search']); r=r.loc[okc]
            return r if idx is None else r[[i for i in r.index if i[0] in idx]]
        BEN=('Calzone cell fate (K=2,951)','Grieco MAPK (K=1,275)','Remy tumorigenesis (K=5,488)')
        mm['hWsixLo']=f"{wratio('wall16').min():.1f}"; mm['hWsixHi']=f"{wratio('wall16').max():.1f}"; mm['hWhunLo']=f"{wratio('wall128').min():.1f}"; mm['hWhunHi']=f"{wratio('wall128').max():.0f}"
        mm['hWbenLo']=f"{wratio('wall128',BEN).min():.0f}"; mm['hWbenHi']=f"{wratio('wall128',BEN).max():.0f}"; mm['hWbenSixLo']=f"{wratio('wall16',BEN).min():.1f}"; mm['hWbenSixHi']=f"{wratio('wall16',BEN).max():.1f}"
        q1=WP.pivot_table(index=['family','eps'],columns='mth',values='wall1',sort=False).loc[okc]; mm['hSerLo']=f"{(q1['Certified search']/q1[['LUCB','UGapE']].min(axis=1)).min():.1f}"; mm['hSerHi']=f"{(q1['Certified search']/q1[['LUCB','UGapE']].min(axis=1)).max():.1f}"
        mm['hNfam']=str(A.family.nunique()); mm['hNset']=str(len(piv)); mm['hNnet']='4'
        with open(PAPER_DIR+'/numbers_methods.tex','w') as fh:
            for k,v in mm.items(): fh.write('\\newcommand{\\%s}{%s}\n'%(k,v))
        # --- tables ---
        rows=[]
        for fam,eps in piv.index:
            row=[tex(fam),f"{eps:g}"]
            for mt in ('Certified search','LUCB','UGapE','Doubling checkpoints','Hoeffding radius','No elimination'):
                r=A[(A.family==fam)&(A.eps==eps)&(A.mth==mt)].iloc[0]; s=f"{r.tot:,.0f}"
                if r.cert<r.runs: s+=f" ({int(r.cert)}/{int(r.runs)} cert.)"
                row.append(s)
            row.append(f"{A[(A.family==fam)&(A.eps==eps)].ub.iloc[0]:,.0f}"); rows.append(row)
        write('t_methods',['Family','$\\varepsilon$','Certified search','LUCB','UGapE','Doubling checkpoints','Hoeffding radius','No elimination','Uniform, same guarantee'],rows,'lrrrrrrrr',
              r'\textbf{Mean simulations to certificate for certified search, two index methods and three ablations.} All methods use the same $\delta=0.05$, batch size, per-candidate cap and (except the Hoeffding ablation) the same empirical-Bernstein radius; they differ in allocation or stopping only. Candidate rewards are replayed from simulated pools, so the true means are exact (Methods). Between 20 and 100 runs per cell (Supplementary Table~\ref{tab:methods_full}). Where fewer than all runs certified before the cap, the count is given.','tab:methods')
        rows=[]
        for fam,eps in piv.index:
            for mt in ('Certified search','LUCB','UGapE','Doubling checkpoints','Hoeffding radius','No elimination'):
                r=A[(A.family==fam)&(A.eps==eps)&(A.mth==mt)].iloc[0]; rows.append([tex(fam),f"{eps:g}",mt,int(r.runs),int(r.cert),int(r.opt),int(r.viol),f"{r.tot:,.0f}",f"{r.sd:,.0f}",f"{r.rounds:.0f}"])
        write('t_methods_full',['Family','$\\varepsilon$','Method','Runs','Certified','$\\varepsilon$-optimal','Interval violations','Mean simulations','SD','Mean decision rounds'],rows,'llrrrrrrrr',r'\textbf{All method-comparison runs.} Decision rounds are the number of times the stopping rule is evaluated; for certified search each round is one parallel batch over all active candidates, for LUCB and UGapE each round is sequential.','tab:methods_full',small=True)
        write('t_batch',['Family','Batch size $m$','Mean simulations','Certified','Interval violations'],[[tex(r.family),int(r.m),f"{r.total:,.0f}",f"{int(r.certified)}/{int(r.n)}",int(r.viol)] for r in HB.groupby(['family','m']).agg(total=('total','mean'),certified=('certified','sum'),n=('rep','count'),viol=('violation','sum')).reset_index().itertuples()],'lrrrr',
              r'\textbf{Effect of the batch size of certified search.} Replayed pools; $\varepsilon=0.01$ ($K=92$, 60 runs per size) and $\varepsilon=0.02$ ($K=833$, 30 runs per size).','tab:batch')
        write('t_gap',['$K$','Best sets always included $j$','Mean gap complexity $H_\\varepsilon$','Mean simulations','Uniform, same guarantee','Reduction','Certified'],[[int(r.K),int(r.top_j),f"{r.H:,.0f}",f"{r.tot:,.0f}",f"{r.ub:,.0f}",f"{r.red:.1f}$\\times$",f"{100*r.cert:.0f}\\%"] for r in GG.itertuples()],'rrrrrrr',
              r'\textbf{Controlled test of family size and near-ties.} Families of $K$ candidate sets are drawn from the 833 three-gene sets; the $j$ highest-scoring sets are always included and the rest are random (five sub-families per row, six runs each, $\varepsilon=0.02$). $H_\varepsilon=\sum_a\max(\Delta_a,\varepsilon)^{-2}$.','tab:gap')
        rows=[]
        for fam,eps in piv.index:
            row=[tex(fam),f"{eps:g}"]
            for Wc in ('wall16','wall128'):
                for mt in ('Certified search','LUCB','UGapE','Doubling checkpoints'):
                    r=WP[(WP.family==fam)&(WP.eps==eps)&(WP.mth==mt)].iloc[0]; row.append(f"{r[Wc]:,.0f}")
            rows.append(row)
        write('t_wall',['Family','$\\varepsilon$','Certified','LUCB','UGapE','Doubling','Certified','LUCB','UGapE','Doubling'],rows,'lrrrrrrrrr',
              r'\textbf{Elapsed time with parallel workers.} Mean elapsed time in units of one batch-of-$m$-simulations per worker, for $W=16$ workers (columns 3--6) and $W=128$ workers (columns 7--10). A round of certified search runs its active candidates in parallel batches ($\lceil A/W\rceil$ batch times for $A$ active candidates); each LUCB or UGapE round is one batch time, because the next choice depends on the previous result. Dispatch latency is not charged, which favours the sequential methods. Serial time ($W=1$) equals the total simulations of Table~\ref{tab:methods}. Same runs as Table~\ref{tab:methods}.','tab:wall')
        if os.path.exists(C+'h_batch_lucb.csv') and os.path.exists(C+'i_theory_bound_check.csv'):
            HBL=pd.read_csv(C+'h_batch_lucb.csv'); TH=pd.read_csv(C+'i_theory_bound_check.csv'); TR=pd.read_csv(C+'i_theory_radius_check.csv'); TP=pd.read_csv(C+'i_replay_pooled_guarantee.csv')
            cs_=WP[WP.mth=='Certified search'].set_index(['family','eps']); ug_=WP[WP.mth=='UGapE'].set_index(['family','eps']); tot_cs=A[A.mth=='Certified search'].set_index(['family','eps']).tot; tot_ug=A[A.mth=='UGapE'].set_index(['family','eps']).tot
            bl=HBL.groupby(['family','eps','B']).agg(tot=('total','mean'),w=('wall_own','mean')).reset_index(); rowsb=[]; sp16=[]; sp128=[]; totr=[]; totr_all=[]
            for (fam,eps),g in HBL.groupby(['family','eps'],sort=False):
                b16=bl[(bl.family==fam)&(bl.eps==eps)&(bl.B==16)].iloc[0]; b128=bl[(bl.family==fam)&(bl.eps==eps)&(bl.B==128)].iloc[0]
                c=cs_.loc[(fam,eps)]; u=ug_.loc[(fam,eps)]
                sp16.append(c.wall16/b16.w); sp128.append(c.wall128/b128.w); totr_all.append((fam,tot_cs.loc[(fam,eps)]/b16.tot))
                rowsb.append([tex(fam),f"{eps:g}",f"{c.wall16:,.0f}",f"{b16.w:,.0f}",f"{u.wall16:,.0f}",f"{c.wall128:,.0f}",f"{b128.w:,.0f}",f"{u.wall128:,.0f}",f"{tot_cs.loc[(fam,eps)]:,.0f}",f"{b16.tot:,.0f}",f"{tot_ug.loc[(fam,eps)]:,.0f}"])
            write('t_batchlucb',['Family','$\\varepsilon$','SE','Batch LUCB','UGapE','SE','Batch LUCB','UGapE','SE','Batch LUCB ($B=16$)','UGapE'],rowsb,'lrrrrrrrrrr',
                  r'\textbf{Batch-parallel LUCB against successive elimination (SE) and sequential UGapE.} Mean elapsed time with $W=16$ workers (columns 3--5) and $W=128$ workers (columns 6--8), in batch times, and mean total simulations (columns 9--11). Batch LUCB samples the empirical best candidate and the $B-1$ strongest challengers in each round, with $B=W$ for the elapsed-time columns and $B=16$ for the total-simulations column; it uses the same confidence sequence, stopping rule, batch size and cap as the other columns. 20 to 100 runs per row.','tab:batchlucb')
            ben_=[x for x in totr_all if x[0] in BEN]; mm2={}
            mm2['hBlRuns']=f"{len(HBL):,}"; mm2['hBlViol']=str(int(HBL.violation.sum())); mm2['hBlOpt']=f"{int(HBL.eps_optimal.sum()):,}/{len(HBL):,}"; mm2['hBlSpSixLo']=f"{min(sp16):.2f}"; mm2['hBlSpSixHi']=f"{max(sp16):.1f}"; mm2['hBlSpHunLo']=f"{min(sp128):.2f}"; mm2['hBlSpHunHi']=f"{max(sp128):.1f}"
            mm2['hBlSpHunMed']=f"{np.median(sp128):.1f}"; mm2['hBlSpSixMed']=f"{np.median(sp16):.1f}"; mm2['hBlTotBenLo']=f"{min(x[1] for x in ben_):.1f}"; mm2['hBlTotBenHi']=f"{max(x[1] for x in ben_):.1f}"; mm2['hBlNset']=str(len(sp16))
            mm2['hBlSlowerSix']=str(int(sum(x<0.98 for x in sp16))); mm2['hBlSlowerHun']=str(int(sum(x<0.98 for x in sp128)))
            mm2['tThmLo']=f"{TH.bound_over_observed.min():.0f}"; mm2['tThmHi']=f"{TH.bound_over_observed.max():.0f}"; mm2['tThmHolds']=f"{int(TH.bound_holds_all_runs.sum())}/{len(TH)}"; mm2['tRadChecks']=f"{int(TR.checks.iloc[0]):,}"; mm2['tRadViol']=str(int(TR.radius_exceeds_bound.iloc[0]))
            mm2['tReplayN']=str(int(TP.runs.iloc[0])); mm2['tReplayOk']=str(int(TP.eps_optimal.iloc[0])); mm2['tReplayLB']=f"{100*TP.exact_one_sided_95_lower.iloc[0]:.1f}"
            with open(PAPER_DIR+'/numbers_methods.tex','a') as fh:
                for k,v in mm2.items(): fh.write('\\newcommand{\\%s}{%s}\n'%(k,v))
            write('t_theory',['Family','$\\varepsilon$','Runs','Mean observed','Largest observed','Theorem 3 bound','Bound / mean','Holds in every run'],[[tex(r.family),f"{r.eps:g}",int(r.runs),f"{r.observed_mean:,.0f}",f"{r.observed_max:,.0f}",f"{r.bound:,.0f}",f"{r.bound_over_observed:.0f}$\\times$",'yes' if r.bound_holds_all_runs else 'no'] for r in TH.itertuples()],'lrrrrrrl',
                  r'\textbf{Numerical check of the explicit sample-complexity bound (Theorem 3).} The bound is evaluated from the true means and variances of each replayed family and compared with the simulations used by successive elimination in the runs of Table~\ref{tab:methods_full}.','tab:theory')
        # --- figure ---
        fig,axs=plt.subplots(2,2,figsize=(11.5,8.2))
        ax=axs[0,0]; sel=[('AML druggable sets (K=92)',0.02),('AML 3-gene sets (K=833)',0.02),('Grieco MAPK (K=1,275)',0.02),('Calzone cell fate (K=2,951)',0.02),('Remy tumorigenesis (K=5,488)',0.02),('AML top-15 gene sets',0.02)]; labs=['AML\nK=92','AML\nK=833','Grieco\nK=1,275','Calzone\nK=2,951','Remy\nK=5,488','AML top\nK=15']
        mts=[('Certified search',CH),('LUCB',CP),('UGapE',CG),('Doubling checkpoints',CA)]; w=0.2
        for j_,(mt,c) in enumerate(mts):
            v=[A[(A.family==f_)&(A.eps==e_)&(A.mth==mt)].iloc[0] for f_,e_ in sel]; ax.bar(np.arange(len(sel))+(j_-1.5)*w,[x.ub/x.tot for x in v],w,color=c,label=mt)
        ax.set_xticks(range(len(sel))); ax.set_xticklabels(labs,fontsize=7.5); ax.set_ylabel('simulations saved vs uniform design\nwith the same guarantee (x), $\\varepsilon$=0.02'); ax.set_title('a  Total simulations (serial cost)',loc='left',fontweight='bold',fontsize=9); ax.legend(frameon=False,fontsize=7.5)
        ax=axs[0,1]; abl=[('LUCB',CP),('UGapE',CG),('Doubling checkpoints',CA),('Hoeffding radius',CS),('No elimination',CW)]
        for j_,(mt,c) in enumerate(abl):
            ys=[rat(mt,'Certified search').loc[i] for i in okc]; ax.scatter([j_]*len(ys),ys,color=c,s=22,alpha=.8)
        ax.axhline(1,color='k',lw=.8,ls='--'); ax.set_yscale('log'); ax.set_xticks(range(len(abl))); ax.set_xticklabels([a_[0].replace(' ','\n') for a_ in abl],fontsize=7.5)
        ax.set_ylabel('simulations relative to certified search'); ax.set_title('b  Variants and ablations',loc='left',fontweight='bold',fontsize=9)
        ax=axs[1,0]; Wx=[1,16,128]
        for k_,(f_,e_) in enumerate(sel):
            q=[WP[(WP.family==f_)&(WP.eps==e_)&(WP.mth==mt)].iloc[0] for mt in ('Certified search','LUCB','UGapE')]
            y=[min(q[1][c_],q[2][c_])/q[0][c_] for c_ in ('wall1','wall16','wall128')]; ax.plot(Wx,y,marker='o',lw=1.4,label=labs[k_].replace('\n',' '))
        ax.axhline(1,color='k',lw=.8,ls='--'); ax.set_xscale('log',base=2); ax.set_yscale('log'); ax.set_xticks(Wx); ax.set_xticklabels(Wx); ax.set_xlabel('parallel workers $W$'); ax.set_ylabel('elapsed time of faster index method\nrelative to certified search'); ax.legend(frameon=False,fontsize=7,ncol=2); ax.set_title('c  Elapsed time with parallel workers',loc='left',fontweight='bold',fontsize=9)
        ax=axs[1,1]; ax.scatter(HG.groupby(['K','top_j','subfamily']).H_eps.first(),HG.groupby(['K','top_j','subfamily']).total.mean(),c=CP,s=18,alpha=.8)
        ax.set_xlabel('gap complexity $H_\\varepsilon$'); ax.set_ylabel('simulations to certificate'); ax.set_title('d  Cost follows gap structure',loc='left',fontweight='bold',fontsize=9)
        plt.tight_layout(); fig.savefig(F+'fig_methods.png',dpi=300,bbox_inches='tight'); plt.close(fig)
        print('method-comparison tables, numbers_methods.tex and fig_methods.png written', flush=True)

    print('paper build written to', PAPER_DIR, flush=True)
