# Revision 10 (third round)
* `H_batch`: batch-parallel LUCB (B = 4, 16, 128) against successive elimination on elapsed time and total simulations. `I_theory`: numerical check of the explicit-constant sample-complexity bound (Theorem 3), radius inequality, pooled replay guarantee. `I_drugcomb`: model-predicted pair synergy against a DrugComb export (`DRUGCOMB_CSV=/path/summary.csv python3 aml_certified_search.py --stages I_drugcomb`); the analysis is fixed in the script and no combination data were available in the revision environment, so no result is reported.

# Revision 9 (supervisor comments)
* Second round: pools and method comparison extended to Grieco, Calzone and Remy (`POOLS=calzone_cellfate,grieco_mapk,remy_tumorigenesis`, about 25 min per core); wall-clock model for W parallel workers (`wall1`, `wall16`, `wall128` columns of `h_method_comparison.csv`; table `t_wall`).
* New stages `H_pools` (simulate reward pools: 92 druggable sets and 833 three-gene sets; about 3 + 7 min on one core each) and `H_methods` (about 1 min): certified search against LUCB and UGapE with the same empirical-Bernstein radius, ablations (no elimination, Hoeffding radius, doubling checkpoints, batch size) and a controlled test of family size against near-ties. Results: `reference_results/h_*.csv`, `pool_f*_counts.npy`; tables, `fig_methods.png` and `numbers_methods.tex` are made by stage `paper`.
* Manuscript: Abstract and Introduction rewritten (no limitations; four stated contributions); limitations moved to a separate Discussion subsection; the earlier 4-run LUCB table is superseded.

# Changelog

## Revision 8
* Manuscript: removed all wording about in vivo, in vitro, ex vivo, cell-line and laboratory work; softened claims that went beyond what the model supports.
* New stage `F_validation`: retrospective out-of-sample check of the calibrated network on held-out public data (single-drug response only).
* New stage `G_decoy`: decoy drug-to-gene maps and single-gene loss of function (computational only). The paper stage now also writes `t_decoy` (all four decoy statistics with raw and Holm-adjusted p-values).
* Figure label corrected from "independent" to "related" calibrations; computational "experiments" renamed "analyses".
* Public inputs (KGBN, PyBoolNet) are now pinned to commits; the optional external-comparison scaffold is generic and unused.
* Fixed an invalid LaTeX macro name (`\koTop3` is now `\koTopThree`).
* Absolute build paths removed from `reproduction_logs/`; no results were changed.
